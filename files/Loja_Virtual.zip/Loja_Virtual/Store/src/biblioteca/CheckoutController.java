package biblioteca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.event.ActionEvent;

public class CheckoutController {

private	Parent root;


	// Event Listener on Button.onAction
	@FXML
	public void onPaypalAction(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("paypalLogin.fxml"));
		root = loader.load();
		
		Stage stage2 = new Stage();
		stage2.setScene(new Scene(root));
		Image x = new Image("biblioteca/shopping-cart.png");
		stage2.getIcons().add(x);
		stage2.show();
	}
	// Event Listener on Button.onAction
	@FXML
	public void OnCartaoAction(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Cartao.fxml"));
		root = loader.load();
		
		Stage stage3 = new Stage();
		stage3.setScene(new Scene(root));
		Image x = new Image("biblioteca/shopping-cart.png");
		stage3.getIcons().add(x);
		stage3.show();
	}
}
