package biblioteca;

import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.ResourceBundle;

import classes.Cart;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class CarrinhoController implements Initializable,Serializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;

    @FXML
    private ImageView myimage1;

    @FXML
    private ImageView myimage2;

    @FXML
    private ImageView myimage3;

    @FXML
    private ImageView myimage4;

    @FXML
    private ImageView myimage5;

    @FXML
    private Label mylabel1;

    @FXML
    private Label mylabel2;

    @FXML
    private Label mylabel3;

    @FXML
    private Label mylabel4;

    @FXML
    private Label mylabel5;
    
    @FXML
    private Label quantidade1;

    @FXML
    private Label quantidade2;

    @FXML
    private Label quantidade3;

    @FXML
    private Label valorTot;
    
    public static ImageView im1;
    public static ImageView im2;
    public static ImageView im3;
    public static ImageView im4;
    public static ImageView im5;
   
    public static Label lab1;
    public static Label lab2;
    public static Label lab3;
    public static Label lab4;
    public static Label lab5;

    
    
    
    public static void setlab1Value(String txt1) {
    	lab1.setText(txt1);
    }
    
    public static void setlab2Value(String txt) {
    	lab2.setText(txt);
    }
    
    public static void setlab3Value(String txt) {
    	lab3.setText(txt);
    }
    
    public static void setlab4Value(String txt) {
    	lab4.setText(txt);
    }
    
    public static void setlab5Value(String txt) {
    	lab5.setText(txt);
    }
    
    public static String getlab1Value() {
    	return lab1.getText();
    }
    
  
    
    
    public static void setImage1(Image i1) {
    	im1.setImage(i1);
    }
    
    public static void setImage2(Image i2) {
    	im2.setImage(i2);
    }
    
    public static void setImage3(Image i3) {
    	im3.setImage(i3);
    }
    
    public static void setImage4(Image i4) {
    	im4.setImage(i4);
    }
    
    public static void setImage5(Image i5) {
    	im5.setImage(i5);
    }
    
    public static Image getImage1() {
    	return im1.getImage();
    }
  

    @FXML
    void OnBackAction(ActionEvent event) throws IOException {
    	
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("menu.fxml"));
    	root = loader.load();
    	
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.setScene(scene);
    	stage.setTitle("Carrinho");
    	stage.show();
    	
    }

    @FXML
    void OnCheckAction(ActionEvent event) throws IOException {
    	 
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Checkout.fxml"));
		root = loader.load();
		
		Stage stage2 = new Stage();
		stage2.setScene(new Scene(root));
		Image x = new Image("biblioteca/shopping-cart.png");
		stage2.getIcons().add(x);
		stage2.show();
    }

	public void initialize(URL arg0, ResourceBundle arg1) {
//		try {
//			 Cart cart = new Cart(null,null);
//			mylabel1.setText(cart.getDesc1());
//			//myimage1.setImage(new Image("C:\\Users\\willt\\Desktop\\Loja_Virtual\\Store\\src\\biblioteca\\"+cart.getImage1()));
//			
//		}catch(Exception e) {
//			System.out.println(e.getMessage());
//		}
		
//		String foto = carr.getImages().toString();
//		myimage1.setImage(new Image("C:\\Users\\willt\\Desktop\\Loja_Virtual\\Store\\src\\biblioteca\\"+foto));
//		Cart carrinha = new Cart();
//		carrinha.getIm1();
//		carrinha.getDesc1();
//		System.out.println(carrinha.getDesc1());
//		im1 = myimage1;
//		lab1 = mylabel1;
//		im2= myimage2;
//		lab2 = mylabel2;
//		im3 = myimage3;
//		lab3 = mylabel3;
//		im4 = myimage4;
//		lab4 = mylabel4;
//		im5 = myimage5;
//		lab5 = mylabel5;
		
	}
	
	public void imagemteste(Image teste, String txt) {
		myimage1.setImage(teste);
		mylabel1.setText(txt);
	}
	
	public void imagemteste2(Image teste2, String txt2) {
		myimage2.setImage(teste2);
		mylabel2.setText(txt2);
	}
	public void imagemteste3(Image teste3, String txt3) {
		myimage3.setImage(teste3);
		mylabel3.setText(txt3);
	}
	
	public void imagemteste4(Image teste4, String txt4) {
		myimage4.setImage(teste4);
		mylabel4.setText(txt4);
	}
	
	public void imagemteste5(Image teste5, String txt5) {
		myimage5.setImage(teste5);
		mylabel5.setText(txt5);
	}
	
	
	
	public void quantaty3(String q1, String q2, String q3) {
		quantidade1.setText(q1);
		quantidade2.setText(q2);
		quantidade3.setText(q3);
	}
	
	public void quantaty1(String q1) {
		quantidade1.setText(q1);
	}
	
	public void quantaty2(String q1, String q2) {
		quantidade1.setText(q1);
		quantidade2.setText(q2);
	}
	
	public void TotalApagar(String totalapagar) {
		valorTot.setText(totalapagar);
		paypalPagamentoController pag = new paypalPagamentoController();
		CartaoController card = new CartaoController();
		card.voi(Double.parseDouble(valorTot.getText().replace(",", ".")));
		pag.voi(Double.parseDouble(valorTot.getText().replace(",", ".")));
	}
	
	

}
