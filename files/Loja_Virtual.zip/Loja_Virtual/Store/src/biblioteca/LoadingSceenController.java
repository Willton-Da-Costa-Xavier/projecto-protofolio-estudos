package biblioteca;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

public class LoadingSceenController implements Initializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;

    @FXML
    public ProgressBar myprogressbar;
    
    @FXML
    public ImageView myImage;
    
    BigDecimal progress = new BigDecimal(String.format("%.2f", 0.0).replace(",", "."));

	public void initialize(URL arg0, ResourceBundle arg1) {
		Image x2 = new Image("biblioteca/grocery-store.png");
		myImage.setImage(x2);
		 myprogressbar.setStyle("-fx-accent: #00FF00;");
		
	}
	
	@FXML
    void OnMouseClickedAction(MouseEvent event) throws IOException{
		

		RotateTransition rotate = new RotateTransition();
		rotate.setNode(myImage);
		rotate.setDuration(Duration.millis(2000));
		rotate.setInterpolator(Interpolator.LINEAR);
//		rotate.setCycleCount(10);
		rotate.setByAngle(360);
		rotate.play();
		if(progress.doubleValue()<1) {
		progress = new BigDecimal(String.format("%.2f", progress.doubleValue()+0.1).replace(",", "."));
		myprogressbar.setProgress(progress.doubleValue());
		}
		
		if(progress.doubleValue()==1) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Audio.fxml"));
	    	root = loader.load();
	    	
	    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
	    	scene = new Scene(root);
	    	stage.setScene(scene);
	    	stage.show();
		}
		
    }
	

}
