package biblioteca;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.Node;

public class AudioController implements Initializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;

    @FXML
    private Label mylabel;

    @FXML
    private ProgressBar myprogressbar;

    @FXML
    private Button pauseButton;

    @FXML
    private Button playButton;

    @FXML
    private Button resetButton;

    @FXML
    private Slider volumeslider;
    
    @FXML
    private Button skipButton;

    
    private File directory;
    
    private File[] files;
    
    private ArrayList<File> song;
    
    private Timer timer;
    
    private TimerTask task;
    
    private boolean running;
    
    private int songNumber;
    
    public Media media;
    public MediaPlayer mediaplayer;
    
    BigDecimal progress = new BigDecimal(String.format("%.2f", 0.0).replace(",", "."));

    @FXML
    void OnPauseAction(ActionEvent event) {
    	cancelTimer();
    	mediaplayer.pause();
    	
    }

    @FXML
    void OnPlayAction(ActionEvent event) {
    	beginTimer();
    	mediaplayer.play();
    }

    @FXML
    void OnResetAction(ActionEvent event) {
    	myprogressbar.setProgress(0);
    	mediaplayer.seek(Duration.seconds(0));
    	
    }
    
    @FXML
    void OnSkipAction(ActionEvent event) throws IOException {
    	mediaplayer.stop();

    	FXMLLoader loader = new FXMLLoader(getClass().getResource("menu.fxml"));
    	root = loader.load();
    	
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.setScene(scene);
    	stage.show();
    	
    }
    

	public void initialize(URL arg0, ResourceBundle arg1) {
		
		song = new ArrayList<File>();
		directory  = new File("intro");
		files = directory.listFiles();
		
		if(files !=null) {
			for(File file: files) {
				song.add(file);
			}
		}
		
    	media = new Media(song.get(songNumber).toURI().toString());
		mediaplayer = new MediaPlayer(media);
		
		mylabel.setText(song.get(songNumber).getName());
		
		 myprogressbar.setStyle("-fx-accent: #00FF00;");
		 
		volumeslider.valueProperty().addListener(new ChangeListener<Number>() {

			public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {
				mediaplayer.setVolume(volumeslider.getValue()*0.01);
				
			}
			
		});
		
		
		
	}
	
	public void beginTimer() {
		timer = new Timer();
		
		task = new TimerTask() {

			@Override
			public void run() {
				
				running = true;
				double current = mediaplayer.getCurrentTime().toSeconds();
				double end = media.getDuration().toSeconds();
				myprogressbar.setProgress(current/end);
				
				if(current/end==1) {
					cancelTimer();
					
				}
			}
			
		};
		
		timer.scheduleAtFixedRate(task, 0, 1000);
		
	}
	
	public void cancelTimer() {
		
		running = false;
		timer.cancel();
	}
	
	

}
