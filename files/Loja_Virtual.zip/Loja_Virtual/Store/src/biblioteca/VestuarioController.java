package biblioteca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

import java.io.IOException;

import classes.Utensilios;
import classes.Vestuario;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class VestuarioController {
	
	private Parent root;
	private Stage stage;
	private Scene scene;
	
private static double val5;
private static int cont;
	
	static {
		val5=0;
		cont=0;
	}
	
	@FXML
	private AnchorPane anchor;
	@FXML
	private TextField txtpesquisa;
	@FXML
	private Label lab1;
	@FXML
	private ImageView image1;
	@FXML
	private Label lab2;
	@FXML
	private ImageView image2;
	@FXML
	private Label lab3;
	@FXML
	private ImageView image3;
	@FXML
	private Label lab4;
	@FXML
	private ImageView image4;
	@FXML
	private Label lab5;
	@FXML
	private ImageView image5;
	@FXML
	private Label lab6;
	@FXML
	private ImageView image6;
	@FXML
	private Button c1;
	@FXML
	private Button c2;
	@FXML
	private Button c3;
	@FXML
	private Button c4;
	@FXML
	private Button c5;
	@FXML
	private Button c6;
	@FXML
	private Label Q1;
	@FXML
	private Label Q2;
	@FXML
	private Label Q3;
	@FXML
	private Label Q4;
	@FXML
	private Label Q5;
	@FXML
	private Label Q6;
	@FXML
	private TextField qnt1;
	@FXML
	private TextField qnt2;
	@FXML
	private TextField qnt3;
	@FXML
	private TextField qnt4;
	@FXML
	private TextField qnt5;
	@FXML
	private TextField qnt6;
	@FXML
	private Button tot;
	@FXML
	private TextField totfield;
	@FXML
	private Label MT;
	
	  @FXML
	    private Button cc1;

	    @FXML
	    private Button cc2;

	    @FXML
	    private Button cc3;
	    
	    @FXML
	    private Button cartbtn;

	    @FXML
	    private Button cc4;

	    @FXML
	    private Button cc5;

	    @FXML
	    private Button cc6;

	    @FXML
	    private Button check;
	
	  @FXML
	    private RadioButton Fem;

	    @FXML
	    private RadioButton Masc;
	    
	    @FXML
	    private RadioButton cri;
	    
	    @FXML
	    private Button adcar1;

	    @FXML
	    private Button adcar2;

	    @FXML
	    private Button adcar3;

	    @FXML
	    private Button adcar4;

	    @FXML
	    private Button adcar5;

	    @FXML
	    private Button adcar6;
	    
	    private Button bt;
	    
	    private Label  labelex;
	    
	    private Label  labelex2;
	    
	    private Label lab32;
	    
	    private Label lab43;

	    
	
	    double total=0;
	    double total1=0;
	    double total2=0;
	    double total3=0;
	    double total4=0;
	    double total5=0;
	    double total6=0;
	    double total7=0;
	    double total8=0;
	    double total9=0;
    
    int quant =0;
    int quant1 =0;
    int quant2 =0;
    int quant3 =0;
    int quant4 =0;
    int quant5 =0;
    int quant6 =0;

	// Event Listener on Button.onAction
	@FXML
	public void PesquisaAction(ActionEvent event) {
		
    	c1.setVisible(true);
		c2.setVisible(true);
		c3.setVisible(true);
		c4.setVisible(true);
		c5.setVisible(true);
		c6.setVisible(true);
		image1.setVisible(true);
		image2.setVisible(true);
		image3.setVisible(true);
		image4.setVisible(true);
		image5.setVisible(true);
		lab1.setVisible(true);
		lab2.setVisible(true);
		lab3.setVisible(true);
		lab4.setVisible(true);
		lab5.setVisible(true);
		lab6.setVisible(true);
		qnt1.setVisible(true);
		qnt2.setVisible(true);
		qnt3.setVisible(true);
		qnt4.setVisible(true);
		qnt5.setVisible(true);
		qnt6.setVisible(true);
		tot.setVisible(true);
		totfield.setVisible(true);
		MT.setVisible(true);
		Q1.setVisible(true);
		Q2.setVisible(true);
		Q3.setVisible(true);
		Q4.setVisible(true);
		Q5.setVisible(true);
		Q6.setVisible(true);
		cc1.setVisible(true);
		cc2.setVisible(true);
		cc3.setVisible(true);
		cc4.setVisible(true);
		cc5.setVisible(true);
		cc6.setVisible(true);
		check.setVisible(true);
		adcar1.setVisible(true);
		adcar2.setVisible(true);
		adcar3.setVisible(true);
		adcar4.setVisible(true);
		adcar5.setVisible(true);
		adcar6.setVisible(true);
		labelex2.setVisible(false);
		labelex.setVisible(false);
		bt.setVisible(false);
		lab32.setVisible(false);
		lab43.setVisible(false);
		
		if(txtpesquisa.getText().equalsIgnoreCase("Camisa") || txtpesquisa.getText().equalsIgnoreCase("Camisas")) {
			if(Fem.isSelected()) {
			Image x = new Image("biblioteca/camisaF1.png");
			image1.setImage(x);
			lab1.setText("Hotlion\nCamisa femenina de\nciclismo respiravel\n1.621.08MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt1.setText(Integer.toString(quant));
        	
        	Image x2 = new Image("biblioteca/camisaF2.png");
			image2.setImage(x2);
			lab2.setText("DF Fit\nKit 3 Camisetas\nFemenina Manga Longa\n957.36.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt2.setText(Integer.toString(quant));
        	
        	Image x3 = new Image("biblioteca/camisaF3.png");
			image3.setImage(x3);
			lab3.setText("basicamente.\nCamiseta Babylook\nGola V Femenina\n301.46.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt3.setText(Integer.toString(quant));
        	
        	Image x4 = new Image("biblioteca/camisaF4.png");
			image4.setImage(x4);
			lab4.setText("MIABR\nCamiseta Blusa Tapa\nBumBum Manga Curta\n553.73.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt4.setText(Integer.toString(quant));
        	
        	Image x5 = new Image("biblioteca/camisaF5.png");
			image5.setImage(x5);
			lab5.setText("Mikonos\nCamisa Golo Polo\nFemenina\n503.28.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt5.setText(Integer.toString(quant));
        	
        	Image x6 = new Image("biblioteca/camisaF6.png");
			image6.setImage(x6);
			lab6.setText("Speedo\nCamiseta Manga Curta\n370.83.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt6.setText(Integer.toString(quant));
        	
			}else if(Masc.isSelected()) {
				
				Image x = new Image("biblioteca/camisaM1.png");
				image1.setImage(x);
				lab1.setText("ZAROC\nKit 5 Camisetas\nMasculinas Slim Fit...\n1.816.33MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt1.setText(Integer.toString(quant));
	        	
	        	Image x2 = new Image("biblioteca/camisaM2.png");
				image2.setImage(x2);
				lab2.setText("POLO VOKER\nCamisa Gola Polo\nVOKER com Protecao\n695.00.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt2.setText(Integer.toString(quant));
	        	
	        	Image x3 = new Image("biblioteca/camisaM3.png");
				image3.setImage(x3);
				lab3.setText("CF Confidencial\nCamisa Social Slim Fit\nInox\nManga Curta\n996.46.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt3.setText(Integer.toString(quant));
	        	
	        	Image x4 = new Image("biblioteca/camisaM4.png");
				image4.setImage(x4);
				lab4.setText("Bom Pano\nCamisa Social\nMasculina Bom Pano\n881.68.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt4.setText(Integer.toString(quant));
	        	
	        	Image x5 = new Image("biblioteca/camisaM5.png");
				image5.setImage(x5);
				lab5.setText("Novastreet\nKit de 5 Camisetas\nMasculinas Manga...\n2.231.31MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt5.setText(Integer.toString(quant));
	        	
	        	Image x6 = new Image("biblioteca/camisaM6.png");
				image6.setImage(x6);
				lab6.setText("Ultra Skull\nCamiseta Targayen\nGame Of Thrones...\n1.007.81MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt6.setText(Integer.toString(quant));
				
			}else if(cri.isSelected()) {
				
				Image x = new Image("biblioteca/camisaC1.png");
				image1.setImage(x);
				lab1.setText("Generic\nSueter arco-iris para\ncriancas | camisola da..\n2.058.76MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt1.setText(Integer.toString(quant));
	        	
	        	Image x2 = new Image("biblioteca/camisaC2.png");
				image2.setImage(x2);
				lab2.setText("AITONG\nMenino da camisa da\nflanela da crianca -...\n1.570.62MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt2.setText(Integer.toString(quant));
	        	
	        	Image x3 = new Image("biblioteca/camisaC3.png");
				image3.setImage(x3);
				lab3.setText("Slim Fitness Fashion\nKit com 3 Camisetas\nUV Protection Infantil...\n1.133.95MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt3.setText(Integer.toString(quant));
	        	
	        	Image x4 = new Image("biblioteca/camisaC4.png");
				image4.setImage(x4);
				lab4.setText("Liga Retro\nCamisa Polo Brasil Liga\nRetro Infantil Amarela\n1.701.68MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt4.setText(Integer.toString(quant));
	        	
	        	Image x5 = new Image("biblioteca/camisaC5.png");
				image5.setImage(x5);
				lab5.setText("Generico\nSafari Zoo Branco Kit\nRoupa Conjunto...\n1.885.71MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt5.setText(Integer.toString(quant));
	        	
	        	Image x6 = new Image("biblioteca/camisaC6.png");
				image6.setImage(x6);
				lab6.setText("Disney\nConjunto de Camisa de\nmanga comprida e...\n3.193.47MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt6.setText(Integer.toString(quant));
			}
			
			
		}else if(txtpesquisa.getText().equalsIgnoreCase("Calcas") || txtpesquisa.getText().equalsIgnoreCase("Calca") || txtpesquisa.getText().equalsIgnoreCase("Cal�a") || txtpesquisa.getText().equalsIgnoreCase("Cal�as")) {
			if(Fem.isSelected()) {
			Image x = new Image("biblioteca/calcasF1.png");
			image1.setImage(x);
			lab1.setText("Hering\nCalcas Jeans Cintura\nMedia Skinny,Hering...\n1.007.539MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt1.setText(Integer.toString(quant));
        	
        	Image x2 = new Image("biblioteca/calcasF2.png");
			image2.setImage(x2);
			lab2.setText("Luma Ventura\nKit 2 Calcas Jeans Retro\nPantalona Wide Leg...\n1.890.239MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt2.setText(Integer.toString(quant));
        	
        	Image x3 = new Image("biblioteca/calcasF3.png");
			image3.setImage(x3);
			lab3.setText("Hotlion\nCalca legging femenina\nde cintura alta para...\n1.127.7123MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt3.setText(Integer.toString(quant));
        	
        	Image x4 = new Image("biblioteca/calcasF4.png");
			image4.setImage(x4);
			lab4.setText("Fashion Jeans\nKit 3 Calcas Jeans\nFeminina Empina...\n2.646.839MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt4.setText(Integer.toString(quant));
        	
        	Image x5 = new Image("biblioteca/calcasF5.png");
			image5.setImage(x5);
			lab5.setText("Trifil\nCalca Af Legging\nMaternidade, Trifil,...\n2.711.15MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt5.setText(Integer.toString(quant));
        	
        	Image x6 = new Image("biblioteca/calcasF6.png");
			image6.setImage(x6);
			lab6.setText("Lupo\nMeia Calca Loba\nClassica Fina Fio 15...\n150.9417.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt6.setText(Integer.toString(quant));
        	
			}else if(Masc.isSelected()) {
				Image x = new Image("biblioteca/calcasM1.png");
				image1.setImage(x);
				lab1.setText("LEGBrasil\nKit 2 Calca Moletom\nCareca Masculina...\n1.752.79MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt1.setText(Integer.toString(quant));
	        	
	        	Image x2 = new Image("biblioteca/calcasM2.png");
				image2.setImage(x2);
				lab2.setText("Almix\nKit 2 Calcas Jeans\nMasculina Tradicional\n1.689.74MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt2.setText(Integer.toString(quant));
	        	
	        	Image x3 = new Image("biblioteca/calcasM3.png");
				image3.setImage(x3);
				lab3.setText("QueroShoes\nKit 2 Calcas Masculinas\nMoletom Conforto...\n1.511.939MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt3.setText(Integer.toString(quant));
	        	
	        	Image x4 = new Image("biblioteca/calcasM4.png");
				image4.setImage(x4);
				lab4.setText("Meio Swag\nCalca Cargo Jogger\nMasculina Moletom...\n1.638.039MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt4.setText(Integer.toString(quant));
	        	
	        	Image x5 = new Image("biblioteca/calcasM5.png");
				image5.setImage(x5);
				lab5.setText("Colin Denim\nCalca Jeans Masculina\nSkinny Destroyed...\n1.551.03MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt5.setText(Integer.toString(quant));
	        	
	        	Image x6 = new Image("biblioteca/calcasM6.png");
				image6.setImage(x6);
				lab6.setText("NEXSTAR\nCalca Moletom\nMasculino Cobra Kai,...\n1.133.639MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt6.setText(Integer.toString(quant));
	        	
			}else if(cri.isSelected()) {
				Image x = new Image("biblioteca/calcasC1.png");
				image1.setImage(x);
				lab1.setText("Lupo\nCalcas Lupo\n1.311.44MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt1.setText(Integer.toString(quant));
	        	
	        	Image x2 = new Image("biblioteca/calcasC2.png");
				image2.setImage(x2);
				lab2.setText("Baby Delux\nBaby Delux Calca de \nMoletom Infantil, Cin...\n600.236.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt2.setText(Integer.toString(quant));
	        	
	        	Image x3 = new Image("biblioteca/calcasC3.png");
				image3.setImage(x3);
				lab3.setText("Generic\nCalca legging infantil\nde camuflagem com...\n524.7021.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt3.setText(Integer.toString(quant));
	        	
	        	Image x4 = new Image("biblioteca/calcasC4.png");
				image4.setImage(x4);
				lab4.setText("TipTop\nCalca Em Molentinho,\nTipTop, Crianca Unisex\n1.007.539MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt4.setText(Integer.toString(quant));
	        	
	        	Image x5 = new Image("biblioteca/calcasC5.png");
				image5.setImage(x5);
				lab5.setText("Generic\nCalcas jeans para bebes\ncalcas suspensorio...\n740.7114.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt5.setText(Integer.toString(quant));
	        	
	        	Image x6 = new Image("biblioteca/calcasC6.png");
				image6.setImage(x6);
				lab6.setText("ASTORE\nCalca Segunda Pele\nADSTORE Infantil Kid\n313.998.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt6.setText(Integer.toString(quant));
			}
        	
		}else if(txtpesquisa.getText().equalsIgnoreCase("Sapato") || txtpesquisa.getText().equalsIgnoreCase("Sapatos")|| txtpesquisa.getText().equalsIgnoreCase("Sapatilhas")|| txtpesquisa.getText().equalsIgnoreCase("Sapatilha")) {
			if(Fem.isSelected()) {
				Image x = new Image("biblioteca/sapatoF1.png");
				image1.setImage(x);
				lab1.setText("Holibanna\nSapatilhas femininas\nde bico fino com glitt...\n1.603.2354MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt1.setText(Integer.toString(quant));
	        	
	        	Image x2 = new Image("biblioteca/sapatoF2.png");
				image2.setImage(x2);
				lab2.setText("Havaianas\nChinelo Slim,\nHavaianas, feminino\n250.939.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt2.setText(Integer.toString(quant));
	        	
	        	Image x3 = new Image("biblioteca/sapatoF3.png");
				image3.setImage(x3);
				lab3.setText("moleca\nSapato Sapatilha\nMoleca Casual...\n567.45.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt3.setText(Integer.toString(quant));
	        	
	        	Image x4 = new Image("biblioteca/sapatoF4.png");
				image4.setImage(x4);
				lab4.setText("Via Uno\nSapatilha Via Uno\n018292SBAVV...\n1.134.09MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt4.setText(Integer.toString(quant));
	        	
	        	Image x5 = new Image("biblioteca/sapatoF5.png");
				image5.setImage(x5);
				lab5.setText("moleca\nSapatilha Moleca\nCasual Feminino\n504.04.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt5.setText(Integer.toString(quant));
	        	
	        	Image x6 = new Image("biblioteca/sapatoF6.png");
				image6.setImage(x6);
				lab6.setText("moleca\nSapatilha Moleca\nCasual Feminino\n755.339.00MT");
				quant1=0;
	        	quant2=0;
	        	quant3=0;
	        	quant4=0;
	        	quant5=0;
	        	quant6=0;
	        	qnt6.setText(Integer.toString(quant));
	        	
				}else if(Masc.isSelected()) {
					
					Image x = new Image("biblioteca/sapatoM1.png");
					image1.setImage(x);
					lab1.setText("Skechers\nTenis Arch Fit Banline,\nSkechers, Masculino...\n5.674.05MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt1.setText(Integer.toString(quant));
		        	
		        	Image x2 = new Image("biblioteca/sapatoM2.png");
					image2.setImage(x2);
					lab2.setText("Skechers\nSapatilha Go Walk Max,\nSkechers, Masculino\n2.394.7651MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt2.setText(Integer.toString(quant));
		        	
		        	Image x3 = new Image("biblioteca/sapatoM3.png");
					image3.setImage(x3);
					lab3.setText("Kit Shoes\nSapatilha Nautica\nHibrida Treino Ciclismo..\n1.259.739MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt3.setText(Integer.toString(quant));
		        	
		        	Image x4 = new Image("biblioteca/sapatoM4.png");
					image4.setImage(x4);
					lab4.setText("Nortenhos Shoes\nKit 3 Pares Mocassim\nDrive Sapatilha...\n1.511.938MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt4.setText(Integer.toString(quant));
		        	
		        	Image x5 = new Image("biblioteca/sapatoM5.png");
					image5.setImage(x5);
					lab5.setText("Algarte Shoes\nSapatilha Neoprene\nAquatica Tenis HIbrid...\n1.133.639MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt5.setText(Integer.toString(quant));
		        	
		        	Image x6 = new Image("biblioteca/sapatoM6.png");
					image6.setImage(x6);
					lab6.setText("Cardume\nTenis Anfibius -\nCardume Adventures\n2.230.709MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt6.setText(Integer.toString(quant));
					
				}else if(cri.isSelected()) {
					
					Image x = new Image("biblioteca/sapatoC1.png");
					image1.setImage(x);
					lab1.setText("Grendene Kids\nSapatilha Disney\nPrincesas Royal,...\n418.0215.00MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt1.setText(Integer.toString(quant));
		        	
		        	Image x2 = new Image("biblioteca/sapatoC2.png");
					image2.setImage(x2);
					lab2.setText("EXCERAT\nSapatilhas de bale\nEXCERAT Sapatos de...\n1.778.01MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt2.setText(Integer.toString(quant));
		        	
		        	Image x3 = new Image("biblioteca/sapatoC3.png");
					image3.setImage(x3);
					lab3.setText("generic\nSapatos de verao do\nbebe - Sapatos infant...\n1.500.00MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt3.setText(Integer.toString(quant));
		        	
		        	Image x4 = new Image("biblioteca/sapatoC4.png");
					image4.setImage(x4);
					lab4.setText("Adidas\nTenis de Corrida Unissex\nInfantil Racer Tr 2.0\n6.241.3195MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt4.setText(Integer.toString(quant));
		        	
		        	Image x5 = new Image("biblioteca/sapatoC5.png");
					image5.setImage(x5);
					lab5.setText("Trifil\nMeias Sapatilha, Trifil,\nMeninos\n339.209.00MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt5.setText(Integer.toString(quant));
		        	
		        	Image x6 = new Image("biblioteca/sapatoC6.png");
					image6.setImage(x6);
					lab6.setText("UFrog\nSapatilha Neoprene\nUFrog Air Infantil Teia...\n1.007.539MT");
					quant1=0;
		        	quant2=0;
		        	quant3=0;
		        	quant4=0;
		        	quant5=0;
		        	quant6=0;
		        	qnt6.setText(Integer.toString(quant));
				}
		}else {
			c1.setVisible(false);
			c2.setVisible(false);
			c3.setVisible(false);
			c4.setVisible(false);
			c5.setVisible(false);
			c6.setVisible(false);
			image1.setVisible(false);
			image2.setVisible(false);
			image3.setVisible(false);
			image4.setVisible(false);
			image5.setVisible(false);
			lab1.setVisible(false);
			lab2.setVisible(false);
			lab3.setVisible(false);
			lab4.setVisible(false);
			lab5.setVisible(false);
			lab6.setVisible(false);
			qnt1.setVisible(false);
			qnt2.setVisible(false);
			qnt3.setVisible(false);
			qnt4.setVisible(false);
			qnt5.setVisible(false);
			qnt6.setVisible(false);
			tot.setVisible(false);
			totfield.setVisible(false);
			MT.setVisible(false);
			Q1.setVisible(false);
			Q2.setVisible(false);
			Q3.setVisible(false);
			Q4.setVisible(false);
			Q5.setVisible(false);
			Q6.setVisible(false);
			 labelex = new Label();
			 labelex2 = new Label();
			 bt = new Button();
			labelex.setText(txtpesquisa.getText()+" Nao existe");
			labelex2.setText("Clique no botao Abaixo para verificar no Stock");
			bt.setText("Verificar no Stock");
			labelex.setTranslateX(475);
			labelex.setTranslateY(200);
			labelex2.setTranslateX(400);
			labelex2.setTranslateY(230);
			bt.setTranslateX(470);
			bt.setTranslateY(260);
			
			bt.setStyle("-fx-font-size: 18");
			labelex.setStyle("-fx-font-size: 18");
			labelex2.setStyle("-fx-font-size: 18");
//			bt.setStyle("-fx-background-color: blue");
			anchor.getChildren().add(labelex);
			anchor.getChildren().add(labelex2);
			anchor.getChildren().add(bt);
			bt.setOnAction(new EventHandler <ActionEvent>() {
				
			public void handle(ActionEvent event) {
			 lab32 = new Label();
			 lab43 = new Label();
			lab43.setText("Procurando no Stock");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			lab32.setText("Nao foi encontrado o produto "+txtpesquisa.getText()+" no Stock");
			lab32.setTranslateX(400);
			lab32.setTranslateY(235);
			lab43.setTranslateX(475);
			lab43.setTranslateY(200);
			lab32.setStyle("-fx-font-size: 18");
			lab43.setStyle("-fx-font-size: 18");
			labelex.setVisible(false);
			labelex2.setVisible(false);
			bt.setVisible(false);
			anchor.getChildren().add(lab32);
			}
			});
		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void backAction(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("menu.fxml"));
		root = loader.load();
		
		stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	// Event Listener on Button[#c1].onAction
	 @FXML
	    void compra1Action(ActionEvent event) {
	    	quant1++;
	    	qnt1.setText(Integer.toString(quant1));
	    }

	    @FXML
	    void compra2Action(ActionEvent event) {
	    	quant2++;
	    	qnt2.setText(Integer.toString(quant2));
	    }

	    @FXML
	    void compra3Action(ActionEvent event) {
	    	quant3++;
	    	qnt3.setText(Integer.toString(quant3));
	    }

	    @FXML
	    void compra4Action(ActionEvent event) {
	    	quant4++;
	    	qnt4.setText(Integer.toString(quant4));
	    }

	    @FXML
	    void compra5Action(ActionEvent event) {
	    	quant5++;
	    	qnt5.setText(Integer.toString(quant5));
	    }

	    @FXML
	    void compra6Action(ActionEvent event) {
	    	quant6++;
	    	qnt6.setText(Integer.toString(quant6));
	    }
	// Event Listener on Button[#tot].onAction
	@FXML
	public void totAction(ActionEvent event) {
		if(txtpesquisa.getText().equalsIgnoreCase("Camisa") || txtpesquisa.getText().equalsIgnoreCase("Camisas")) {
			if(Fem.isSelected()) {
			 Vestuario v1 = new Vestuario(quant1,1621.08);
			 Vestuario v2 = new Vestuario(quant2,957.36);
			 Vestuario v3 = new Vestuario(quant3,301.46);
			 Vestuario v4 = new Vestuario(quant4,553.73);
			 Vestuario v5 = new Vestuario(quant5,503.28);
			 Vestuario v6 = new Vestuario(quant6,370.83);
			 total1=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
	   		// totfield.setText(Double.toString(total));
	   		 
			}else if(Masc.isSelected()) {
				 Vestuario v1 = new Vestuario(quant1,1816.33);
				 Vestuario v2 = new Vestuario(quant2,695.00);
				 Vestuario v3 = new Vestuario(quant3,996.46);
				 Vestuario v4 = new Vestuario(quant4,881.68);
				 Vestuario v5 = new Vestuario(quant5,2231.31);
				 Vestuario v6 = new Vestuario(quant6,1007.81);
				 total2=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
		   		// totfield.setText(Double.toString(total));
		   		 
			}else if(cri.isSelected()) {
				 Vestuario v1 = new Vestuario(quant1,2058.76);
				 Vestuario v2 = new Vestuario(quant2,1570.62);
				 Vestuario v3 = new Vestuario(quant3,1133.95);
				 Vestuario v4 = new Vestuario(quant4,1701.68);
				 Vestuario v5 = new Vestuario(quant5,1885.71);
				 Vestuario v6 = new Vestuario(quant6,3193.47);
				 total3=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
		   		// totfield.setText(Double.toString(total));
			}
			
		}else if(txtpesquisa.getText().equalsIgnoreCase("Calcas") || txtpesquisa.getText().equalsIgnoreCase("Calca") || txtpesquisa.getText().equalsIgnoreCase("Cal�a") || txtpesquisa.getText().equalsIgnoreCase("Cal�as")) {
			if(Fem.isSelected()) {
				 Vestuario v1 = new Vestuario(quant1,1007.539);
				 Vestuario v2 = new Vestuario(quant2,1890.239);
				 Vestuario v3 = new Vestuario(quant3,1127.7123);
				 Vestuario v4 = new Vestuario(quant4,2646.839);
				 Vestuario v5 = new Vestuario(quant5,2711.15);
				 Vestuario v6 = new Vestuario(quant6,150.9417);
				 total4=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
		   		// totfield.setText(Double.toString(total));
		   		 
				}else if(Masc.isSelected()) {
					 Vestuario v1 = new Vestuario(quant1,1752.79);
					 Vestuario v2 = new Vestuario(quant2,1689.74);
					 Vestuario v3 = new Vestuario(quant3,1511.939);
					 Vestuario v4 = new Vestuario(quant4,1638.039);
					 Vestuario v5 = new Vestuario(quant5,1551.03);
					 Vestuario v6 = new Vestuario(quant6,1133.639);
					 total5=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
			   		// totfield.setText(Double.toString(total));
			   		 
				}else if(cri.isSelected()) {
					 Vestuario v1 = new Vestuario(quant1,1311.44);
					 Vestuario v2 = new Vestuario(quant2,600.236);
					 Vestuario v3 = new Vestuario(quant3,524.7021);
					 Vestuario v4 = new Vestuario(quant4,1007.539);
					 Vestuario v5 = new Vestuario(quant5,740.7114);
					 Vestuario v6 = new Vestuario(quant6,313.998);
					 total6=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
			   		// totfield.setText(Double.toString(total));
				}
		}else if(txtpesquisa.getText().equalsIgnoreCase("Sapato") || txtpesquisa.getText().equalsIgnoreCase("Sapatos")|| txtpesquisa.getText().equalsIgnoreCase("Sapatilhas")|| txtpesquisa.getText().equalsIgnoreCase("Sapatilha")) {
			if(Fem.isSelected()) {
				 Vestuario v1 = new Vestuario(quant1,1603.2354);
				 Vestuario v2 = new Vestuario(quant2,250.939);
				 Vestuario v3 = new Vestuario(quant3,567.45);
				 Vestuario v4 = new Vestuario(quant4,1134.09);
				 Vestuario v5 = new Vestuario(quant5,504.04);
				 Vestuario v6 = new Vestuario(quant6,755.339);
				 total7=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
		   		// totfield.setText(Double.toString(total));
		   		 
				}else if(Masc.isSelected()) {
					 Vestuario v1 = new Vestuario(quant1,5674.05);
					 Vestuario v2 = new Vestuario(quant2,2394.7651);
					 Vestuario v3 = new Vestuario(quant3,1259.739);
					 Vestuario v4 = new Vestuario(quant4,1511.938);
					 Vestuario v5 = new Vestuario(quant5,1133.639);
					 Vestuario v6 = new Vestuario(quant6,2230.709);
					 total8=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
			   		// totfield.setText(Double.toString(total));
			   		 
				}else if(cri.isSelected()) {
					 Vestuario v1 = new Vestuario(quant1,418.0215);
					 Vestuario v2 = new Vestuario(quant2,1778.01);
					 Vestuario v3 = new Vestuario(quant3,1500.00);
					 Vestuario v4 = new Vestuario(quant4,6241.3195);
					 Vestuario v5 = new Vestuario(quant5,339.209);
					 Vestuario v6 = new Vestuario(quant6,1007.539);
					 total9=((v1.getQuantaty()*v1.getValorUten())+(v2.getQuantaty()*v2.getValorUten())+(v3.getQuantaty()*v3.getValorUten())+(v4.getQuantaty()*v4.getValorUten())+(v5.getQuantaty()*v5.getValorUten())+(v6.getQuantaty()*v6.getValorUten()));
			   		// totfield.setText(Double.toString(total));
				}
		}
			
		total = total1+total2+total3+total4+total5+total6+total7+total8+total9;
		 totfield.setText(Double.toString(total));
		 paypalPagamentoController pag = new paypalPagamentoController();
    	 CartaoController card = new CartaoController();
			card.voi(total);
		 pag.voi(total);
	}
	
	  @FXML
	    void Menos1Action(ActionEvent event) {
		  quant1--;
	    	qnt1.setText(Integer.toString(quant1));
	    }

	    @FXML
	    void Menos2Action(ActionEvent event) {
	    	quant2--;
	    	qnt2.setText(Integer.toString(quant2));
	    }

	    @FXML
	    void Menos3Action(ActionEvent event) {
	    	quant3--;
	    	qnt3.setText(Integer.toString(quant3));
	    }

	    @FXML
	    void Menos4Action(ActionEvent event) {
	    	quant4--;
	    	qnt4.setText(Integer.toString(quant4));
	    }

	    @FXML
	    void Menos5Action(ActionEvent event) {
	    	quant5--;
	    	qnt5.setText(Integer.toString(quant5));
	    }

	    @FXML
	    void Menos6Action(ActionEvent event) {
	    	quant6--;
	    	qnt6.setText(Integer.toString(quant6));
	    }
	    
	    @FXML
	    void checkoutAction(ActionEvent event) throws IOException {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Checkout.fxml"));
			root = loader.load();
			
			Stage stage2 = new Stage();
			stage2.setScene(new Scene(root));
			stage2.show();
	    }
	    
	    @FXML
	    void OnAdCarrinho1Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	 
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    	
	    	
	    
	    }

	    @FXML
	    void OnAdCarrinho2Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    	
		    	
	    	
	    }

	    @FXML
	    void OnAdCarrinho3Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho4Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho5Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho6Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }
	    
	    @FXML
	    void OnCartAction(ActionEvent event) throws IOException {
	    	
	    	if(txtpesquisa.getText().equalsIgnoreCase("Camisa") || txtpesquisa.getText().equalsIgnoreCase("Camisas")) {
				if(Fem.isSelected()) {
					 Vestuario b1 = new Vestuario(quant1,1621.08);
					 Vestuario b2 = new Vestuario(quant2,957.36);
					 Vestuario b3 = new Vestuario(quant3,301.46);
					 Vestuario b4 = new Vestuario(quant4,553.73);
					 Vestuario b5 = new Vestuario(quant5,503.28);
					 Vestuario b6 = new Vestuario(quant6,370.83);
					if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	double totAl = (b1.getValorUten()*b1.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab2.getText();
				    	Image i = image2.getImage();
				    	String quantidadeTotal = qnt2.getText();
				    	double totAl = (b2.getValorUten()*b2.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab3.getText();
				    	Image i = image3.getImage();
				    	String quantidadeTotal = qnt3.getText();
				    	
				    	double totAl = (b3.getValorUten()*b3.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab4.getText();
				    	Image i = image4.getImage();
				    	String quantidadeTotal = qnt4.getText();
				    	double totAl = (b4.getValorUten()*b4.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
			    		
			    		String txt1 = lab5.getText();
				    	Image i = image5.getImage();
				    	String quantidadeTotal = qnt5.getText();
				    	
				    	double totAl = (b5.getValorUten()*b5.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
			    		
			    		String txt1 = lab6.getText();
				    	Image i = image6.getImage();
				    	String quantidadeTotal = qnt6.getText();
				    	
				    	double totAl = (b6.getValorUten()*b6.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    	}
			    	
			    	
			    	
			    	if(quant1>=1 && quant2>=1) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	
				    	
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant1>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant6>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant5>=1 && quant6>=1){
			    		
			    		String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i5, txt5);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	 
			    	if(quant1>=1 && quant2>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i3, txt3);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant2>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	 
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
					
				}else if(Masc.isSelected()) {
					
					Vestuario b1 = new Vestuario(quant1,1816.33);
					 Vestuario b2 = new Vestuario(quant2,695.00);
					 Vestuario b3 = new Vestuario(quant3,996.46);
					 Vestuario b4 = new Vestuario(quant4,881.68);
					 Vestuario b5 = new Vestuario(quant5,2231.31);
					 Vestuario b6 = new Vestuario(quant6,1007.81);
					
					if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	double totAl = (b1.getValorUten()*b1.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab2.getText();
				    	Image i = image2.getImage();
				    	String quantidadeTotal = qnt2.getText();
				    	double totAl = (b2.getValorUten()*b2.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab3.getText();
				    	Image i = image3.getImage();
				    	String quantidadeTotal = qnt3.getText();
				    	
				    	double totAl = (b3.getValorUten()*b3.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab4.getText();
				    	Image i = image4.getImage();
				    	String quantidadeTotal = qnt4.getText();
				    	double totAl = (b4.getValorUten()*b4.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
			    		
			    		String txt1 = lab5.getText();
				    	Image i = image5.getImage();
				    	String quantidadeTotal = qnt5.getText();
				    	
				    	double totAl = (b5.getValorUten()*b5.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
			    		
			    		String txt1 = lab6.getText();
				    	Image i = image6.getImage();
				    	String quantidadeTotal = qnt6.getText();
				    	
				    	double totAl = (b6.getValorUten()*b6.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    	}
			    	
			    	
			    	
			    	if(quant1>=1 && quant2>=1) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	
				    	
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant1>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant6>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant5>=1 && quant6>=1){
			    		
			    		String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i5, txt5);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	 
			    	if(quant1>=1 && quant2>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i3, txt3);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant2>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	 
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
					
				}else if(cri.isSelected()) {
					
					 Vestuario b1 = new Vestuario(quant1,2058.76);
					 Vestuario b2 = new Vestuario(quant2,1570.62);
					 Vestuario b3 = new Vestuario(quant3,1133.95);
					 Vestuario b4 = new Vestuario(quant4,1701.68);
					 Vestuario b5 = new Vestuario(quant5,1885.71);
					 Vestuario b6 = new Vestuario(quant6,3193.47);
					
					if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	double totAl = (b1.getValorUten()*b1.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab2.getText();
				    	Image i = image2.getImage();
				    	String quantidadeTotal = qnt2.getText();
				    	double totAl = (b2.getValorUten()*b2.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab3.getText();
				    	Image i = image3.getImage();
				    	String quantidadeTotal = qnt3.getText();
				    	
				    	double totAl = (b3.getValorUten()*b3.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab4.getText();
				    	Image i = image4.getImage();
				    	String quantidadeTotal = qnt4.getText();
				    	double totAl = (b4.getValorUten()*b4.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
			    		
			    		String txt1 = lab5.getText();
				    	Image i = image5.getImage();
				    	String quantidadeTotal = qnt5.getText();
				    	
				    	double totAl = (b5.getValorUten()*b5.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
			    		
			    		String txt1 = lab6.getText();
				    	Image i = image6.getImage();
				    	String quantidadeTotal = qnt6.getText();
				    	
				    	double totAl = (b6.getValorUten()*b6.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    	}
			    	
			    	
			    	
			    	if(quant1>=1 && quant2>=1) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	
				    	
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant1>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant6>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant5>=1 && quant6>=1){
			    		
			    		String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i5, txt5);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	 
			    	if(quant1>=1 && quant2>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i3, txt3);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant2>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	 
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
				}
				
	    	}else if(txtpesquisa.getText().equalsIgnoreCase("Calcas") || txtpesquisa.getText().equalsIgnoreCase("Calca") || txtpesquisa.getText().equalsIgnoreCase("Cal�a") || txtpesquisa.getText().equalsIgnoreCase("Cal�as")) {
	    		
	    				if(Fem.isSelected()) {
	    					
	    					 Vestuario b1 = new Vestuario(quant1,1007.539);
	    					 Vestuario b2 = new Vestuario(quant2,1890.239);
	    					 Vestuario b3 = new Vestuario(quant3,1127.7123);
	    					 Vestuario b4 = new Vestuario(quant4,2646.839);
	    					 Vestuario b5 = new Vestuario(quant5,2711.15);
	    					 Vestuario b6 = new Vestuario(quant6,150.9417);
					
	    					if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    			    		String txt1 = lab1.getText();
	    				    	Image i = image1.getImage();
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	double totAl = (b1.getValorUten()*b1.getQuantaty());
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.quantaty1(quantidadeTotal);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    			    		
	    			    		String txt1 = lab2.getText();
	    				    	Image i = image2.getImage();
	    				    	String quantidadeTotal = qnt2.getText();
	    				    	double totAl = (b2.getValorUten()*b2.getQuantaty());
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.quantaty1(quantidadeTotal);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    			    		
	    			    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    			    		
	    			    		String txt1 = lab3.getText();
	    				    	Image i = image3.getImage();
	    				    	String quantidadeTotal = qnt3.getText();
	    				    	
	    				    	double totAl = (b3.getValorUten()*b3.getQuantaty());
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.quantaty1(quantidadeTotal);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    			    		
	    			    		String txt1 = lab4.getText();
	    				    	Image i = image4.getImage();
	    				    	String quantidadeTotal = qnt4.getText();
	    				    	double totAl = (b4.getValorUten()*b4.getQuantaty());
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.quantaty1(quantidadeTotal);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    			    		
	    			    		String txt1 = lab5.getText();
	    				    	Image i = image5.getImage();
	    				    	String quantidadeTotal = qnt5.getText();
	    				    	
	    				    	double totAl = (b5.getValorUten()*b5.getQuantaty());
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.quantaty1(quantidadeTotal);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    			    		
	    			    		String txt1 = lab6.getText();
	    				    	Image i = image6.getImage();
	    				    	String quantidadeTotal = qnt6.getText();
	    				    	
	    				    	double totAl = (b6.getValorUten()*b6.getQuantaty());
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.quantaty1(quantidadeTotal);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    			    	}
	    			    	
	    			    	
	    			    	
	    			    	if(quant1>=1 && quant2>=1) {
	    			    		String txt1 = lab1.getText();
	    				    	Image i = image1.getImage();
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	
	    				    	
	    				    	String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.imagemteste2(i2, txt2);
	    				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant3>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i = image1.getImage();
	    				    	
	    				    	String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.imagemteste2(i3, txt3);
	    				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    			    		
	    			    	}else if(quant1>=1 && quant4>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i = image1.getImage();
	    				    	
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.imagemteste2(i4, txt4);
	    				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant5>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i = image1.getImage();
	    				    	
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.imagemteste2(i5, txt5);
	    				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant6>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i = image1.getImage();
	    				    	
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i, txt1);
	    				    	carrinho.imagemteste2(i6, txt6);
	    				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant2>=1 && quant3>=1){
	    			    		
	    			    		String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	 
	    				    	String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i2, txt2);
	    				    	carrinho.imagemteste2(i3, txt3);
	    				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant2>=1 && quant4>=1){
	    			    		
	    			    		String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	 
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i2, txt2);
	    				    	carrinho.imagemteste2(i4, txt4);
	    				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant2>=1 && quant5>=1){
	    			    		
	    			    		String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	 
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	 
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i2, txt2);
	    				    	carrinho.imagemteste2(i5, txt5);
	    				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant2>=1 && quant6>=1){
	    			    		
	    			    		String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	 
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i2, txt2);
	    				    	carrinho.imagemteste2(i6, txt6);
	    				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant3>=1 && quant4>=1){
	    			    		
	    			    		String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	 
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i3, txt3);
	    				    	carrinho.imagemteste2(i4, txt4);
	    				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant3>=1 && quant5>=1){
	    			    		
	    			    		String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	 
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i3, txt3);
	    				    	carrinho.imagemteste2(i5, txt5);
	    				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant3>=1 && quant6>=1){
	    			    		
	    			    		String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	 
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i3, txt3);
	    				    	carrinho.imagemteste2(i6, txt6);
	    				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant4>=1 && quant5>=1){
	    			    		
	    			    		String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	 
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i4, txt4);
	    				    	carrinho.imagemteste2(i5, txt5);
	    				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant4>=1 && quant6>=1){
	    			    		
	    			    		String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	 
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i4, txt4);
	    				    	carrinho.imagemteste2(i6, txt6);
	    				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant5>=1 && quant6>=1){
	    			    		
	    			    		String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	 
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i5, txt5);
	    				    	carrinho.imagemteste2(i6, txt6);
	    				    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	 
	    			    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	
	    				    	String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i2, txt2);
	    				    	carrinho.imagemteste3(i3, txt3);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i4, txt4);
	    				    	carrinho.imagemteste3(i5, txt5);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i2, txt2);
	    				    	carrinho.imagemteste3(i6, txt6);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i3, txt3);
	    				    	carrinho.imagemteste3(i6, txt6);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i4, txt4);
	    				    	carrinho.imagemteste3(i6, txt6);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i5, txt5);
	    				    	carrinho.imagemteste3(i6, txt6);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	 
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i2, txt2);
	    				    	carrinho.imagemteste3(i4, txt4);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i2, txt2);
	    				    	carrinho.imagemteste3(i5, txt5);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i3, txt3);
	    				    	carrinho.imagemteste3(i4, txt4);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    			    		
	    			    		String txt1 = lab1.getText();
	    				    	Image i1 = image1.getImage();
	    				    	 
	    				    	String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String quantidadeTotal = qnt1.getText();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i1, txt1);
	    				    	carrinho.imagemteste2(i3, txt3);
	    				    	carrinho.imagemteste3(i5, txt5);
	    				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    			    		
	    			    		String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	 
	    				    	String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	 
	    				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i2, txt2);
	    				    	carrinho.imagemteste2(i3, txt3);
	    				    	carrinho.imagemteste3(i4, txt4);
	    				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    			    		
	    			    		String txt2 = lab2.getText();
	    				    	Image i2 = image2.getImage();
	    				    	 
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal2 = qnt2.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i2, txt2);
	    				    	carrinho.imagemteste2(i5, txt5);
	    				    	carrinho.imagemteste3(i6, txt6);
	    				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    			    		
	    			    		String txt3 = lab3.getText();
	    				    	Image i3 = image3.getImage();
	    				    	 
	    				    	String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String quantidadeTotal3 = qnt3.getText();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i3, txt3);
	    				    	carrinho.imagemteste2(i4, txt4);
	    				    	carrinho.imagemteste3(i5, txt5);
	    				    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
	    			    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    			    		
	    			    		String txt4 = lab4.getText();
	    				    	Image i4 = image4.getImage();
	    				    	 
	    				    	String txt5 = lab5.getText();
	    				    	Image i5 = image5.getImage();
	    				    	
	    				    	String txt6 = lab6.getText();
	    				    	Image i6 = image6.getImage();
	    				    	
	    				    	String quantidadeTotal4 = qnt4.getText();
	    				    	
	    				    	String quantidadeTotal5 = qnt5.getText();
	    				    	
	    				    	String quantidadeTotal6 = qnt6.getText();
	    				    	
	    				    	
	    				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    				    	Double.toString(totAl);
	    						String valor = String.format("%.2f",totAl);
	    				    	 
	    				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    				    	root = loader.load();
	    				    	
	    				    	CarrinhoController carrinho = loader.getController();
	    				    	carrinho.imagemteste(i4, txt4);
	    				    	carrinho.imagemteste2(i5, txt5);
	    				    	carrinho.imagemteste3(i6, txt6);
	    				    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
	    				    	carrinho.TotalApagar(valor);
	    				    	
	    				    	Stage stage2 = new Stage();
	    				    	Scene scene = new Scene(root);
	    				    	stage2.setScene(scene);
	    				    	stage2.show();
	    				    	
	    			    	}
	    			    	
					
				}else if(Masc.isSelected()) {
					
					 Vestuario b1 = new Vestuario(quant1,1752.79);
					 Vestuario b2 = new Vestuario(quant2,1689.74);
					 Vestuario b3 = new Vestuario(quant3,1511.939);
					 Vestuario b4 = new Vestuario(quant4,1638.039);
					 Vestuario b5 = new Vestuario(quant5,1551.03);
					 Vestuario b6 = new Vestuario(quant6,1133.639);
					
					if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	double totAl = (b1.getValorUten()*b1.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab2.getText();
				    	Image i = image2.getImage();
				    	String quantidadeTotal = qnt2.getText();
				    	double totAl = (b2.getValorUten()*b2.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab3.getText();
				    	Image i = image3.getImage();
				    	String quantidadeTotal = qnt3.getText();
				    	
				    	double totAl = (b3.getValorUten()*b3.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab4.getText();
				    	Image i = image4.getImage();
				    	String quantidadeTotal = qnt4.getText();
				    	double totAl = (b4.getValorUten()*b4.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
			    		
			    		String txt1 = lab5.getText();
				    	Image i = image5.getImage();
				    	String quantidadeTotal = qnt5.getText();
				    	
				    	double totAl = (b5.getValorUten()*b5.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
			    		
			    		String txt1 = lab6.getText();
				    	Image i = image6.getImage();
				    	String quantidadeTotal = qnt6.getText();
				    	
				    	double totAl = (b6.getValorUten()*b6.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    	}
			    	
			    	
			    	
			    	if(quant1>=1 && quant2>=1) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	
				    	
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant1>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant6>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant5>=1 && quant6>=1){
			    		
			    		String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i5, txt5);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	 
			    	if(quant1>=1 && quant2>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i3, txt3);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant2>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	 
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
					
				}else if(cri.isSelected()) {
					
					 Vestuario b1 = new Vestuario(quant1,1311.44);
					 Vestuario b2 = new Vestuario(quant2,600.236);
					 Vestuario b3 = new Vestuario(quant3,524.7021);
					 Vestuario b4 = new Vestuario(quant4,1007.539);
					 Vestuario b5 = new Vestuario(quant5,740.7114);
					 Vestuario b6 = new Vestuario(quant6,313.998);
					
					if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	double totAl = (b1.getValorUten()*b1.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab2.getText();
				    	Image i = image2.getImage();
				    	String quantidadeTotal = qnt2.getText();
				    	double totAl = (b2.getValorUten()*b2.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab3.getText();
				    	Image i = image3.getImage();
				    	String quantidadeTotal = qnt3.getText();
				    	
				    	double totAl = (b3.getValorUten()*b3.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
			    		
			    		String txt1 = lab4.getText();
				    	Image i = image4.getImage();
				    	String quantidadeTotal = qnt4.getText();
				    	double totAl = (b4.getValorUten()*b4.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
			    		
			    		String txt1 = lab5.getText();
				    	Image i = image5.getImage();
				    	String quantidadeTotal = qnt5.getText();
				    	
				    	double totAl = (b5.getValorUten()*b5.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
			    		
			    		String txt1 = lab6.getText();
				    	Image i = image6.getImage();
				    	String quantidadeTotal = qnt6.getText();
				    	
				    	double totAl = (b6.getValorUten()*b6.getQuantaty());
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.quantaty1(quantidadeTotal);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    	}
			    	
			    	
			    	
			    	if(quant1>=1 && quant2>=1) {
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	
				    	
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
			    		
			    	}else if(quant1>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i = image1.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i, txt1);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant3>=1 && quant6>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant4>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant5>=1 && quant6>=1){
			    		
			    		String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	 
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i5, txt5);
				    	carrinho.imagemteste2(i6, txt6);
				    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	 
			    	if(quant1>=1 && quant2>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i3, txt3);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant2>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i2, txt2);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant1>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
			    		
			    		String txt1 = lab1.getText();
				    	Image i1 = image1.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal = qnt1.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i1, txt1);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant2>=1 && quant3>=1 && quant4>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	 
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i3, txt3);
				    	carrinho.imagemteste3(i4, txt4);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt2 = lab2.getText();
				    	Image i2 = image2.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal2 = qnt2.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i2, txt2);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant3>=1 && quant4>=1 && quant5>=1){
			    		
			    		String txt3 = lab3.getText();
				    	Image i3 = image3.getImage();
				    	 
				    	String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String quantidadeTotal3 = qnt3.getText();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	
				    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i3, txt3);
				    	carrinho.imagemteste2(i4, txt4);
				    	carrinho.imagemteste3(i5, txt5);
				    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
			    	if(quant4>=1 && quant5>=1 && quant6>=1){
			    		
			    		String txt4 = lab4.getText();
				    	Image i4 = image4.getImage();
				    	 
				    	String txt5 = lab5.getText();
				    	Image i5 = image5.getImage();
				    	
				    	String txt6 = lab6.getText();
				    	Image i6 = image6.getImage();
				    	
				    	String quantidadeTotal4 = qnt4.getText();
				    	
				    	String quantidadeTotal5 = qnt5.getText();
				    	
				    	String quantidadeTotal6 = qnt6.getText();
				    	
				    	
				    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
				    	Double.toString(totAl);
						String valor = String.format("%.2f",totAl);
				    	 
				    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
				    	root = loader.load();
				    	
				    	CarrinhoController carrinho = loader.getController();
				    	carrinho.imagemteste(i4, txt4);
				    	carrinho.imagemteste2(i5, txt5);
				    	carrinho.imagemteste3(i6, txt6);
				    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
				    	carrinho.TotalApagar(valor);
				    	
				    	Stage stage2 = new Stage();
				    	Scene scene = new Scene(root);
				    	stage2.setScene(scene);
				    	stage2.show();
				    	
			    	}
			    	
				}
	    				
	    	}else if(txtpesquisa.getText().equalsIgnoreCase("Sapato") || txtpesquisa.getText().equalsIgnoreCase("Sapatos")|| txtpesquisa.getText().equalsIgnoreCase("Sapatilhas")|| txtpesquisa.getText().equalsIgnoreCase("Sapatilha")) {
	    		
	    		
			    	Sapato();
				
			    	}
	    	}
	    
	    
	    public  void Sapato() throws IOException {
	    	
	    	if(Fem.isSelected()) {
	    		
	    		 Vestuario b1 = new Vestuario(quant1,1603.2354);
	    		 Vestuario b2 = new Vestuario(quant2,250.939);
	    		 Vestuario b3 = new Vestuario(quant3,567.45);
	    		 Vestuario b4 = new Vestuario(quant4,1134.09);
	    		 Vestuario b5 = new Vestuario(quant5,504.04);
	    		 Vestuario b6 = new Vestuario(quant6,755.339);
	    						
	    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    			String txt1 = lab1.getText();
	    	    	Image i = image1.getImage();
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	double totAl = (b1.getValorUten()*b1.getQuantaty());
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.quantaty1(quantidadeTotal);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    			
	    			String txt1 = lab2.getText();
	    	    	Image i = image2.getImage();
	    	    	String quantidadeTotal = qnt2.getText();
	    	    	double totAl = (b2.getValorUten()*b2.getQuantaty());
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.quantaty1(quantidadeTotal);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    			
	    		}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    			
	    			String txt1 = lab3.getText();
	    	    	Image i = image3.getImage();
	    	    	String quantidadeTotal = qnt3.getText();
	    	    	
	    	    	double totAl = (b3.getValorUten()*b3.getQuantaty());
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.quantaty1(quantidadeTotal);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    			
	    			String txt1 = lab4.getText();
	    	    	Image i = image4.getImage();
	    	    	String quantidadeTotal = qnt4.getText();
	    	    	double totAl = (b4.getValorUten()*b4.getQuantaty());
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.quantaty1(quantidadeTotal);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    			
	    			String txt1 = lab5.getText();
	    	    	Image i = image5.getImage();
	    	    	String quantidadeTotal = qnt5.getText();
	    	    	
	    	    	double totAl = (b5.getValorUten()*b5.getQuantaty());
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.quantaty1(quantidadeTotal);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    			
	    			String txt1 = lab6.getText();
	    	    	Image i = image6.getImage();
	    	    	String quantidadeTotal = qnt6.getText();
	    	    	
	    	    	double totAl = (b6.getValorUten()*b6.getQuantaty());
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.quantaty1(quantidadeTotal);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    		}
	    		
	    		
	    		
	    		if(quant1>=1 && quant2>=1) {
	    			String txt1 = lab1.getText();
	    	    	Image i = image1.getImage();
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	
	    	    	
	    	    	String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.imagemteste2(i2, txt2);
	    	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant3>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i = image1.getImage();
	    	    	
	    	    	String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.imagemteste2(i3, txt3);
	    	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    			
	    		}else if(quant1>=1 && quant4>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i = image1.getImage();
	    	    	
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.imagemteste2(i4, txt4);
	    	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant5>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i = image1.getImage();
	    	    	
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.imagemteste2(i5, txt5);
	    	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant6>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i = image1.getImage();
	    	    	
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i, txt1);
	    	    	carrinho.imagemteste2(i6, txt6);
	    	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    		
	    		if(quant2>=1 && quant3>=1){
	    			
	    			String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	 
	    	    	String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i2, txt2);
	    	    	carrinho.imagemteste2(i3, txt3);
	    	    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant2>=1 && quant4>=1){
	    			
	    			String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	 
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i2, txt2);
	    	    	carrinho.imagemteste2(i4, txt4);
	    	    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant2>=1 && quant5>=1){
	    			
	    			String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	 
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	 
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i2, txt2);
	    	    	carrinho.imagemteste2(i5, txt5);
	    	    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant2>=1 && quant6>=1){
	    			
	    			String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	 
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i2, txt2);
	    	    	carrinho.imagemteste2(i6, txt6);
	    	    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    		
	    		if(quant3>=1 && quant4>=1){
	    			
	    			String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	 
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i3, txt3);
	    	    	carrinho.imagemteste2(i4, txt4);
	    	    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant3>=1 && quant5>=1){
	    			
	    			String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	 
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i3, txt3);
	    	    	carrinho.imagemteste2(i5, txt5);
	    	    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant3>=1 && quant6>=1){
	    			
	    			String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	 
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i3, txt3);
	    	    	carrinho.imagemteste2(i6, txt6);
	    	    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    		
	    		if(quant4>=1 && quant5>=1){
	    			
	    			String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	 
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i4, txt4);
	    	    	carrinho.imagemteste2(i5, txt5);
	    	    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant4>=1 && quant6>=1){
	    			
	    			String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	 
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i4, txt4);
	    	    	carrinho.imagemteste2(i6, txt6);
	    	    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    		
	    		if(quant5>=1 && quant6>=1){
	    			
	    			String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	 
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i5, txt5);
	    	    	carrinho.imagemteste2(i6, txt6);
	    	    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    		 
	    		if(quant1>=1 && quant2>=1 && quant3>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	
	    	    	String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i2, txt2);
	    	    	carrinho.imagemteste3(i3, txt3);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i4, txt4);
	    	    	carrinho.imagemteste3(i5, txt5);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i2, txt2);
	    	    	carrinho.imagemteste3(i6, txt6);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i3, txt3);
	    	    	carrinho.imagemteste3(i6, txt6);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i4, txt4);
	    	    	carrinho.imagemteste3(i6, txt6);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i5, txt5);
	    	    	carrinho.imagemteste3(i6, txt6);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    		
	    		if(quant1>=1 && quant2>=1 && quant4>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	 
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i2, txt2);
	    	    	carrinho.imagemteste3(i4, txt4);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i2, txt2);
	    	    	carrinho.imagemteste3(i5, txt5);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    		
	    		if(quant1>=1 && quant3>=1 && quant4>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	
	    	    	String quantidadeTotal = qnt1.getText();
	    	    
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i3, txt3);
	    	    	carrinho.imagemteste3(i4, txt4);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    			
	    			String txt1 = lab1.getText();
	    	    	Image i1 = image1.getImage();
	    	    	 
	    	    	String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	String quantidadeTotal = qnt1.getText();
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	 
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i1, txt1);
	    	    	carrinho.imagemteste2(i3, txt3);
	    	    	carrinho.imagemteste3(i5, txt5);
	    	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    		
	    		if(quant2>=1 && quant3>=1 && quant4>=1){
	    			
	    			String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	 
	    	    	String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	
	    	    	 
	    	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i2, txt2);
	    	    	carrinho.imagemteste2(i3, txt3);
	    	    	carrinho.imagemteste3(i4, txt4);
	    	    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
	    	    	carrinho.TotalApagar(valor);
	    	    	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    			String txt2 = lab2.getText();
	    	    	Image i2 = image2.getImage();
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	String quantidadeTotal2 = qnt2.getText();
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	String quantidadeTotal6 = qnt6.getText();	
	    	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i2, txt2);
	    	    	carrinho.imagemteste2(i5, txt5);
	    	    	carrinho.imagemteste3(i6, txt6);
	    	    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();	
	    		}
	    		if(quant3>=1 && quant4>=1 && quant5>=1){
	    			String txt3 = lab3.getText();
	    	    	Image i3 = image3.getImage();
	    	    	String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	String quantidadeTotal3 = qnt3.getText();
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i3, txt3);
	    	    	carrinho.imagemteste2(i4, txt4);
	    	    	carrinho.imagemteste3(i5, txt5);
	    	    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
	    	    	carrinho.TotalApagar(valor);
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();	
	    		}
	    		if(quant4>=1 && quant5>=1 && quant6>=1){
	    			String txt4 = lab4.getText();
	    	    	Image i4 = image4.getImage();
	    	    	String txt5 = lab5.getText();
	    	    	Image i5 = image5.getImage();
	    	    	String txt6 = lab6.getText();
	    	    	Image i6 = image6.getImage();
	    	    	String quantidadeTotal4 = qnt4.getText();
	    	    	String quantidadeTotal5 = qnt5.getText();
	    	    	String quantidadeTotal6 = qnt6.getText();
	    	    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	    	Double.toString(totAl);
	    			String valor = String.format("%.2f",totAl);
	    	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	    	root = loader.load();
	    	    	CarrinhoController carrinho = loader.getController();
	    	    	carrinho.imagemteste(i4, txt4);
	    	    	carrinho.imagemteste2(i5, txt5);
	    	    	carrinho.imagemteste3(i6, txt6);
	    	    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
	    	    	carrinho.TotalApagar(valor);	
	    	    	Stage stage2 = new Stage();
	    	    	Scene scene = new Scene(root);
	    	    	stage2.setScene(scene);
	    	    	stage2.show();
	    	    	
	    		}
	    						
	    					}else if(Masc.isSelected()) {
	    						
	    						 Vestuario b1 = new Vestuario(quant1,5674.05);
	    						 Vestuario b2 = new Vestuario(quant2,2394.7651);
	    						 Vestuario b3 = new Vestuario(quant3,1259.739);
	    						 Vestuario b4 = new Vestuario(quant4,1511.938);
	    						 Vestuario b5 = new Vestuario(quant5,1133.639);
	    						 Vestuario b6 = new Vestuario(quant6,2230.709);
	    						
	    						if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	double totAl = (b1.getValorUten()*b1.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    				    		
	    				    		String txt1 = lab2.getText();
	    					    	Image i = image2.getImage();
	    					    	String quantidadeTotal = qnt2.getText();
	    					    	double totAl = (b2.getValorUten()*b2.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    				    		
	    				    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    				    		
	    				    		String txt1 = lab3.getText();
	    					    	Image i = image3.getImage();
	    					    	String quantidadeTotal = qnt3.getText();
	    					    	
	    					    	double totAl = (b3.getValorUten()*b3.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    				    		
	    				    		String txt1 = lab4.getText();
	    					    	Image i = image4.getImage();
	    					    	String quantidadeTotal = qnt4.getText();
	    					    	double totAl = (b4.getValorUten()*b4.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    				    		
	    				    		String txt1 = lab5.getText();
	    					    	Image i = image5.getImage();
	    					    	String quantidadeTotal = qnt5.getText();
	    					    	
	    					    	double totAl = (b5.getValorUten()*b5.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    				    		
	    				    		String txt1 = lab6.getText();
	    					    	Image i = image6.getImage();
	    					    	String quantidadeTotal = qnt6.getText();
	    					    	
	    					    	double totAl = (b6.getValorUten()*b6.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    				    	}
	    				    	
	    				    	
	    				    	
	    				    	if(quant1>=1 && quant2>=1) {
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	
	    					    	
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant3>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    				    		
	    				    	}else if(quant1>=1 && quant4>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant2>=1 && quant3>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant4>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant5>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	 
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant6>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant3>=1 && quant4>=1){
	    				    		
	    				    		String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i3, txt3);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant3>=1 && quant5>=1){
	    				    		
	    				    		String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i3, txt3);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant3>=1 && quant6>=1){
	    				    		
	    				    		String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	 
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i3, txt3);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant4>=1 && quant5>=1){
	    				    		
	    				    		String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i4, txt4);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant4>=1 && quant6>=1){
	    				    		
	    				    		String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	 
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i4, txt4);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant5>=1 && quant6>=1){
	    				    		
	    				    		String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	 
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i5, txt5);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	 
	    				    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.imagemteste3(i3, txt3);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.imagemteste3(i5, txt5);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	 
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.imagemteste3(i4, txt4);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.imagemteste3(i5, txt5);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.imagemteste3(i4, txt4);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.imagemteste3(i5, txt5);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	 
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.imagemteste3(i4, txt4);
	    					    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    				    		
	    				    		String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i3, txt3);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.imagemteste3(i5, txt5);
	    					    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    				    		
	    				    		String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i4, txt4);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    						
	    					}else if(cri.isSelected()) {
	    						
	    						 Vestuario b1 = new Vestuario(quant1,418.0215);
	    						 Vestuario b2 = new Vestuario(quant2,1778.01);
	    						 Vestuario b3 = new Vestuario(quant3,1500.00);
	    						 Vestuario b4 = new Vestuario(quant4,6241.3195);
	    						 Vestuario b5 = new Vestuario(quant5,339.209);
	    						 Vestuario b6 = new Vestuario(quant6,1007.539);
	    						
	    						if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	double totAl = (b1.getValorUten()*b1.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    				    		
	    				    		String txt1 = lab2.getText();
	    					    	Image i = image2.getImage();
	    					    	String quantidadeTotal = qnt2.getText();
	    					    	double totAl = (b2.getValorUten()*b2.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    				    		
	    				    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    				    		
	    				    		String txt1 = lab3.getText();
	    					    	Image i = image3.getImage();
	    					    	String quantidadeTotal = qnt3.getText();
	    					    	
	    					    	double totAl = (b3.getValorUten()*b3.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    				    		
	    				    		String txt1 = lab4.getText();
	    					    	Image i = image4.getImage();
	    					    	String quantidadeTotal = qnt4.getText();
	    					    	double totAl = (b4.getValorUten()*b4.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    				    		
	    				    		String txt1 = lab5.getText();
	    					    	Image i = image5.getImage();
	    					    	String quantidadeTotal = qnt5.getText();
	    					    	
	    					    	double totAl = (b5.getValorUten()*b5.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    				    		
	    				    		String txt1 = lab6.getText();
	    					    	Image i = image6.getImage();
	    					    	String quantidadeTotal = qnt6.getText();
	    					    	
	    					    	double totAl = (b6.getValorUten()*b6.getQuantaty());
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.quantaty1(quantidadeTotal);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    				    	}
	    				    	
	    				    	
	    				    	
	    				    	if(quant1>=1 && quant2>=1) {
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	
	    					    	
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant3>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    				    		
	    				    	}else if(quant1>=1 && quant4>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i = image1.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i, txt1);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant2>=1 && quant3>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant4>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant5>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	 
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant6>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant3>=1 && quant4>=1){
	    				    		
	    				    		String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i3, txt3);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant3>=1 && quant5>=1){
	    				    		
	    				    		String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i3, txt3);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant3>=1 && quant6>=1){
	    				    		
	    				    		String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	 
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i3, txt3);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant4>=1 && quant5>=1){
	    				    		
	    				    		String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i4, txt4);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant4>=1 && quant6>=1){
	    				    		
	    				    		String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	 
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i4, txt4);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant5>=1 && quant6>=1){
	    				    		
	    				    		String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	 
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i5, txt5);
	    					    	carrinho.imagemteste2(i6, txt6);
	    					    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	 
	    				    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.imagemteste3(i3, txt3);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.imagemteste3(i5, txt5);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	 
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.imagemteste3(i4, txt4);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i2, txt2);
	    					    	carrinho.imagemteste3(i5, txt5);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.imagemteste3(i4, txt4);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    				    		
	    				    		String txt1 = lab1.getText();
	    					    	Image i1 = image1.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal = qnt1.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i1, txt1);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.imagemteste3(i5, txt5);
	    					    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	 
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i3, txt3);
	    					    	carrinho.imagemteste3(i4, txt4);
	    					    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    				    		
	    				    		String txt2 = lab2.getText();
	    					    	Image i2 = image2.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal2 = qnt2.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i2, txt2);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    				    		
	    				    		String txt3 = lab3.getText();
	    					    	Image i3 = image3.getImage();
	    					    	 
	    					    	String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String quantidadeTotal3 = qnt3.getText();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i3, txt3);
	    					    	carrinho.imagemteste2(i4, txt4);
	    					    	carrinho.imagemteste3(i5, txt5);
	    					    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    				    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    				    		
	    				    		String txt4 = lab4.getText();
	    					    	Image i4 = image4.getImage();
	    					    	 
	    					    	String txt5 = lab5.getText();
	    					    	Image i5 = image5.getImage();
	    					    	
	    					    	String txt6 = lab6.getText();
	    					    	Image i6 = image6.getImage();
	    					    	
	    					    	String quantidadeTotal4 = qnt4.getText();
	    					    	
	    					    	String quantidadeTotal5 = qnt5.getText();
	    					    	
	    					    	String quantidadeTotal6 = qnt6.getText();
	    					    	
	    					    	
	    					    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    					    	Double.toString(totAl);
	    							String valor = String.format("%.2f",totAl);
	    					    	 
	    					    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    					    	root = loader.load();
	    					    	
	    					    	CarrinhoController carrinho = loader.getController();
	    					    	carrinho.imagemteste(i4, txt4);
	    					    	carrinho.imagemteste2(i5, txt5);
	    					    	carrinho.imagemteste3(i6, txt6);
	    					    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
	    					    	carrinho.TotalApagar(valor);
	    					    	
	    					    	Stage stage2 = new Stage();
	    					    	Scene scene = new Scene(root);
	    					    	stage2.setScene(scene);
	    					    	stage2.show();
	    					    	
	    				    	}
	    				    	
	    					}
	    	
	    	
	    }
}
