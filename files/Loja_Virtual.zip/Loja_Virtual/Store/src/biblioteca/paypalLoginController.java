package biblioteca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;

public class paypalLoginController implements Initializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;
	
	   @FXML
	    private TextField txtUsername;
	   
	   @FXML
	    private ToggleButton PassButton;

	    @FXML
	    private Label ShownPass;

	    @FXML
	    private Label passShow;
	  
	    @FXML
	    private PasswordField PassField;
	   
	  

	// Event Listener on Button.onAction
	@FXML
	public void OnLogAction(ActionEvent event) throws IOException {
		String username = txtUsername.getText();
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("paypalPagamento.fxml"));
    	root = loader.load();
    	
    	
    	paypalPagamentoController pay = loader.getController();
    	pay.nome(username);
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.setScene(scene);
    	stage.show();
	}
	
	   @FXML
	    void OnShowHideAction(ActionEvent event) {
		   
		   if(PassButton.isSelected()) {
	    		passShow.setVisible(true);
	    		ShownPass.setVisible(true);
	    		ShownPass.textProperty().bind(Bindings.concat(PassField.getText()));
	    		PassButton.setText("Hide");
	    	}else {
	    		passShow.setVisible(false);
	    		ShownPass.setVisible(false);
	    		PassButton.setText("Show");
	    	}
		   
	    }

	    @FXML
	    void PasswordType(KeyEvent event) {
	    	
	    	  ShownPass.textProperty().bind(Bindings.concat(PassField.getText()));
	    	
	    }

		public void initialize(URL arg0, ResourceBundle arg1) {
			passShow.setVisible(false);
    		ShownPass.setVisible(false);
			
		}
	    
	    

	
}
