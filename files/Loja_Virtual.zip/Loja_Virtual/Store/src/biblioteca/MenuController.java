package biblioteca;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class MenuController implements Initializable{
	private Parent root;
	private Stage stage;
	private Scene scene;
	
	public static Button primCarr;
	
	public static void setCarrinhoValue(String txt) {
		 primCarr.setText(txt);
	}
	public static  String getCarrinhoValue() {
		 return primCarr.getText();
	}
	
	
	
	
	
	  @FXML
	    private  Button carrinho;
	  
	 
	  
	  @FXML
	    private ImageView MyImage;
	  
	 
	  
	 

	    @FXML
	    void OnCarrinhoAction(ActionEvent event) throws IOException {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	Image x = new Image("biblioteca/shopping-cart.png");
			stage2.getIcons().add(x);
	    	stage2.show();
	    	}

    @FXML
    void brinqAction(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Brinquedos.fxml"));
    	root = loader.load();
    	
//    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
//    	scene = new Scene(root);
//    	stage.setScene(scene);
//    	stage.show();
    	Stage stage2 = new Stage();
    	Scene scene = new Scene(root);
    	stage2.setScene(scene);
    	Image x = new Image("biblioteca/shopping-cart.png");
		stage2.getIcons().add(x);
    	stage2.show();
    	
    }

    @FXML
    void electroAction(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Electrodomesticos.fxml"));
    	root = loader.load();
    	
    	Stage stage2 = new Stage();
    	Scene scene = new Scene(root);
    	stage2.setScene(scene);
    	Image x = new Image("biblioteca/shopping-cart.png");
		stage2.getIcons().add(x);
    	stage2.show();
    }

    @FXML
    void floresAction(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Flores.fxml"));
    	root = loader.load();
    	
    	Stage stage2 = new Stage();
    	Scene scene = new Scene(root);
    	stage2.setScene(scene);
    	Image x = new Image("biblioteca/shopping-cart.png");
		stage2.getIcons().add(x);
    	stage2.show();
    }

    @FXML
    void utensiliosAction(ActionEvent event) {
    	try {
    		
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("Utensilios.fxml"));
    		root = loader.load();
    		
    		Stage stage2 = new Stage();
        	Scene scene = new Scene(root);
        	stage2.setScene(scene);
        	Image x = new Image("biblioteca/shopping-cart.png");
			stage2.getIcons().add(x);
        	stage2.show();
    		
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }

    @FXML
    void vestAction(ActionEvent event) {
    	try {
    		
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("Vestuario.fxml"));
    		root = loader.load();
    		
    		Stage stage2 = new Stage();
        	Scene scene = new Scene(root);
        	stage2.setScene(scene);
        	Image x = new Image("biblioteca/shopping-cart.png");
			stage2.getIcons().add(x);
        	stage2.show();
    		
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }

	public void initialize(URL arg0, ResourceBundle arg1) {
		Image x2 = new Image("biblioteca/grocery-store.png");
		MyImage.setImage(x2);
		primCarr=carrinho;
	}
	
	

}
