package biblioteca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

import java.awt.Color;
import java.io.IOException;

import classes.Utensilios;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Node;

public class UtensiliosController {
	
	private Parent root;
	private Stage stage;
	private Scene scene;
	
private static double val4;
private static int cont;


	static {
		val4=0;
		cont=0;
	}
	
	@FXML
	private TextField txtpesquisa;
	@FXML
	private Label lab1;
	@FXML
	private ImageView image1;
	@FXML
	private Label lab2;
	@FXML
	private ImageView image2;
	@FXML
	private Label lab3;
	@FXML
	private ImageView image3;
	@FXML
	private Label lab4;
	@FXML
	private ImageView image4;
	@FXML
	private Label lab5;
	@FXML
	private ImageView image5;
	@FXML
	private Label lab6;
	@FXML
	private ImageView image6;
	@FXML
	private Button c1;
	@FXML
	private Button c2;
	@FXML
	private Button c3;
	@FXML
	private Button c4;
	@FXML
	private Button c5;
	@FXML
	private Button c6;
	@FXML
	private TextField qnt1;
	@FXML
	private TextField qnt2;
	@FXML
	private TextField qnt3;
	@FXML
	private TextField qnt4;
	@FXML
	private TextField qnt5;
	@FXML
	private TextField qnt6;
	@FXML
	private Button tot;
	@FXML
	private TextField totfield;
	
	 @FXML
	    private Button cc1;

	    @FXML
	    private Button cc2;

	    @FXML
	    private Button cc3;

	    @FXML
	    private Button cc4;

	    @FXML
	    private Button cc5;

	    @FXML
	    private Button cc6;

	    @FXML
	    private Button check;
	
	   @FXML
	    private Label MT;

	    @FXML
	    private Label Q1;

	    @FXML
	    private Label Q2;

	    @FXML
	    private Label Q3;

	    @FXML
	    private Label Q4;

	    @FXML
	    private Label Q5;

	    @FXML
	    private Label Q6;
	    
	    @FXML
	    private AnchorPane anchor;
	    
	    @FXML
	    private Button cartbtn;
	    
	    @FXML
	    private Button adcar1;

	    @FXML
	    private Button adcar2;

	    @FXML
	    private Button adcar3;

	    @FXML
	    private Button adcar4;

	    @FXML
	    private Button adcar5;

	    @FXML
	    private Button adcar6;
	    
	    private Button bt;
	    
	    private Label  labelex;
	    
	    private Label  labelex2;
	    
	    private Label lab32;
	    
	    private Label lab43;


	
	    double total=0;
	    double total1=0;
	    double total2=0;
	    double total3=0;
	    double total4=0;
	    double total5=0;
	    double total6=0;
	    double total7=0;
	    double total8=0;
	    double total9=0;
    
    
    int quant =0;
    int quant1 =0;
    int quant2 =0;
    int quant3 =0;
    int quant4 =0;
    int quant5 =0;
    int quant6 =0;

	// Event Listener on Button.onAction
	@FXML
	public void PesquisaAction(ActionEvent event) {
//		c1.setVisible(false);
//		c2.setVisible(false);
//		c3.setVisible(false);
//		c4.setVisible(false);
//		c5.setVisible(false);
//		c6.setVisible(false);
//		image1.setVisible(false);
//		image2.setVisible(false);
//		image3.setVisible(false);
//		image4.setVisible(false);
//		image5.setVisible(false);
//		lab1.setVisible(false);
//		lab2.setVisible(false);
//		lab3.setVisible(false);
//		lab4.setVisible(false);
//		lab5.setVisible(false);
//		lab6.setVisible(false);
//		qnt1.setVisible(false);
//		qnt2.setVisible(false);
//		qnt3.setVisible(false);
//		qnt4.setVisible(false);
//		qnt5.setVisible(false);
//		qnt6.setVisible(false);
//		tot.setVisible(false);
//		totfield.setVisible(false);
//		MT.setVisible(false);
//		Q1.setVisible(false);
//		Q2.setVisible(false);
//		Q3.setVisible(false);
//		Q4.setVisible(false);
//		Q5.setVisible(false);
//		Q6.setVisible(false);
		if(txtpesquisa.getText().equalsIgnoreCase("Garfo") || txtpesquisa.getText().equalsIgnoreCase("Garfos")) {
			
			c1.setVisible(true);
			c2.setVisible(true);
			c3.setVisible(true);
			c4.setVisible(true);
			c5.setVisible(true);
			c6.setVisible(true);
			image1.setVisible(true);
			image2.setVisible(true);
			image3.setVisible(true);
			image4.setVisible(true);
			image5.setVisible(true);
			lab1.setVisible(true);
			lab2.setVisible(true);
			lab3.setVisible(true);
			lab4.setVisible(true);
			lab5.setVisible(true);
			lab6.setVisible(true);
			qnt1.setVisible(true);
			qnt2.setVisible(true);
			qnt3.setVisible(true);
			qnt4.setVisible(true);
			qnt5.setVisible(true);
			qnt6.setVisible(true);
			tot.setVisible(true);
			totfield.setVisible(true);
			MT.setVisible(true);
			Q1.setVisible(true);
			Q2.setVisible(true);
			Q3.setVisible(true);
			Q4.setVisible(true);
			Q5.setVisible(true);
			Q6.setVisible(true);
			cc1.setVisible(true);
			cc2.setVisible(true);
			cc3.setVisible(true);
			cc4.setVisible(true);
			cc5.setVisible(true);
			cc6.setVisible(true);
			check.setVisible(true);
			adcar1.setVisible(true);
			adcar2.setVisible(true);
			adcar3.setVisible(true);
			adcar4.setVisible(true);
			adcar5.setVisible(true);
			adcar6.setVisible(true);
			labelex2.setVisible(false);
			labelex.setVisible(false);
			bt.setVisible(false);
			lab32.setVisible(false);
			lab43.setVisible(false);
			
			Image x = new Image("biblioteca/garfo1.png");
			image1.setImage(x);
			lab1.setText("Garfo Tridente para\nChurrasco Personalizado\nAluminio\n1.009.07MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt1.setText(Integer.toString(quant));
        	
        	Image x2 = new Image("biblioteca/garfo2.png");
			image2.setImage(x2);
			lab2.setText("Conjunto de Garfos de Mesa\nTramontina Leme\ncom Laminas em Aco Inox e Cab...\nAco inoxidavel\n630.67.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt2.setText(Integer.toString(quant));
        	
        	Image x3 = new Image("biblioteca/garfo3.png");
			image3.setImage(x3);
			lab3.setText("Conjunto De Garfos De Mesa\nAco Inox 3 Pc Tramontina\nInox\nAco Inoxidavel\n403.63.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt3.setText(Integer.toString(quant));
        	
        	Image x4 = new Image("biblioteca/garfo4.png");
			image4.setImage(x4);
			lab4.setText("Garfo Trinchante Tramontina\nPreto\n148.21.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt4.setText(Integer.toString(quant));
        	
        	Image x5 = new Image("biblioteca/garfo5.png");
			image5.setImage(x5);
			lab5.setText("Mimo Style Conjunto de 06\nGarfos para Fondue 24cm,\nProduzido em Aco Inoxidav...\nMadeira, Aco inoxidavel\n663.09.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt5.setText(Integer.toString(quant));
        	
        	Image x6 = new Image("biblioteca/garfo6.png");
			image6.setImage(x6);
			lab6.setText("Mini Garfo para Petiscos\nCoracao 12 unidades\n478.05.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt6.setText(Integer.toString(quant));
        	
//        	c1.setVisible(true);
//			c2.setVisible(true);
//			c3.setVisible(true);
//			c4.setVisible(true);
//			c5.setVisible(true);
//			c6.setVisible(true);
//			image1.setVisible(true);
//			image2.setVisible(true);
//			image3.setVisible(true);
//			image4.setVisible(true);
//			image5.setVisible(true);
//			lab1.setVisible(true);
//			lab2.setVisible(true);
//			lab3.setVisible(true);
//			lab4.setVisible(true);
//			lab5.setVisible(true);
//			lab6.setVisible(true);
//			qnt1.setVisible(true);
//			qnt2.setVisible(true);
//			qnt3.setVisible(true);
//			qnt4.setVisible(true);
//			qnt5.setVisible(true);
//			qnt6.setVisible(true);
//			tot.setVisible(true);
//			totfield.setVisible(true);
//			MT.setVisible(true);
//			Q1.setVisible(true);
//			Q2.setVisible(true);
//			Q3.setVisible(true);
//			Q4.setVisible(true);
//			Q5.setVisible(true);
//			Q6.setVisible(true);
//        	
		}else if(txtpesquisa.getText().equalsIgnoreCase("Faca") || txtpesquisa.getText().equalsIgnoreCase("Facas")) {
			
			c1.setVisible(true);
			c2.setVisible(true);
			c3.setVisible(true);
			c4.setVisible(true);
			c5.setVisible(true);
			c6.setVisible(true);
			image1.setVisible(true);
			image2.setVisible(true);
			image3.setVisible(true);
			image4.setVisible(true);
			image5.setVisible(true);
			lab1.setVisible(true);
			lab2.setVisible(true);
			lab3.setVisible(true);
			lab4.setVisible(true);
			lab5.setVisible(true);
			lab6.setVisible(true);
			qnt1.setVisible(true);
			qnt2.setVisible(true);
			qnt3.setVisible(true);
			qnt4.setVisible(true);
			qnt5.setVisible(true);
			qnt6.setVisible(true);
			tot.setVisible(true);
			totfield.setVisible(true);
			MT.setVisible(true);
			Q1.setVisible(true);
			Q2.setVisible(true);
			Q3.setVisible(true);
			Q4.setVisible(true);
			Q5.setVisible(true);
			Q6.setVisible(true);
			cc1.setVisible(true);
			cc2.setVisible(true);
			cc3.setVisible(true);
			cc4.setVisible(true);
			cc5.setVisible(true);
			cc6.setVisible(true);
			check.setVisible(true);
			adcar1.setVisible(true);
			adcar2.setVisible(true);
			adcar3.setVisible(true);
			adcar4.setVisible(true);
			adcar5.setVisible(true);
			adcar6.setVisible(true);
			labelex2.setVisible(false);
			labelex.setVisible(false);
			bt.setVisible(false);
			lab32.setVisible(false);
			lab43.setVisible(false);
			
			
			
			Image x = new Image("biblioteca/faca1.png");
			image1.setImage(x);
			lab1.setText("Faca de ACOUG FIREBOX\n25CM\n7.048.99MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt1.setText(Integer.toString(quant));
        	
        	Image x2 = new Image("biblioteca/faca2.png");
			image2.setImage(x2);
			lab2.setText("Jogos de Facas 9 Pecas\nTramontina Plenus 23498048\nPreto\nAco inoxidavel\n669.591.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt2.setText(Integer.toString(quant));
        	
        	Image x3 = new Image("biblioteca/faca3.png");
			image3.setImage(x3);
			lab3.setText("Faca Zeta de Chefe com\nAcabamento em Aco\n2.131.09MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt3.setText(Integer.toString(quant));
        	
        	Image x4 = new Image("biblioteca/faca4.png");
			image4.setImage(x4);
			lab4.setText("Jogo de Facas 6 pecas\nTramontina Nygma\n2.899.039MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt4.setText(Integer.toString(quant));
        	
        	Image x5 = new Image("biblioteca/faca5.png");
			image5.setImage(x5);
			lab5.setText("Kit Facas Coloridas Infantil 5\nPecas Comtac Kids 4443\n377.039.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt5.setText(Integer.toString(quant));
        	
        	Image x6 = new Image("biblioteca/faca6.png");
			image6.setImage(x6);
			lab6.setText("Conjunto de Facas 6 Pecas\nColorstone Rattan Preta,\nFSC5500, Euro Home\n1.386.7217MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt6.setText(Integer.toString(quant));
        	
		}else if(txtpesquisa.getText().equalsIgnoreCase("Colher") || txtpesquisa.getText().equalsIgnoreCase("Colheres")) {
			
			c1.setVisible(true);
			c2.setVisible(true);
			c3.setVisible(true);
			c4.setVisible(true);
			c5.setVisible(true);
			c6.setVisible(true);
			image1.setVisible(true);
			image2.setVisible(true);
			image3.setVisible(true);
			image4.setVisible(true);
			image5.setVisible(true);
			lab1.setVisible(true);
			lab2.setVisible(true);
			lab3.setVisible(true);
			lab4.setVisible(true);
			lab5.setVisible(true);
			lab6.setVisible(true);
			qnt1.setVisible(true);
			qnt2.setVisible(true);
			qnt3.setVisible(true);
			qnt4.setVisible(true);
			qnt5.setVisible(true);
			qnt6.setVisible(true);
			tot.setVisible(true);
			totfield.setVisible(true);
			MT.setVisible(true);
			Q1.setVisible(true);
			Q2.setVisible(true);
			Q3.setVisible(true);
			Q4.setVisible(true);
			Q5.setVisible(true);
			Q6.setVisible(true);
			cc1.setVisible(true);
			cc2.setVisible(true);
			cc3.setVisible(true);
			cc4.setVisible(true);
			cc5.setVisible(true);
			cc6.setVisible(true);
			check.setVisible(true);
			adcar1.setVisible(true);
			adcar2.setVisible(true);
			adcar3.setVisible(true);
			adcar4.setVisible(true);
			adcar5.setVisible(true);
			adcar6.setVisible(true);
			labelex2.setVisible(false);
			labelex.setVisible(false);
			bt.setVisible(false);
			lab32.setVisible(false);
			lab43.setVisible(false);
			
			Image x = new Image("biblioteca/colher1.png");
			image1.setImage(x);
			lab1.setText("Concha de vinho colher de\naco inoxidavel, colher de\nvinho para colher medidora...\n1.013.7179MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt1.setText(Integer.toString(quant));
        	
        	Image x2 = new Image("biblioteca/colher2.png");
			image2.setImage(x2);
			lab2.setText("Colher De Arroz Siena Brinox\nAco Inox\nPreto\nAco inoxidavel\n88.27.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt2.setText(Integer.toString(quant));
        	
        	Image x3 = new Image("biblioteca/colher3.png");
			image3.setImage(x3);
			lab3.setText("Colher de Silicone Laranja\nGrande - Oikos\nSilicone, Metal\n288.769.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt3.setText(Integer.toString(quant));
        	
        	Image x4 = new Image("biblioteca/colher4.png");
			image4.setImage(x4);
			lab4.setText("Colher para Servir Aco Inox\nLinha Aruba, Simonaggio,\nAB41, Aco Inox\nAco inoxidavel\n140.6015.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt4.setText(Integer.toString(quant));
        	
        	Image x5 = new Image("biblioteca/colher5.png");
			image5.setImage(x5);
			lab5.setText("Colher De Cha Siena - 6 Pcs\nBrinox Aco Inox\nAco inoxidavel\n143.5018.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt5.setText(Integer.toString(quant));
        	
        	Image x6 = new Image("biblioteca/colher6.png");
			image6.setImage(x6);
			lab6.setText("Kit de Colher, concha,\nespatula e escumadeira em\nsilicone (vermelho)\n534.1596.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt6.setText(Integer.toString(quant));
		}else {
			c1.setVisible(false);
			c2.setVisible(false);
			c3.setVisible(false);
			c4.setVisible(false);
			c5.setVisible(false);
			c6.setVisible(false);
			image1.setVisible(false);
			image2.setVisible(false);
			image3.setVisible(false);
			image4.setVisible(false);
			image5.setVisible(false);
			lab1.setVisible(false);
			lab2.setVisible(false);
			lab3.setVisible(false);
			lab4.setVisible(false);
			lab5.setVisible(false);
			lab6.setVisible(false);
			qnt1.setVisible(false);
			qnt2.setVisible(false);
			qnt3.setVisible(false);
			qnt4.setVisible(false);
			qnt5.setVisible(false);
			qnt6.setVisible(false);
			tot.setVisible(false);
			totfield.setVisible(false);
			MT.setVisible(false);
			Q1.setVisible(false);
			Q2.setVisible(false);
			Q3.setVisible(false);
			Q4.setVisible(false);
			Q5.setVisible(false);
			Q6.setVisible(false);
			 labelex = new Label();
			 bt = new Button();
			 labelex2 = new Label();
			labelex.setText(txtpesquisa.getText()+" Nao existe");
			bt.setText("Verificar no Stock");
			labelex2.setText("Clique no botao Abaixo para verificar no Stock");
			labelex.setTranslateX(450);
			labelex.setTranslateY(200);
			labelex2.setTranslateX(350);
			labelex2.setTranslateY(230);
			bt.setTranslateX(440);
			bt.setTranslateY(260);
			bt.setStyle("-fx-font-size: 18");
			labelex.setStyle("-fx-font-size: 18");
			labelex2.setStyle("-fx-font-size: 18");
//			bt.setStyle("-fx-text-fill: #fcfcfc");
//			bt.setStyle("-fx-background-color: blue");
			anchor.getChildren().add(labelex);
			anchor.getChildren().add(bt);
			anchor.getChildren().add(labelex2);
			bt.setOnAction(new EventHandler <ActionEvent>() {
				
				public void handle(ActionEvent event) {
				 lab32 = new Label();
				 lab43 = new Label();
				lab43.setText("Procurando no Stock");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				lab32.setText("Nao foi encontrado o produto "+txtpesquisa.getText()+" no Stock");
				lab32.setTranslateX(400);
				lab32.setTranslateY(235);
				lab43.setTranslateX(475);
				lab43.setTranslateY(200);
				lab32.setStyle("-fx-font-size: 18");
				lab43.setStyle("-fx-font-size: 18");
				labelex.setVisible(false);
				labelex2.setVisible(false);
				bt.setVisible(false);
				anchor.getChildren().add(lab32);
				}
				});
		}
	}
	// Event Listener on Button.onAction
	@FXML
	public void backAction(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("menu.fxml"));
		root = loader.load();
		
		stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
		
	}
	// Event Listener on Button[#c1].onAction
	  @FXML
	    void compra1Action(ActionEvent event) {
	    	quant1++;
	    	qnt1.setText(Integer.toString(quant1));
	    }

	    @FXML
	    void compra2Action(ActionEvent event) {
	    	quant2++;
	    	qnt2.setText(Integer.toString(quant2));
	    }

	    @FXML
	    void compra3Action(ActionEvent event) {
	    	quant3++;
	    	qnt3.setText(Integer.toString(quant3));
	    }

	    @FXML
	    void compra4Action(ActionEvent event) {
	    	quant4++;
	    	qnt4.setText(Integer.toString(quant4));
	    }

	    @FXML
	    void compra5Action(ActionEvent event) {
	    	quant5++;
	    	qnt5.setText(Integer.toString(quant5));
	    }

	    @FXML
	    void compra6Action(ActionEvent event) {
	    	quant6++;
	    	qnt6.setText(Integer.toString(quant6));
	    }
	// Event Listener on Button[#tot].onAction
	@FXML
	public void totAction(ActionEvent event) {
		if(txtpesquisa.getText().equalsIgnoreCase("Garfo") || txtpesquisa.getText().equalsIgnoreCase("Garfos")) {
   		 Utensilios u1 = new Utensilios(quant1,1009.07);
   		 Utensilios u2 = new Utensilios(quant2,630.67);
   		 Utensilios u3 = new Utensilios(quant3,403.63);
   		 Utensilios u4 = new Utensilios(quant4,148.21);
   		 Utensilios u5 = new Utensilios(quant5,663.09);
   		 Utensilios u6 = new Utensilios(quant6,478.05);
   		 total1=((u1.getQuantaty()*u1.getValorUten())+(u2.getQuantaty()*u2.getValorUten())+(u3.getQuantaty()*u3.getValorUten())+(u4.getQuantaty()*u4.getValorUten())+(u5.getQuantaty()*u5.getValorUten())+(u6.getQuantaty()*u6.getValorUten()));
   		// totfield.setText(Double.toString(total));
   		
   	}else if(txtpesquisa.getText().equalsIgnoreCase("Faca") || txtpesquisa.getText().equalsIgnoreCase("Facas")) {
   	 Utensilios u1 = new Utensilios(quant1,7048.99);
		 Utensilios u2 = new Utensilios(quant2,669.591);
		 Utensilios u3 = new Utensilios(quant3,2131.09);
		 Utensilios u4 = new Utensilios(quant4,2899.039);
		 Utensilios u5 = new Utensilios(quant5,377.039);
		 Utensilios u6 = new Utensilios(quant6,1386.7217);
		 total2=((u1.getQuantaty()*u1.getValorUten())+(u2.getQuantaty()*u2.getValorUten())+(u3.getQuantaty()*u3.getValorUten())+(u4.getQuantaty()*u4.getValorUten())+(u5.getQuantaty()*u5.getValorUten())+(u6.getQuantaty()*u6.getValorUten()));
		 //totfield.setText(Double.toString(total));
   		
   	}else if(txtpesquisa.getText().equalsIgnoreCase("Colher") || txtpesquisa.getText().equalsIgnoreCase("Colheres")) {
   	 Utensilios u1 = new Utensilios(quant1,1013.7179);
		 Utensilios u2 = new Utensilios(quant2,88.27);
		 Utensilios u3 = new Utensilios(quant3,288.769);
		 Utensilios u4 = new Utensilios(quant4,140.6015);
		 Utensilios u5 = new Utensilios(quant5,143.5018);
		 Utensilios u6 = new Utensilios(quant6,534.1596);
		 total3=((u1.getQuantaty()*u1.getValorUten())+(u2.getQuantaty()*u2.getValorUten())+(u3.getQuantaty()*u3.getValorUten())+(u4.getQuantaty()*u4.getValorUten())+(u5.getQuantaty()*u5.getValorUten())+(u6.getQuantaty()*u6.getValorUten()));
		 paypalPagamentoController pag = new paypalPagamentoController();
		 pag.voi(total);
		 
		 //totfield.setText(Double.toString(total));
   	}
		total = total1+total2+total3;
		 totfield.setText(Double.toString(total));
		 paypalPagamentoController pag = new paypalPagamentoController();
    	 CartaoController card = new CartaoController();
			card.voi(total);
		 pag.voi(total);
	}
	
	 @FXML
	    void Menos1Action(ActionEvent event) {
		  quant1--;
	    	qnt1.setText(Integer.toString(quant1));
	    }

	    @FXML
	    void Menos2Action(ActionEvent event) {
	    	quant2--;
	    	qnt2.setText(Integer.toString(quant2));
	    }

	    @FXML
	    void Menos3Action(ActionEvent event) {
	    	quant3--;
	    	qnt3.setText(Integer.toString(quant3));
	    }

	    @FXML
	    void Menos4Action(ActionEvent event) {
	    	quant4--;
	    	qnt4.setText(Integer.toString(quant4));
	    }

	    @FXML
	    void Menos5Action(ActionEvent event) {
	    	quant5--;
	    	qnt5.setText(Integer.toString(quant5));
	    }

	    @FXML
	    void Menos6Action(ActionEvent event) {
	    	quant6--;
	    	qnt6.setText(Integer.toString(quant6));
	    }
	    
	    @FXML
	    void checkoutAction(ActionEvent event) throws IOException {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Checkout.fxml"));
			root = loader.load();
			
			Stage stage2 = new Stage();
			stage2.setScene(new Scene(root));
			stage2.show();
	    }
	    
	    @FXML
	    void OnAdCarrinho1Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	 
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    	
	    	
	    
	    }

	    @FXML
	    void OnAdCarrinho2Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    	
		    	
	    	
	    }

	    @FXML
	    void OnAdCarrinho3Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho4Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho5Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho6Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }
	    
	    @FXML
	    void OnCartAction(ActionEvent event) throws IOException {
	    	
	    	if(txtpesquisa.getText().equalsIgnoreCase("Garfo") || txtpesquisa.getText().equalsIgnoreCase("Garfos")) {
	    		
	    		Utensilios b1 = new Utensilios(quant1,1009.07);
	      		 Utensilios b2 = new Utensilios(quant2,630.67);
	      		 Utensilios b3 = new Utensilios(quant3,403.63);
	      		 Utensilios b4 = new Utensilios(quant4,148.21);
	      		 Utensilios b5 = new Utensilios(quant5,663.09);
	      		 Utensilios b6 = new Utensilios(quant6,478.05);
	    		
	    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	String quantidadeTotal = qnt1.getText();
			    	double totAl = (b1.getValorUten()*b1.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab2.getText();
			    	Image i = image2.getImage();
			    	String quantidadeTotal = qnt2.getText();
			    	double totAl = (b2.getValorUten()*b2.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    		
		    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab3.getText();
			    	Image i = image3.getImage();
			    	String quantidadeTotal = qnt3.getText();
			    	
			    	double totAl = (b3.getValorUten()*b3.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab4.getText();
			    	Image i = image4.getImage();
			    	String quantidadeTotal = qnt4.getText();
			    	double totAl = (b4.getValorUten()*b4.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
		    		
		    		String txt1 = lab5.getText();
			    	Image i = image5.getImage();
			    	String quantidadeTotal = qnt5.getText();
			    	
			    	double totAl = (b5.getValorUten()*b5.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
		    		
		    		String txt1 = lab6.getText();
			    	Image i = image6.getImage();
			    	String quantidadeTotal = qnt6.getText();
			    	
			    	double totAl = (b6.getValorUten()*b6.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    	}
		    	
		    	
		    	
		    	if(quant1>=1 && quant2>=1) {
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	
			    	
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    		
		    	}else if(quant1>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant2>=1 && quant3>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant4>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant5>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	 
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant6>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant3>=1 && quant4>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant3>=1 && quant5>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant3>=1 && quant6>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant4>=1 && quant5>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant4>=1 && quant6>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant5>=1 && quant6>=1){
		    		
		    		String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i5, txt5);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	 
		    	if(quant1>=1 && quant2>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i3, txt3);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant1>=1 && quant2>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant1>=1 && quant3>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant2>=1 && quant3>=1 && quant4>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	 
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant3>=1 && quant4>=1 && quant5>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant4>=1 && quant5>=1 && quant6>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
	        
	    		
	    	}else if(txtpesquisa.getText().equalsIgnoreCase("Faca") || txtpesquisa.getText().equalsIgnoreCase("Facas")) {
	    		
	    		Utensilios b1 = new Utensilios(quant1,7048.99);
	   		 Utensilios b2 = new Utensilios(quant2,669.591);
	   		 Utensilios b3 = new Utensilios(quant3,2131.09);
	   		 Utensilios b4 = new Utensilios(quant4,2899.039);
	   		 Utensilios b5 = new Utensilios(quant5,377.039);
	   		 Utensilios b6 = new Utensilios(quant6,1386.7217);
	    		
	    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	String quantidadeTotal = qnt1.getText();
			    	double totAl = (b1.getValorUten()*b1.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab2.getText();
			    	Image i = image2.getImage();
			    	String quantidadeTotal = qnt2.getText();
			    	double totAl = (b2.getValorUten()*b2.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    		
		    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab3.getText();
			    	Image i = image3.getImage();
			    	String quantidadeTotal = qnt3.getText();
			    	
			    	double totAl = (b3.getValorUten()*b3.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab4.getText();
			    	Image i = image4.getImage();
			    	String quantidadeTotal = qnt4.getText();
			    	double totAl = (b4.getValorUten()*b4.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
		    		
		    		String txt1 = lab5.getText();
			    	Image i = image5.getImage();
			    	String quantidadeTotal = qnt5.getText();
			    	
			    	double totAl = (b5.getValorUten()*b5.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
		    		
		    		String txt1 = lab6.getText();
			    	Image i = image6.getImage();
			    	String quantidadeTotal = qnt6.getText();
			    	
			    	double totAl = (b6.getValorUten()*b6.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    	}
		    	
		    	
		    	
		    	if(quant1>=1 && quant2>=1) {
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	
			    	
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    		
		    	}else if(quant1>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant2>=1 && quant3>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant4>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant5>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	 
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant6>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant3>=1 && quant4>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant3>=1 && quant5>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant3>=1 && quant6>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant4>=1 && quant5>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant4>=1 && quant6>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant5>=1 && quant6>=1){
		    		
		    		String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i5, txt5);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	 
		    	if(quant1>=1 && quant2>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i3, txt3);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant1>=1 && quant2>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant1>=1 && quant3>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant2>=1 && quant3>=1 && quant4>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	 
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant3>=1 && quant4>=1 && quant5>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant4>=1 && quant5>=1 && quant6>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
	        
	    			
	    	}else if(txtpesquisa.getText().equalsIgnoreCase("Colher") || txtpesquisa.getText().equalsIgnoreCase("Colheres")) {
	    		
	    		 Utensilios b1 = new Utensilios(quant1,1013.7179);
	    		 Utensilios b2 = new Utensilios(quant2,88.27);
	    		 Utensilios b3 = new Utensilios(quant3,288.769);
	    		 Utensilios b4 = new Utensilios(quant4,140.6015);
	    		 Utensilios b5 = new Utensilios(quant5,143.5018);
	    		 Utensilios b6 = new Utensilios(quant6,534.1596);
	    		
	    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	String quantidadeTotal = qnt1.getText();
			    	double totAl = (b1.getValorUten()*b1.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab2.getText();
			    	Image i = image2.getImage();
			    	String quantidadeTotal = qnt2.getText();
			    	double totAl = (b2.getValorUten()*b2.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    		
		    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab3.getText();
			    	Image i = image3.getImage();
			    	String quantidadeTotal = qnt3.getText();
			    	
			    	double totAl = (b3.getValorUten()*b3.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab4.getText();
			    	Image i = image4.getImage();
			    	String quantidadeTotal = qnt4.getText();
			    	double totAl = (b4.getValorUten()*b4.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
		    		
		    		String txt1 = lab5.getText();
			    	Image i = image5.getImage();
			    	String quantidadeTotal = qnt5.getText();
			    	
			    	double totAl = (b5.getValorUten()*b5.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
		    		
		    		String txt1 = lab6.getText();
			    	Image i = image6.getImage();
			    	String quantidadeTotal = qnt6.getText();
			    	
			    	double totAl = (b6.getValorUten()*b6.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    	}
		    	
		    	
		    	
		    	if(quant1>=1 && quant2>=1) {
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	
			    	
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    		
		    	}else if(quant1>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant2>=1 && quant3>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant4>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant5>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	 
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant6>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant3>=1 && quant4>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant3>=1 && quant5>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant3>=1 && quant6>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant4>=1 && quant5>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant4>=1 && quant6>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant5>=1 && quant6>=1){
		    		
		    		String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i5, txt5);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	 
		    	if(quant1>=1 && quant2>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i3, txt3);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant1>=1 && quant2>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant1>=1 && quant3>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant2>=1 && quant3>=1 && quant4>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	 
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant3>=1 && quant4>=1 && quant5>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant4>=1 && quant5>=1 && quant6>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
	        
	    	}
	    }
}
