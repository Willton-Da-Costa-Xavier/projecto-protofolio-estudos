package biblioteca;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class PaypalController {

    @FXML
    private AnchorPane anchor;

    @FXML
    private TextField txtApelido;

    @FXML
    private TextField txtCSC;

    @FXML
    private TextField txtExpira;

    @FXML
    private TextField txtMorada;

    @FXML
    private TextField txtNome;

    @FXML
    private TextField txtNumCartao;
    
    @FXML
    void OntxtCSCAction(ActionEvent event) {
    	
    	txtCSC.setStyle("-fx-border-color: lightblue");
    	

    }

    @FXML
    void OntxtCardNumAction(ActionEvent event) {
    	
    	txtNumCartao.setStyle("-fx-border-color: lightblue");
    }

    @FXML
    void OntxtExpiraAction(ActionEvent event) {
    	
    	txtExpira.setStyle("-fx-border-color: lightblue");
    }

    @FXML
    void OntxtMoradaAction(ActionEvent event) {
    	
    	txtMorada.setStyle("-fx-border-color: lightblue");
    }

    @FXML
    void OntxtNameAction(ActionEvent event) {
    	
    	txtNome.setStyle("-fx-border-color: lightblue");
    }

    @FXML
    void OntxtSurnameAction(ActionEvent event) {
    	
    	txtApelido.setStyle("-fx-border-color: lightblue");
    }

}
