package biblioteca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classes.Paypal;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class paypalPagamentoController implements Initializable{
	@FXML
	private Label valor1txt;
	@FXML
	private Label valor2txt;
	
	  @FXML
	    private Label txtNomeAnterior;
	
	private Parent root;
	private static double r;
	
	static {
		r=0;
		
	}

	// Event Listener on Button.onAction
	@FXML
	public void OnContinuarAction(ActionEvent event) throws IOException {
		
		Paypal pay = new Paypal(500000);
		
		BrinquedosController bq = new BrinquedosController();
		ElectrodomesticosController elect = new ElectrodomesticosController();
		FloresController fl = new FloresController();
		UtensiliosController ut = new UtensiliosController();
		VestuarioController vest = new VestuarioController();
		
	
		
		if((pay.getSaldo()-r>0)) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("pagamentoSucesso.fxml"));
			root = loader.load();
			
			Stage stage3 = new Stage();
			stage3.setScene(new Scene(root));
			Image x = new Image("biblioteca/shopping-cart.png");
			stage3.getIcons().add(x);
			stage3.show();
		}else {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("saldoInsuficiente.fxml"));
			root = loader.load();
			
			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			Image x = new Image("biblioteca/shopping-cart.png");
			stage.getIcons().add(x);
			stage.show();
		}
		
		
	}
	
	public  double voi(double tot) {
		r = tot;
		return tot;

	}
	
	public void nome(String username) {
	
			txtNomeAnterior.setText(username);
	}

	public void initialize(URL arg0, ResourceBundle arg1) {
	
		
	}
}
