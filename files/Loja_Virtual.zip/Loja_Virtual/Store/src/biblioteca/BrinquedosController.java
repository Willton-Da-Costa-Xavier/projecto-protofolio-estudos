package biblioteca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;

import javafx.scene.control.ToggleGroup;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classes.Brinquedos;
import classes.Cart;
import javafx.event.ActionEvent;

import javafx.scene.control.Label;

import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.control.RadioButton;

public class BrinquedosController  implements Initializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;
	
	@FXML
	private AnchorPane anchor;
	
	public static String txt1;
	public static int cont;
	public static Image i;
	
	static {
		txt1="0";
		cont=0;
	}
	@FXML
	private TextField txtpesquisa;
	@FXML
	private Label lab1;
	@FXML
	private ImageView image1;
	@FXML
	private Label lab2;
	@FXML
	private ImageView image2;
	@FXML
	private Label lab3;
	@FXML
	private ImageView image3;
	@FXML
	private Label lab4;
	@FXML
	private ImageView image4;
	@FXML
	private Label lab5;
	@FXML
	private ImageView image5;
	@FXML
	private Label lab6;
	@FXML
	private ImageView image6;
	@FXML
	private Button c1;
	@FXML
	private Button c2;
	@FXML
	private Button c3;
	@FXML
	private Button c4;
	@FXML
	private Button c5;
	@FXML
	private Button c6;
	@FXML
	private Label Q1;
	@FXML
	private Label Q2;
	@FXML
	private Label Q3;
	@FXML
	private Label Q4;
	@FXML
	private Label Q5;
	@FXML
	private Label Q6;
	@FXML
	private TextField qnt1;
	@FXML
	private TextField qnt2;
	@FXML
	private TextField qnt3;
	@FXML
	private TextField qnt4;
	@FXML
	private TextField qnt5;
	@FXML
	private TextField qnt6;
	@FXML
	private Button tot;
	@FXML
	private TextField totfield;
	@FXML
	private Label MT;
	@FXML
	private RadioButton Masc;
	@FXML
	private ToggleGroup sexo;
	@FXML
	private RadioButton Fem;
	
	  @FXML
	    private Button cartbtn;
	
	 @FXML
	    private Button adcar1;

	    @FXML
	    private Button adcar2;

	    @FXML
	    private Button addcar3;

	    @FXML
	    private Button addcar4;

	    @FXML
	    private Button addcar5;

	    @FXML
	    private Button addcar6;
	    
	@FXML
	private Button cc1;
	@FXML
	private Button cc2;
	@FXML
	private Button cc4;
	@FXML
	private Button cc5;
	@FXML
	private Button cc6;
	@FXML
	private Button cc3;
	@FXML
	private Button check;
	
	  double total=0;
	    double total1=0;
	    double total2=0;
	    double total3=0;
	    double total4=0;
	    double total5=0;
	    double total6=0;
	    double total7=0;
	    double total8=0;
	    double total9=0;
  
  int quant =0;
  int quant1 =0;
  int quant2 =0;
  int quant3 =0;
  int quant4 =0;
  int quant5 =0;
  int quant6 =0;
  
   

	// Event Listener on Button.onAction
//	@FXML
//	public void PesquisaAction(ActionEvent event) {
//		c1.setVisible(true);
//		c2.setVisible(true);
//		c3.setVisible(true);
//		c4.setVisible(true);
//		c5.setVisible(true);
//		c6.setVisible(true);
//		image1.setVisible(true);
//		image2.setVisible(true);
//		image3.setVisible(true);
//		image4.setVisible(true);
//		image5.setVisible(true);
//		lab1.setVisible(true);
//		lab2.setVisible(true);
//		lab3.setVisible(true);
//		lab4.setVisible(true);
//		lab5.setVisible(true);
//		lab6.setVisible(true);
//		qnt1.setVisible(true);
//		qnt2.setVisible(true);
//		qnt3.setVisible(true);
//		qnt4.setVisible(true);
//		qnt5.setVisible(true);
//		qnt6.setVisible(true);
//		tot.setVisible(true);
//		totfield.setVisible(true);
//		MT.setVisible(true);
//		Q1.setVisible(true);
//		Q2.setVisible(true);
//		Q3.setVisible(true);
//		Q4.setVisible(true);
//		Q5.setVisible(true);
//		Q6.setVisible(true);
//		cc1.setVisible(true);
//		cc2.setVisible(true);
//		cc3.setVisible(true);
//		cc4.setVisible(true);
//		cc5.setVisible(true);
//		cc6.setVisible(true);
//		check.setVisible(true);
//		
//		if(Fem.isSelected()) {
//			Image x = new Image("biblioteca/brinquedoF1.png");
//			image1.setImage(x);
//			lab1.setText("Kit de brinquedos de\nmaquiagem infantil lavavel,\nbrinquedos de cosmeticos...\n1.803.23MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt1.setText(Integer.toString(quant));
//        	
//        	Image x2 = new Image("biblioteca/brinquedoF2.png");
//			image2.setImage(x2);
//			lab2.setText("Baldinho de Praia Menina\ncom Moldes e Pa Merco Toys\n391.5405.00MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt2.setText(Integer.toString(quant));
//        	
//        	Image x3 = new Image("biblioteca/brinquedoF3.png");
//			image3.setImage(x3);
//			lab3.setText("GLAMOUR FLIP DA BARBIE -\nRADIO CONTROLE, Candide,\nrosa\nCandide\n841.609.00MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt3.setText(Integer.toString(quant));
//        	
//        	Image x4 = new Image("biblioteca/brinquedoF4.png");
//			image4.setImage(x4);
//			lab4.setText("Nova Big Cozinha Infantil\nCompleta, Big Star, 630-NBC,\nRosa\nPlastico\n1.337.5427MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt4.setText(Integer.toString(quant));
//        	
//        	Image x5 = new Image("biblioteca/brinquedoF5.png");
//			image5.setImage(x5);
//			lab5.setText("Brinquedo Boneca Baby Alive\nHora do Xixi Loira - Com\nRoupinha removivel e...\n1.157.9763MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt5.setText(Integer.toString(quant));
//        	
//        	Image x6 = new Image("biblioteca/brinquedoF6.png");
//			image6.setImage(x6);
//			lab6.setText("Maleta - Doutor Canino Roma\nJensen Rosa\nPolipropileno\n1.186.0966MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt6.setText(Integer.toString(quant));
//        	
//		}else if(Masc.isSelected()) {
//			Image x = new Image("biblioteca/brinquedoM1.png");
//			image1.setImage(x);
//			lab1.setText("Brincando de Engenheiro 120\nPecas Xalingo, Multicor\nPlastico\n473.1272.00MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt1.setText(Integer.toString(quant));
//        	
//        	Image x2 = new Image("biblioteca/brinquedoM2.png");
//			image2.setImage(x2);
//			lab2.setText("Express Wheels Garagem\nPolicia 40 Pecas MuktiKids -\nBR1237\nPlastico\n665.6819.00MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt2.setText(Integer.toString(quant));
//        	
//        	Image x3 = new Image("biblioteca/brinquedoM3.png");
//			image3.setImage(x3);
//			lab3.setText("Robo Agil com Luzes e Sons -\nBate e Volta - 1039\n679.5529.00MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt3.setText(Integer.toString(quant));
//        	
//        	Image x4 = new Image("biblioteca/brinquedoM4.png");
//			image4.setImage(x4);
//			lab4.setText("11013 LEGO� Classic Blocos\nTransparentes Criativos; Kit\nde Construcao para Crianca...\nPlastico\n2.079.389MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt4.setText(Integer.toString(quant));
//        	
//        	Image x5 = new Image("biblioteca/brinquedoM5.png");
//			image5.setImage(x5);
//			lab5.setText("Bateria De Brinquedo Infantil\nInstrumento Musical Para\nCriancas Meninos...\n813.345.00MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt5.setText(Integer.toString(quant));
//        	
//        	Image x6 = new Image("biblioteca/brinquedoM6.png");
//			image6.setImage(x6);
//			lab6.setText("KKcare Carro RC carro de\ncontrole remoto RC carro de\ncorrida 1\n18 2,4 GHz RC Dri...\n1638.039.00MT");
//			quant1=0;
//        	quant2=0;
//        	quant3=0;
//        	quant4=0;
//        	quant5=0;
//        	quant6=0;
//        	qnt6.setText(Integer.toString(quant));
//		}else {
//			c1.setVisible(false);
//			c2.setVisible(false);
//			c3.setVisible(false);
//			c4.setVisible(false);
//			c5.setVisible(false);
//			c6.setVisible(false);
//			image1.setVisible(false);
//			image2.setVisible(false);
//			image3.setVisible(false);
//			image4.setVisible(false);
//			image5.setVisible(false);
//			lab1.setVisible(false);
//			lab2.setVisible(false);
//			lab3.setVisible(false);
//			lab4.setVisible(false);
//			lab5.setVisible(false);
//			lab6.setVisible(false);
//			qnt1.setVisible(false);
//			qnt2.setVisible(false);
//			qnt3.setVisible(false);
//			qnt4.setVisible(false);
//			qnt5.setVisible(false);
//			qnt6.setVisible(false);
//			tot.setVisible(false);
//			totfield.setVisible(false);
//			MT.setVisible(false);
//			Q1.setVisible(false);
//			Q2.setVisible(false);
//			Q3.setVisible(false);
//			Q4.setVisible(false);
//			Q5.setVisible(false);
//			Q6.setVisible(false);
//			Label labelex = new Label();
//			Label labelex2 = new Label();
//			Button bt = new Button();
//			labelex.setText(txtpesquisa.getText()+" Nao existe");
//			labelex2.setText("Clique no botao Abaixo para verificar no Stock");
//			bt.setText("Verificar no Stock");
//			labelex.setTranslateX(475);
//			labelex.setTranslateY(200);
//			labelex2.setTranslateX(400);
//			labelex2.setTranslateY(230);
//			bt.setTranslateX(470);
//			bt.setTranslateY(260);
//			
//			bt.setStyle("-fx-font-size: 18");
//			labelex.setStyle("-fx-font-size: 18");
//			labelex2.setStyle("-fx-font-size: 18");
////			bt.setStyle("-fx-background-color: blue");
//			anchor.getChildren().add(labelex);
//			anchor.getChildren().add(labelex2);
//			anchor.getChildren().add(bt);
//			bt.setOnAction(arg0 -> {
//			Label lab32 = new Label();
//			Label lab43 = new Label();
//			lab43.setText("Procurando no Stock");
//			try {
//				Thread.sleep(2000);
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			lab32.setText("Nao foi encontrado o produto "+txtpesquisa.getText()+" no Stock");
//			lab32.setTranslateX(400);
//			lab32.setTranslateY(235);
//			lab43.setTranslateX(475);
//			lab43.setTranslateY(200);
//			lab32.setStyle("-fx-font-size: 18");
//			lab43.setStyle("-fx-font-size: 18");
//			labelex.setVisible(false);
//			labelex2.setVisible(false);
//			bt.setVisible(false);
//			anchor.getChildren().add(lab32);
//			});
//			
//		}
//	}
	// Event Listener on Button.onAction
	@FXML
	public void backAction(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("menu.fxml"));
		root = loader.load();
		
		stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	// Event Listener on Button[#c1].onAction
	 @FXML
	    void compra1Action(ActionEvent event) {
	    	quant1++;
	    	qnt1.setText(Integer.toString(quant1));
	    }

	    @FXML
	    void compra2Action(ActionEvent event) {
	    	quant2++;
	    	qnt2.setText(Integer.toString(quant2));
	    }

	    @FXML
	    void compra3Action(ActionEvent event) {
	    	quant3++;
	    	qnt3.setText(Integer.toString(quant3));
	    }

	    @FXML
	    void compra4Action(ActionEvent event) {
	    	quant4++;
	    	qnt4.setText(Integer.toString(quant4));
	    }

	    @FXML
	    void compra5Action(ActionEvent event) {
	    	quant5++;
	    	qnt5.setText(Integer.toString(quant5));
	    }

	    @FXML
	    void compra6Action(ActionEvent event) {
	    	quant6++;
	    	qnt6.setText(Integer.toString(quant6));
	    }
	// Event Listener on Button[#tot].onAction
	    @FXML
	    void Menos1Action(ActionEvent event) {
		  quant1--;
	    	qnt1.setText(Integer.toString(quant1));
	    }

	    @FXML
	    void Menos2Action(ActionEvent event) {
	    	quant2--;
	    	qnt2.setText(Integer.toString(quant2));
	    }

	    @FXML
	    void Menos3Action(ActionEvent event) {
	    	quant3--;
	    	qnt3.setText(Integer.toString(quant3));
	    }

	    @FXML
	    void Menos4Action(ActionEvent event) {
	    	quant4--;
	    	qnt4.setText(Integer.toString(quant4));
	    }

	    @FXML
	    void Menos5Action(ActionEvent event) {
	    	quant5--;
	    	qnt5.setText(Integer.toString(quant5));
	    }

	    @FXML
	    void Menos6Action(ActionEvent event) {
	    	quant6--;
	    	qnt6.setText(Integer.toString(quant6));
	    }
	    
	    @FXML
	    void checkoutAction(ActionEvent event) throws IOException {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Checkout.fxml"));
			root = loader.load();
			
			Stage stage2 = new Stage();
			stage2.setScene(new Scene(root));
			stage2.show();
	    }
	    
	    @FXML
	    void OnRadioFemAction(ActionEvent event) {
	    	c1.setVisible(true);
			c2.setVisible(true);
			c3.setVisible(true);
			c4.setVisible(true);
			c5.setVisible(true);
			c6.setVisible(true);
			image1.setVisible(true);
			image2.setVisible(true);
			image3.setVisible(true);
			image4.setVisible(true);
			image5.setVisible(true);
			lab1.setVisible(true);
			lab2.setVisible(true);
			lab3.setVisible(true);
			lab4.setVisible(true);
			lab5.setVisible(true);
			lab6.setVisible(true);
			qnt1.setVisible(true);
			qnt2.setVisible(true);
			qnt3.setVisible(true);
			qnt4.setVisible(true);
			qnt5.setVisible(true);
			qnt6.setVisible(true);
			tot.setVisible(true);
			totfield.setVisible(true);
			MT.setVisible(true);
			Q1.setVisible(true);
			Q2.setVisible(true);
			Q3.setVisible(true);
			Q4.setVisible(true);
			Q5.setVisible(true);
			Q6.setVisible(true);
			cc1.setVisible(true);
			cc2.setVisible(true);
			cc3.setVisible(true);
			cc4.setVisible(true);
			cc5.setVisible(true);
			cc6.setVisible(true);
			check.setVisible(true);
			adcar1.setVisible(true);
			adcar2.setVisible(true);
			addcar3.setVisible(true);
			addcar4.setVisible(true);
			addcar5.setVisible(true);
			addcar6.setVisible(true);
			
			Image x = new Image("biblioteca/brinquedoF1.png");
			image1.setImage(x);
			lab1.setText("Kit de brinquedos de\nmaquiagem infantil lavavel,\nbrinquedos de cosmeticos...\n1.803.23MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt1.setText(Integer.toString(quant));
        	
        	Image x2 = new Image("biblioteca/brinquedoF2.png");
			image2.setImage(x2);
			lab2.setText("Baldinho de Praia Menina\ncom Moldes e Pa Merco Toys\n391.5405.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt2.setText(Integer.toString(quant));
        	
        	Image x3 = new Image("biblioteca/brinquedoF3.png");
			image3.setImage(x3);
			lab3.setText("GLAMOUR FLIP DA BARBIE -\nRADIO CONTROLE, Candide,\nrosa\nCandide\n841.609.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt3.setText(Integer.toString(quant));
        	
        	Image x4 = new Image("biblioteca/brinquedoF4.png");
			image4.setImage(x4);
			lab4.setText("Nova Big Cozinha Infantil\nCompleta, Big Star, 630-NBC,\nRosa\nPlastico\n1.337.5427MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt4.setText(Integer.toString(quant));
        	
        	Image x5 = new Image("biblioteca/brinquedoF5.png");
			image5.setImage(x5);
			lab5.setText("Brinquedo Boneca Baby Alive\nHora do Xixi Loira - Com\nRoupinha removivel e...\n1.157.9763MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt5.setText(Integer.toString(quant));
        	
        	Image x6 = new Image("biblioteca/brinquedoF6.png");
			image6.setImage(x6);
			lab6.setText("Maleta - Doutor Canino Roma\nJensen Rosa\nPolipropileno\n1.186.0966MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt6.setText(Integer.toString(quant));
	    }

	    @FXML
	    void OnRadioMascAction(ActionEvent event) {
	    	c1.setVisible(true);
			c2.setVisible(true);
			c3.setVisible(true);
			c4.setVisible(true);
			c5.setVisible(true);
			c6.setVisible(true);
			image1.setVisible(true);
			image2.setVisible(true);
			image3.setVisible(true);
			image4.setVisible(true);
			image5.setVisible(true);
			lab1.setVisible(true);
			lab2.setVisible(true);
			lab3.setVisible(true);
			lab4.setVisible(true);
			lab5.setVisible(true);
			lab6.setVisible(true);
			qnt1.setVisible(true);
			qnt2.setVisible(true);
			qnt3.setVisible(true);
			qnt4.setVisible(true);
			qnt5.setVisible(true);
			qnt6.setVisible(true);
			tot.setVisible(true);
			totfield.setVisible(true);
			MT.setVisible(true);
			Q1.setVisible(true);
			Q2.setVisible(true);
			Q3.setVisible(true);
			Q4.setVisible(true);
			Q5.setVisible(true);
			Q6.setVisible(true);
			cc1.setVisible(true);
			cc2.setVisible(true);
			cc3.setVisible(true);
			cc4.setVisible(true);
			cc5.setVisible(true);
			cc6.setVisible(true);
			check.setVisible(true);
			adcar1.setVisible(true);
			adcar2.setVisible(true);
			addcar3.setVisible(true);
			addcar4.setVisible(true);
			addcar5.setVisible(true);
			addcar6.setVisible(true);
			
			Image x = new Image("biblioteca/brinquedoM1.png");
			image1.setImage(x);
			lab1.setText("Brincando de Engenheiro 120\nPecas Xalingo, Multicor\nPlastico\n473.1272.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt1.setText(Integer.toString(quant));
        	
        	Image x2 = new Image("biblioteca/brinquedoM2.png");
			image2.setImage(x2);
			lab2.setText("Express Wheels Garagem\nPolicia 40 Pecas MuktiKids -\nBR1237\nPlastico\n665.6819.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt2.setText(Integer.toString(quant));
        	
        	Image x3 = new Image("biblioteca/brinquedoM3.png");
			image3.setImage(x3);
			lab3.setText("Robo Agil com Luzes e Sons -\nBate e Volta - 1039\n679.5529.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt3.setText(Integer.toString(quant));
        	
        	Image x4 = new Image("biblioteca/brinquedoM4.png");
			image4.setImage(x4);
			lab4.setText("11013 LEGO� Classic Blocos\nTransparentes Criativos; Kit\nde Construcao para Crianca...\nPlastico\n2.079.389MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt4.setText(Integer.toString(quant));
        	
        	Image x5 = new Image("biblioteca/brinquedoM5.png");
			image5.setImage(x5);
			lab5.setText("Bateria De Brinquedo Infantil\nInstrumento Musical Para\nCriancas Meninos...\n813.345.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt5.setText(Integer.toString(quant));
        	
        	Image x6 = new Image("biblioteca/brinquedoM6.png");
			image6.setImage(x6);
			lab6.setText("KKcare Carro RC carro de\ncontrole remoto RC carro de\ncorrida 1\n18 2,4 GHz RC Dri...\n1638.039.00MT");
			quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt6.setText(Integer.toString(quant));
	    }
	    
	    @FXML
		public void totAction(ActionEvent event) {
	    	if(Fem.isSelected()) {
	    		Brinquedos b1 = new Brinquedos(quant1,1803.23);
	    		Brinquedos b2 = new Brinquedos(quant2,391.5405);
	    		Brinquedos b3 = new Brinquedos(quant3,841.609);
	    		Brinquedos b4 = new Brinquedos(quant4,1337.5427);
	    		Brinquedos b5 = new Brinquedos(quant5,1157.9763);
	    		Brinquedos b6 = new Brinquedos(quant6,1186.0966);
	    		 total1=((b1.getQuantaty()*b1.getValorUten())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	}else if(Masc.isSelected()) {
	    		Brinquedos b1 = new Brinquedos(quant1,473.1272);
	    		Brinquedos b2 = new Brinquedos(quant2,665.6819);
	    		Brinquedos b3 = new Brinquedos(quant3,679.5529);
	    		Brinquedos b4 = new Brinquedos(quant4,2079.389);
	    		Brinquedos b5 = new Brinquedos(quant5,813.345);
	    		Brinquedos b6 = new Brinquedos(quant6,1638.039);
	    		 total2=((b1.getQuantaty()*b1.getValorUten())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	}
	    	
	    	total = total1+total2;
			 totfield.setText(Double.toString(total));
			paypalPagamentoController pag = new paypalPagamentoController();
			CartaoController card = new CartaoController();
			card.voi(total);
			pag.voi(total);
			 
	    }
	    
	  
	    
	    @FXML
	    void OnAdCarrinho1Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	 
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    	
	    	
	    
	    }

	    @FXML
	    void OnAdCarrinho2Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    	
		    	
	    	
	    }

	    @FXML
	    void OnAdCarrinho3Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho4Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho5Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }

	    @FXML
	    void OnAdCarrinho6Action(ActionEvent event) {
	    	try {
	    		cont++;
	    	if(cont<=3) {
	    	 MenuController.setCarrinhoValue(Integer.toString(cont));
	    	 cartbtn.setText(Integer.toString(cont));
	    	
	    	}else {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
	    		alert.setTitle("Atencao");
	    		alert.show();
	    		
	    	}
	    	}catch(Exception e) {
	    		System.out.println(e.getMessage());
	    	}
	    }
	    
	    @FXML
	    void OnCartAction(ActionEvent event) throws IOException {
	    	
	    	if(Masc.isSelected()) {
	    		
	    		Brinquedos b1 = new Brinquedos(quant1,473.1272);
	    		Brinquedos b2 = new Brinquedos(quant2,665.6819);
	    		Brinquedos b3 = new Brinquedos(quant3,679.5529);
	    		Brinquedos b4 = new Brinquedos(quant4,2079.389);
	    		Brinquedos b5 = new Brinquedos(quant5,813.345);
	    		Brinquedos b6 = new Brinquedos(quant6,1638.039);
	    		
	    		
	    	if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	double totAl = (b1.getValorUten()*b1.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab2.getText();
		    	Image i = image2.getImage();
		    	String quantidadeTotal = qnt2.getText();
		    	double totAl = (b2.getValorUten()*b2.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab3.getText();
		    	Image i = image3.getImage();
		    	String quantidadeTotal = qnt3.getText();
		    	
		    	double totAl = (b3.getValorUten()*b3.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab4.getText();
		    	Image i = image4.getImage();
		    	String quantidadeTotal = qnt4.getText();
		    	double totAl = (b4.getValorUten()*b4.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    		
	    		String txt1 = lab5.getText();
		    	Image i = image5.getImage();
		    	String quantidadeTotal = qnt5.getText();
		    	
		    	double totAl = (b5.getValorUten()*b5.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    		
	    		String txt1 = lab6.getText();
		    	Image i = image6.getImage();
		    	String quantidadeTotal = qnt6.getText();
		    	
		    	double totAl = (b6.getValorUten()*b6.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    	}
	    	
	    	
	    	
	    	if(quant1>=1 && quant2>=1) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	
		    	
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant1>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant6>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant5>=1 && quant6>=1){
	    		
	    		String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i5, txt5);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	 
	    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i3, txt3);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	 
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	
	    	}
	    	
	    	if(Fem.isSelected()) {
	    		
	    		Brinquedos b1 = new Brinquedos(quant1,1803.23);
	    		Brinquedos b2 = new Brinquedos(quant2,391.5405);
	    		Brinquedos b3 = new Brinquedos(quant3,841.609);
	    		Brinquedos b4 = new Brinquedos(quant4,1337.5427);
	    		Brinquedos b5 = new Brinquedos(quant5,1157.9763);
	    		Brinquedos b6 = new Brinquedos(quant6,1186.0966);
	    		
	    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	String quantidadeTotal = qnt1.getText();
			    	double totAl = (b1.getValorUten()*b1.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab2.getText();
			    	Image i = image2.getImage();
			    	String quantidadeTotal = qnt2.getText();
			    	double totAl = (b2.getValorUten()*b2.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    		
		    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab3.getText();
			    	Image i = image3.getImage();
			    	String quantidadeTotal = qnt3.getText();
			    	
			    	double totAl = (b3.getValorUten()*b3.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
		    		
		    		String txt1 = lab4.getText();
			    	Image i = image4.getImage();
			    	String quantidadeTotal = qnt4.getText();
			    	double totAl = (b4.getValorUten()*b4.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
		    		
		    		String txt1 = lab5.getText();
			    	Image i = image5.getImage();
			    	String quantidadeTotal = qnt5.getText();
			    	
			    	double totAl = (b5.getValorUten()*b5.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
		    		
		    		String txt1 = lab6.getText();
			    	Image i = image6.getImage();
			    	String quantidadeTotal = qnt6.getText();
			    	
			    	double totAl = (b6.getValorUten()*b6.getQuantaty());
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.quantaty1(quantidadeTotal);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    	}
		    	
		    	
		    	
		    	if(quant1>=1 && quant2>=1) {
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	
			    	
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
		    		
		    	}else if(quant1>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i = image1.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i, txt1);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant2>=1 && quant3>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant4>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant5>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	 
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant6>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant3>=1 && quant4>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant3>=1 && quant5>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant3>=1 && quant6>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant4>=1 && quant5>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant4>=1 && quant6>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant5>=1 && quant6>=1){
		    		
		    		String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	 
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i5, txt5);
			    	carrinho.imagemteste2(i6, txt6);
			    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	 
		    	if(quant1>=1 && quant2>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i3, txt3);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant1>=1 && quant2>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i2, txt2);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant1>=1 && quant3>=1 && quant4>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
		    		
		    		String txt1 = lab1.getText();
			    	Image i1 = image1.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal = qnt1.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i1, txt1);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant2>=1 && quant3>=1 && quant4>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	 
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i3, txt3);
			    	carrinho.imagemteste3(i4, txt4);
			    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
		    		
		    		String txt2 = lab2.getText();
			    	Image i2 = image2.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal2 = qnt2.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i2, txt2);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant3>=1 && quant4>=1 && quant5>=1){
		    		
		    		String txt3 = lab3.getText();
			    	Image i3 = image3.getImage();
			    	 
			    	String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String quantidadeTotal3 = qnt3.getText();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	
			    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i3, txt3);
			    	carrinho.imagemteste2(i4, txt4);
			    	carrinho.imagemteste3(i5, txt5);
			    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
		    	if(quant4>=1 && quant5>=1 && quant6>=1){
		    		
		    		String txt4 = lab4.getText();
			    	Image i4 = image4.getImage();
			    	 
			    	String txt5 = lab5.getText();
			    	Image i5 = image5.getImage();
			    	
			    	String txt6 = lab6.getText();
			    	Image i6 = image6.getImage();
			    	
			    	String quantidadeTotal4 = qnt4.getText();
			    	
			    	String quantidadeTotal5 = qnt5.getText();
			    	
			    	String quantidadeTotal6 = qnt6.getText();
			    	
			    	
			    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
			    	Double.toString(totAl);
					String valor = String.format("%.2f",totAl);
			    	 
			    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
			    	root = loader.load();
			    	
			    	CarrinhoController carrinho = loader.getController();
			    	carrinho.imagemteste(i4, txt4);
			    	carrinho.imagemteste2(i5, txt5);
			    	carrinho.imagemteste3(i6, txt6);
			    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
			    	carrinho.TotalApagar(valor);
			    	
			    	Stage stage2 = new Stage();
			    	Scene scene = new Scene(root);
			    	stage2.setScene(scene);
			    	stage2.show();
			    	
		    	}
		    	
	    	}
	    }
	    
		public void initialize(URL arg0, ResourceBundle arg1) {
			
			
		}
		
		public double aumentar(String valor) {
			double valor2 = Double.parseDouble(valor);
			valor2=valor2+1;
			return valor2;
		}
		
		

}
