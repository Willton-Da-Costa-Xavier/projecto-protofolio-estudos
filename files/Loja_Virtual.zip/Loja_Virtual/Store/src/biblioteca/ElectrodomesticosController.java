package biblioteca;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import classes.Electrodomesticos;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ElectrodomesticosController {
	
	private Parent root;
	private Stage stage;
	private Scene scene;
	
	@FXML
    private Button c1;
	
private static double val2;
public static int cont;
	
	static {
		val2=0;
		cont=0;
	}

    @FXML
    private Button c2;

    @FXML
    private Button c3;
    
    @FXML
    private Button cartbtn;

    @FXML
    private Button c4;

    @FXML
    private Button c5;

    @FXML
    private Button c6;
    
    @FXML
    private TextField qnt1;
    
    @FXML
    private TextField qnt2;

    @FXML
    private TextField qnt3;

    @FXML
    private TextField qnt4;

    @FXML
    private TextField qnt5;

    @FXML
    private TextField qnt6;


    @FXML
    private ImageView image1;

    @FXML
    private ImageView image2;

    @FXML
    private ImageView image3;

    @FXML
    private ImageView image4;

    @FXML
    private ImageView image5;

    @FXML
    private ImageView image6;
    
    @FXML
    private Label lab1;

    @FXML
    private Label lab2;

    @FXML
    private Label lab3;

    @FXML
    private Label lab4;

    @FXML
    private Label lab5;

    @FXML
    private Label lab6;
    
    @FXML
    private Button tot;

    @FXML
    private TextField totfield;
    
    @FXML
    private Button cc1;

    @FXML
    private Button cc2;

    @FXML
    private Button cc3;

    @FXML
    private Button cc4;

    @FXML
    private Button cc5;

    @FXML
    private Button cc6;

    @FXML
    private Button check;
    
    double total=0;
    double total1=0;
    double total2=0;
    double total3=0;
    double total4=0;
    double total5=0;
    double total6=0;
    double total7=0;
    double total8=0;
    double total9=0;
    
    
    int quant =0;
    int quant1 =0;
    int quant2 =0;
    int quant3 =0;
    int quant4 =0;
    int quant5 =0;
    int quant6 =0;
    @FXML
    private Label MT;

    @FXML
    private Label Q1;

    @FXML
    private Label Q2;

    @FXML
    private Label Q3;

    @FXML
    private Label Q4;

    @FXML
    private Label Q5;

    @FXML
    private Label Q6;
    
    
    @FXML
    private TextField txtpesquisa;
    
    @FXML
    private AnchorPane anchor;
    
    @FXML
    private Button adcar1;

    @FXML
    private Button adcar2;

    @FXML
    private Button adcar3;

    @FXML
    private Button adcar4;

    @FXML
    private Button adcar5;

    @FXML
    private Button adcar6;
    
    private Button bt;
    
    private Label  labelex;
    
    private Label  labelex2;
    
    private Label lab32;
    
    private Label lab43;
    
    
    
    
    
    
    @FXML
    void PesquisaAction(ActionEvent event) throws FileNotFoundException {
    	
    	c1.setVisible(true);
		c2.setVisible(true);
		c3.setVisible(true);
		c4.setVisible(true);
		c5.setVisible(true);
		c6.setVisible(true);
		image1.setVisible(true);
		image2.setVisible(true);
		image3.setVisible(true);
		image4.setVisible(true);
		image5.setVisible(true);
		lab1.setVisible(true);
		lab2.setVisible(true);
		lab3.setVisible(true);
		lab4.setVisible(true);
		lab5.setVisible(true);
		lab6.setVisible(true);
		qnt1.setVisible(true);
		qnt2.setVisible(true);
		qnt3.setVisible(true);
		qnt4.setVisible(true);
		qnt5.setVisible(true);
		qnt6.setVisible(true);
		tot.setVisible(true);
		totfield.setVisible(true);
		MT.setVisible(true);
		Q1.setVisible(true);
		Q2.setVisible(true);
		Q3.setVisible(true);
		Q4.setVisible(true);
		Q5.setVisible(true);
		Q6.setVisible(true);
		cc1.setVisible(true);
		cc2.setVisible(true);
		cc3.setVisible(true);
		cc4.setVisible(true);
		cc5.setVisible(true);
		cc6.setVisible(true);
		check.setVisible(true);
		adcar1.setVisible(true);
		adcar2.setVisible(true);
		adcar3.setVisible(true);
		adcar4.setVisible(true);
		adcar5.setVisible(true);
		adcar6.setVisible(true);
		labelex2.setVisible(false);
		labelex.setVisible(false);
		bt.setVisible(false);
		lab32.setVisible(false);
		lab43.setVisible(false);
		
	
    	
    	if(txtpesquisa.getText().equalsIgnoreCase("PC Gamer") || txtpesquisa.getText().equalsIgnoreCase("Gaming PC")) {
    		FileInputStream fi = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\comp1.png");
        	Image x = new Image(fi);
        	image1.setImage(x);
        	lab1.setText("Skill Gaming PC Gamer\nAMD 6-Core CPU 3.8Ghz 8GB\n23.587.11MT");
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	qnt1.setText(Integer.toString(quant));
        	
        	FileInputStream fi2 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\comp2.png");
        	Image x2 = new Image(fi2);
        	image2.setImage(x2);
        	lab2.setText("PC Gamer ITX Arena Setup\nRyzen 5 PRO 4650G, 16GB\n(2x8GB) DDR4, SSD 240GB\n31.533.56MT");
        	qnt2.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi3 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\comp3.png");
        	Image x3 = new Image(fi3);
        	image3.setImage(x3);
        	lab3.setText("Skill Gaming PC Gamer\nCompleto AMD 6-Core CPU\n3.8Ghz 8GB\n26.417.41MT");
        	qnt3.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi4 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\laptop1.png");
        	Image x4 = new Image(fi4);
        	image4.setImage(x4);
        	lab4.setText("Notebook ideapad Gaming 3i\ni5-11300H 8GB 512GB\nDedicada GTX 1650\n52.724.12MT");
        	qnt4.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi5 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\laptop2.png");
        	Image x5 = new Image(fi5);
        	image5.setImage(x5);
        	lab5.setText("ACER Notebook Gamer Nitro\n5 AN515-55-59T4, Intel Core\n I5 10 geracao\n58.652.43MT");
        	qnt5.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi6 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\laptop3.png");
        	Image x6 = new Image(fi6);
        	image6.setImage(x6);
        	lab6.setText("Notebook ideapad Gaming\n3i,Intel Core i5-11300H,8GB\nRAM, 256GB SSD\n55.612.59MT");
        	qnt6.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Geleira") || txtpesquisa.getText().equalsIgnoreCase("Geladeira")) {
    		FileInputStream fi = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\geleira1.png");
        	Image x = new Image(fi);
        	image1.setImage(x);
        	lab1.setText("Geladeira/Refrigerador Frost\nFree cor Inox 310L Electrolux\n(TF39S) 127V\n35.317.59MT");
        	qnt1.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi2 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\geleira2.png");
        	Image x2 = new Image(fi2);
        	image2.setImage(x2);
        	lab2.setText("Geladeira Top Freezer com\nDispenser de Agua Platinum\n400L(DW44S) 220V\n41.624.30MT");
        	qnt2.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi3 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\geleira3.png");
        	Image x3 = new Image(fi3);
        	image3.setImage(x3);
        	lab3.setText("Geladeira Frost Free\nBrastemp Inverse 2 Portas\n443L Evox BRE57AK 127V\n59.030.83MT");
        	qnt3.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi4 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\geleira4.png");
        	Image x4 = new Image(fi4);
        	image4.setImage(x4);
        	lab4.setText("Geladeira Consult Frost Free\nDuplex 386 litros Branca com\nPrateleira Dobravel\n38.556.01MT");
        	qnt4.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi5 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\geleira5.png");
        	Image x5 = new Image(fi5);
        	image5.setImage(x5);
        	lab5.setText("Geladeira Panasonic Frost\nFree 425L A+++ Black Glass -\nNR-BB53GV3B\n66.851.15MT");
        	qnt5.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi6 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\geleira6.png");
        	Image x6 = new Image(fi6);
        	image6.setImage(x6);
        	lab6.setText("Geladeira Side By Side Eco\nInverter Philo 434 Litros\nInox Prf533id - 220v\n70.496.43MT");
        	qnt6.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Torradeira") || txtpesquisa.getText().equalsIgnoreCase("Toradeira")) {
    		FileInputStream fi = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\torra1.png");
        	Image x = new Image(fi);
        	image1.setImage(x);
        	lab1.setText("Torradeira 2 Paes 730W,\n220V, Masterchef\nTO2002P/02, Preta\n1.261.34MT");
        	qnt1.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi2 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\torra2.png");
        	Image x2 = new Image(fi2);
        	image2.setImage(x2);
        	lab2.setText("Torradeira 4 Paes Premium\n1600W, 127V, Masterchef\nTO3004V/01, Vermelho\n2.522.69MT");
        	qnt2.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi3 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\torra3.png");
        	Image x3 = new Image(fi3);
        	image3.setImage(x3);
        	lab3.setText("Torradeira ETS10 Electrolux\n2.257.80MT");
        	qnt3.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi4 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\torra4.png");
        	Image x4 = new Image(fi4);
        	image4.setImage(x4);
        	lab4.setText("Torradeira BTR01P 127V\n2.261.34MT");
        	qnt4.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi5 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\torra5.png");
        	Image x5 = new Image(fi5);
        	image5.setImage(x5);
        	lab5.setText("Torradeira Oster 127 -\nOTOR650, Modelo:\nOTOR650-127V\n2.005.53MT");
        	qnt5.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi6 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\torra6.png");
        	Image x6 = new Image(fi6);
        	image6.setImage(x6);
        	lab6.setText("Torradeira Retro, Ptr02v,\nVermelho, 110V, Philco\n2.333.48MT");
        	qnt6.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Televisor") || txtpesquisa.getText().equalsIgnoreCase("Tv")) {
    		FileInputStream fi = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\tv1.png");
        	Image x = new Image(fi);
        	image1.setImage(x);
        	lab1.setText("Smart TV LED 32\" HD LG\n32LQ621CBSB.AWZ - IA LG\nThinQ, Alexa built-in\n14.883.84MT");
        	qnt1.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi2 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\tv2.png");
        	Image x2 = new Image(fi2);
        	image2.setImage(x2);
        	lab2.setText("Smart TV LED 24\" Monitor LG\n24TL520S, Wi-Fi, WebOS 3.5,\nDTV Machine Ready\n10.555.42MT");
        	qnt2.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi3 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\tv3.png");
        	Image x3 = new Image(fi3);
        	image3.setImage(x3);
        	lab3.setText("SAMSUNG, TV Smart 50\nBEAHVGGXZD\n34.686.92MT");
        	qnt3.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi4 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\tv4.png");
        	Image x4 = new Image(fi4);
        	image4.setImage(x4);
        	lab4.setText("Smart TV LED 32\" HD\nSAMSUNG LH32BETBLGGXZD\n14.877.79MT");
        	qnt4.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi5 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\tv5.png");
        	Image x5 = new Image(fi5);
        	image5.setImage(x5);
        	lab5.setText("Smart TV LED 43\" Full HD\nAOC ROKU TV FHD\n43S5195/78G, Wi-Fi\n20.118.41MT");
        	qnt5.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi6 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\tv6.png");
        	Image x6 = new Image(fi6);
        	image6.setImage(x6);
        	lab6.setText("Smart TV LED 32\" HD HQ\nConversor Digital Externo 3\nHDMI 2 USB WI-FI Android\n13.034.59MT");
        	qnt6.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Microonda") || txtpesquisa.getText().equalsIgnoreCase("Microondas")) {
    		FileInputStream fi = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\micro1.png");
        	Image x = new Image(fi);
        	image1.setImage(x);
        	lab1.setText("MICRO-ONDAS PANASONIC\n21LT NN-ST27LWRUN 700W\n127V ESPELHADA (AM)\n6.811.25MT");
        	qnt1.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi2 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\micro2.png");
        	Image x2 = new Image(fi2);
        	image2.setImage(x2);
        	lab2.setText("MICRO-ONDAS, MEO44, 34L,\nBranco, 110v, Electrolux\n7.161.90MT");
        	qnt2.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi3 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\micro3.png");
        	Image x3 = new Image(fi3);
        	image3.setImage(x3);
        	lab3.setText("MICRO-ONDAS, MS37R, 27L,\nPreta, 110v, Electrolux\n10.090.74MT");
        	qnt3.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi4 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\micro4.png");
        	Image x4 = new Image(fi4);
        	image4.setImage(x4);
        	lab4.setText("Forno Micro-ondas 20L\nBranco Espelhado Midea\n127V MRAM21\n6.598.97MT");
        	qnt4.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi5 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\micro5.png");
        	Image x5 = new Image(fi5);
        	image5.setImage(x5);
        	lab5.setText("Microondas,\n31L,Branco/Preto, 110v,\nMidea\n6.672.50MT");
        	qnt5.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi6 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\micro6.png");
        	Image x6 = new Image(fi6);
        	image6.setImage(x6);
        	lab6.setText("Micro-ondas Panasonic NN-\nST25LWRUN 21L Branco,\n110v\n6.672.50MT");
        	qnt6.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
    	}else if(txtpesquisa.getText().equalsIgnoreCase("PS5") || txtpesquisa.getText().equalsIgnoreCase("Playstation 5")) {
    		FileInputStream fi = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\ps5_1.png");
        	Image x = new Image(fi);
        	image1.setImage(x);
        	lab1.setText("Console Playstation�5 +\nHorizon Forbidden West\n53.911.04MT");
        	qnt1.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi2 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\ps5_2.png");
        	Image x2 = new Image(fi2);
        	image2.setImage(x2);
        	lab2.setText("Console Playstation�5 +\nFIFA 23\n54.488.86MT");
        	qnt2.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi3 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\ps5_3.png");
        	Image x3 = new Image(fi3);
        	image3.setImage(x3);
        	lab3.setText("Console Playstation�5 + God Of War\nRagnarok\n60.544.44MT");
        	qnt3.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi4 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\ps5head.png");
        	Image x4 = new Image(fi4);
        	image4.setImage(x4);
        	lab4.setText("Headeset sem fio PULSE 3D -\nPlaystation 5\n6.685.12MT");
        	qnt4.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi5 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\ps5con.png");
        	Image x5 = new Image(fi5);
        	image5.setImage(x5);
        	lab5.setText("Controle DualSense - Branco\n4.993.78MT");
        	qnt5.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
        	
        	FileInputStream fi6 = new FileInputStream("C:\\Users\\willt\\Desktop\\Everything\\Programas\\Store\\src\\biblioteca\\ps5game.png");
        	Image x6 = new Image(fi6);
        	image6.setImage(x6);
        	lab6.setText("Marvel's Spider-Man: Miles\nMorales Edicao Padrao -\nPlaystation 5\n1.765.88MT");
        	qnt6.setText(Integer.toString(quant));
        	quant1=0;
        	quant2=0;
        	quant3=0;
        	quant4=0;
        	quant5=0;
        	quant6=0;
    	}else {
    		c1.setVisible(false);
			c2.setVisible(false);
			c3.setVisible(false);
			c4.setVisible(false);
			c5.setVisible(false);
			c6.setVisible(false);
			image1.setVisible(false);
			image2.setVisible(false);
			image3.setVisible(false);
			image4.setVisible(false);
			image5.setVisible(false);
			lab1.setVisible(false);
			lab2.setVisible(false);
			lab3.setVisible(false);
			lab4.setVisible(false);
			lab5.setVisible(false);
			lab6.setVisible(false);
			qnt1.setVisible(false);
			qnt2.setVisible(false);
			qnt3.setVisible(false);
			qnt4.setVisible(false);
			qnt5.setVisible(false);
			qnt6.setVisible(false);
			tot.setVisible(false);
			totfield.setVisible(false);
			MT.setVisible(false);
			Q1.setVisible(false);
			Q2.setVisible(false);
			Q3.setVisible(false);
			Q4.setVisible(false);
			Q5.setVisible(false);
			Q6.setVisible(false);
			cc1.setVisible(false);
			cc2.setVisible(false);
			cc3.setVisible(false);
			cc4.setVisible(false);
			cc5.setVisible(false);
			cc6.setVisible(false);
			check.setVisible(false);
			 labelex = new Label();
			 bt = new Button();
			 labelex2 = new Label();
			labelex.setText(txtpesquisa.getText()+" Nao existe");
			bt.setText("Verificar no Stock");
			labelex2.setText("Clique no botao Abaixo para verificar no Stock");
			labelex.setTranslateX(450);
			labelex.setTranslateY(200);
			labelex2.setTranslateX(350);
			labelex2.setTranslateY(230);
			bt.setTranslateX(440);
			bt.setTranslateY(260);
			bt.setStyle("-fx-font-size: 18");
			labelex.setStyle("-fx-font-size: 18");
			labelex2.setStyle("-fx-font-size: 18");
//			bt.setStyle("-fx-text-fill: #fcfcfc");
//			bt.setStyle("-fx-background-color: blue");
			anchor.getChildren().add(labelex);
			anchor.getChildren().add(bt);
			anchor.getChildren().add(labelex2);
			bt.setOnAction(new EventHandler <ActionEvent>() {
				
				public void handle(ActionEvent event) {
				 lab32 = new Label();
				 lab43 = new Label();
				lab43.setText("Procurando no Stock");
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				lab32.setText("Nao foi encontrado o produto "+txtpesquisa.getText()+" no Stock");
				lab32.setTranslateX(400);
				lab32.setTranslateY(235);
				lab43.setTranslateX(475);
				lab43.setTranslateY(200);
				lab32.setStyle("-fx-font-size: 18");
				lab43.setStyle("-fx-font-size: 18");
				labelex.setVisible(false);
				labelex2.setVisible(false);
				bt.setVisible(false);
				anchor.getChildren().add(lab32);
				}
				});
    	}
    }
    
    

    @FXML
    void backAction(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("menu.fxml"));
    	root = loader.load();
    	
    	stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    	scene = new Scene(root);
    	stage.setScene(scene);
    	stage.show();
    }

   
    @FXML
    void compra1Action(ActionEvent event) {
    	quant1++;
    	qnt1.setText(Integer.toString(quant1));
    }

    @FXML
    void compra2Action(ActionEvent event) {
    	quant2++;
    	qnt2.setText(Integer.toString(quant2));
    }

    @FXML
    void compra3Action(ActionEvent event) {
    	quant3++;
    	qnt3.setText(Integer.toString(quant3));
    }

    @FXML
    void compra4Action(ActionEvent event) {
    	quant4++;
    	qnt4.setText(Integer.toString(quant4));
    }

    @FXML
    void compra5Action(ActionEvent event) {
    	quant5++;
    	qnt5.setText(Integer.toString(quant5));
    }

    @FXML
    void compra6Action(ActionEvent event) {
    	quant6++;
    	qnt6.setText(Integer.toString(quant6));
    }
    
    @FXML
    void totAction(ActionEvent event) {
    	if(txtpesquisa.getText().equalsIgnoreCase("PC Gamer") || txtpesquisa.getText().equalsIgnoreCase("Gaming PC")) {
    		Electrodomesticos e1 = new Electrodomesticos(quant1,23587.11);
    		Electrodomesticos e2 = new Electrodomesticos(quant2,31533.56);
    		Electrodomesticos e3 = new Electrodomesticos(quant3,26417.41);
    		Electrodomesticos e4 = new Electrodomesticos(quant4,52724.12);
    		Electrodomesticos e5 = new Electrodomesticos(quant5,58652.43);
    		Electrodomesticos e6 = new Electrodomesticos(quant6,55612.59);
    		 total1=((e1.getQuantaty()*e1.getValorUten())+(e2.getQuantaty()*e2.getValorUten())+(e3.getQuantaty()*e3.getValorUten())+(e4.getQuantaty()*e4.getValorUten())+(e5.getQuantaty()*e5.getValorUten())+(e6.getQuantaty()*e6.getValorUten()));
       		// totfield.setText(Double.toString(total));
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Geleira") || txtpesquisa.getText().equalsIgnoreCase("Geladeira")) {
    		Electrodomesticos e1 = new Electrodomesticos(quant1,35317.59);
    		Electrodomesticos e2 = new Electrodomesticos(quant2,41624.30);
    		Electrodomesticos e3 = new Electrodomesticos(quant3,59030.83);
    		Electrodomesticos e4 = new Electrodomesticos(quant4,38556.01);
    		Electrodomesticos e5 = new Electrodomesticos(quant5,66851.15);
    		Electrodomesticos e6 = new Electrodomesticos(quant6,70496.43);
    		 total2=((e1.getQuantaty()*e1.getValorUten())+(e2.getQuantaty()*e2.getValorUten())+(e3.getQuantaty()*e3.getValorUten())+(e4.getQuantaty()*e4.getValorUten())+(e5.getQuantaty()*e5.getValorUten())+(e6.getQuantaty()*e6.getValorUten()));
       		// totfield.setText(Double.toString(total));
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Torradeira") || txtpesquisa.getText().equalsIgnoreCase("Toradeira")) {
    		Electrodomesticos e1 = new Electrodomesticos(quant1,1261.34);
    		Electrodomesticos e2 = new Electrodomesticos(quant2,2522.69);
    		Electrodomesticos e3 = new Electrodomesticos(quant3,2257.80);
    		Electrodomesticos e4 = new Electrodomesticos(quant4,2261.34);
    		Electrodomesticos e5 = new Electrodomesticos(quant5,2005.53);
    		Electrodomesticos e6 = new Electrodomesticos(quant6,2333.48);
    		 total3=((e1.getQuantaty()*e1.getValorUten())+(e2.getQuantaty()*e2.getValorUten())+(e3.getQuantaty()*e3.getValorUten())+(e4.getQuantaty()*e4.getValorUten())+(e5.getQuantaty()*e5.getValorUten())+(e6.getQuantaty()*e6.getValorUten()));
       		// totfield.setText(Double.toString(total));
       		 
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Televisor") || txtpesquisa.getText().equalsIgnoreCase("Tv")) {
    		Electrodomesticos e1 = new Electrodomesticos(quant1,14883.84);
    		Electrodomesticos e2 = new Electrodomesticos(quant2,10555.42);
    		Electrodomesticos e3 = new Electrodomesticos(quant3,34686.92);
    		Electrodomesticos e4 = new Electrodomesticos(quant4,14877.79);
    		Electrodomesticos e5 = new Electrodomesticos(quant5,20118.41);
    		Electrodomesticos e6 = new Electrodomesticos(quant6,13034.59);
    		 total4=((e1.getQuantaty()*e1.getValorUten())+(e2.getQuantaty()*e2.getValorUten())+(e3.getQuantaty()*e3.getValorUten())+(e4.getQuantaty()*e4.getValorUten())+(e5.getQuantaty()*e5.getValorUten())+(e6.getQuantaty()*e6.getValorUten()));
       		// totfield.setText(Double.toString(total));
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Microonda") || txtpesquisa.getText().equalsIgnoreCase("Microondas")) {
    		Electrodomesticos e1 = new Electrodomesticos(quant1,6811.25);
    		Electrodomesticos e2 = new Electrodomesticos(quant2,7160.90);
    		Electrodomesticos e3 = new Electrodomesticos(quant3,10090.74);
    		Electrodomesticos e4 = new Electrodomesticos(quant4,6598.97);
    		Electrodomesticos e5 = new Electrodomesticos(quant5,6672.50);
    		Electrodomesticos e6 = new Electrodomesticos(quant6,6672.50);
    		 total5=((e1.getQuantaty()*e1.getValorUten())+(e2.getQuantaty()*e2.getValorUten())+(e3.getQuantaty()*e3.getValorUten())+(e4.getQuantaty()*e4.getValorUten())+(e5.getQuantaty()*e5.getValorUten())+(e6.getQuantaty()*e6.getValorUten()));
       		// totfield.setText(Double.toString(total));
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("PS5") || txtpesquisa.getText().equalsIgnoreCase("Playstation 5")) {
    		Electrodomesticos e1 = new Electrodomesticos(quant1,53910.04);
    		Electrodomesticos e2 = new Electrodomesticos(quant2,54488.86);
    		Electrodomesticos e3 = new Electrodomesticos(quant3,60544.44);
    		Electrodomesticos e4 = new Electrodomesticos(quant4,6685.12);
    		Electrodomesticos e5 = new Electrodomesticos(quant5,4993.78);
    		Electrodomesticos e6 = new Electrodomesticos(quant6,1765.88);
    		 total6=((e1.getQuantaty()*e1.getValorUten())+(e2.getQuantaty()*e2.getValorUten())+(e3.getQuantaty()*e3.getValorUten())+(e4.getQuantaty()*e4.getValorUten())+(e5.getQuantaty()*e5.getValorUten())+(e6.getQuantaty()*e6.getValorUten()));
       		// totfield.setText(Double.toString(total));
    	}
    	
    	total = total1+total2+total3+total4+total5+total6;
		 totfield.setText(Double.toString(total));
		 paypalPagamentoController pag = new paypalPagamentoController();
		 CartaoController card = new CartaoController();
			card.voi(total);
		 pag.voi(total);
    }
    
    @FXML
    void Menos1Action(ActionEvent event) {
	  quant1--;
    	qnt1.setText(Integer.toString(quant1));
    }

    @FXML
    void Menos2Action(ActionEvent event) {
    	quant2--;
    	qnt2.setText(Integer.toString(quant2));
    }

    @FXML
    void Menos3Action(ActionEvent event) {
    	quant3--;
    	qnt3.setText(Integer.toString(quant3));
    }

    @FXML
    void Menos4Action(ActionEvent event) {
    	quant4--;
    	qnt4.setText(Integer.toString(quant4));
    }

    @FXML
    void Menos5Action(ActionEvent event) {
    	quant5--;
    	qnt5.setText(Integer.toString(quant5));
    }

    @FXML
    void Menos6Action(ActionEvent event) {
    	quant6--;
    	qnt6.setText(Integer.toString(quant6));
    }
    
    @FXML
    void checkoutAction(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Checkout.fxml"));
		root = loader.load();
		
		Stage stage2 = new Stage();
		stage2.setScene(new Scene(root));
		stage2.show();
    }
    
    @FXML
    void OnAdCarrinho1Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	 
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
    	
    
    }

    @FXML
    void OnAdCarrinho2Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
	    	
    	
    }

    @FXML
    void OnAdCarrinho3Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }

    @FXML
    void OnAdCarrinho4Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }

    @FXML
    void OnAdCarrinho5Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }

    @FXML
    void OnAdCarrinho6Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }
    
    @FXML
    void OnCartAction(ActionEvent event) throws IOException {
    	if(txtpesquisa.getText().equalsIgnoreCase("PC Gamer") || txtpesquisa.getText().equalsIgnoreCase("Gaming PC")) {
    		
    		Electrodomesticos b1 = new Electrodomesticos(quant1,23587.11);
    		Electrodomesticos b2 = new Electrodomesticos(quant2,31533.56);
    		Electrodomesticos b3 = new Electrodomesticos(quant3,26417.41);
    		Electrodomesticos b4 = new Electrodomesticos(quant4,52724.12);
    		Electrodomesticos b5 = new Electrodomesticos(quant5,58652.43);
    		Electrodomesticos b6 = new Electrodomesticos(quant6,55612.59);
    		
    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	double totAl = (b1.getValorUten()*b1.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab2.getText();
		    	Image i = image2.getImage();
		    	String quantidadeTotal = qnt2.getText();
		    	double totAl = (b2.getValorUten()*b2.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab3.getText();
		    	Image i = image3.getImage();
		    	String quantidadeTotal = qnt3.getText();
		    	
		    	double totAl = (b3.getValorUten()*b3.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab4.getText();
		    	Image i = image4.getImage();
		    	String quantidadeTotal = qnt4.getText();
		    	double totAl = (b4.getValorUten()*b4.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    		
	    		String txt1 = lab5.getText();
		    	Image i = image5.getImage();
		    	String quantidadeTotal = qnt5.getText();
		    	
		    	double totAl = (b5.getValorUten()*b5.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    		
	    		String txt1 = lab6.getText();
		    	Image i = image6.getImage();
		    	String quantidadeTotal = qnt6.getText();
		    	
		    	double totAl = (b6.getValorUten()*b6.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    	}
	    	
	    	
	    	
	    	if(quant1>=1 && quant2>=1) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	
		    	
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant1>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant6>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant5>=1 && quant6>=1){
	    		
	    		String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i5, txt5);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	 
	    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i3, txt3);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	 
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
    		
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Geleira") || txtpesquisa.getText().equalsIgnoreCase("Geladeira")) {
    		
    		Electrodomesticos b1 = new Electrodomesticos(quant1,35317.59);
    		Electrodomesticos b2 = new Electrodomesticos(quant2,41624.30);
    		Electrodomesticos b3 = new Electrodomesticos(quant3,59030.83);
    		Electrodomesticos b4 = new Electrodomesticos(quant4,38556.01);
    		Electrodomesticos b5 = new Electrodomesticos(quant5,66851.15);
    		Electrodomesticos b6 = new Electrodomesticos(quant6,70496.43);
    		
    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	double totAl = (b1.getValorUten()*b1.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab2.getText();
		    	Image i = image2.getImage();
		    	String quantidadeTotal = qnt2.getText();
		    	double totAl = (b2.getValorUten()*b2.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab3.getText();
		    	Image i = image3.getImage();
		    	String quantidadeTotal = qnt3.getText();
		    	
		    	double totAl = (b3.getValorUten()*b3.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab4.getText();
		    	Image i = image4.getImage();
		    	String quantidadeTotal = qnt4.getText();
		    	double totAl = (b4.getValorUten()*b4.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    		
	    		String txt1 = lab5.getText();
		    	Image i = image5.getImage();
		    	String quantidadeTotal = qnt5.getText();
		    	
		    	double totAl = (b5.getValorUten()*b5.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    		
	    		String txt1 = lab6.getText();
		    	Image i = image6.getImage();
		    	String quantidadeTotal = qnt6.getText();
		    	
		    	double totAl = (b6.getValorUten()*b6.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    	}
	    	
	    	
	    	
	    	if(quant1>=1 && quant2>=1) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	
		    	
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant1>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant6>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant5>=1 && quant6>=1){
	    		
	    		String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i5, txt5);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	 
	    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i3, txt3);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	 
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
    	
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Torradeira") || txtpesquisa.getText().equalsIgnoreCase("Toradeira")) {
    		
    		Electrodomesticos b1 = new Electrodomesticos(quant1,1261.34);
    		Electrodomesticos b2 = new Electrodomesticos(quant2,2522.69);
    		Electrodomesticos b3 = new Electrodomesticos(quant3,2257.80);
    		Electrodomesticos b4 = new Electrodomesticos(quant4,2261.34);
    		Electrodomesticos b5 = new Electrodomesticos(quant5,2005.53);
    		Electrodomesticos b6 = new Electrodomesticos(quant6,2333.48);
    		
    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	double totAl = (b1.getValorUten()*b1.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab2.getText();
		    	Image i = image2.getImage();
		    	String quantidadeTotal = qnt2.getText();
		    	double totAl = (b2.getValorUten()*b2.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab3.getText();
		    	Image i = image3.getImage();
		    	String quantidadeTotal = qnt3.getText();
		    	
		    	double totAl = (b3.getValorUten()*b3.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab4.getText();
		    	Image i = image4.getImage();
		    	String quantidadeTotal = qnt4.getText();
		    	double totAl = (b4.getValorUten()*b4.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    		
	    		String txt1 = lab5.getText();
		    	Image i = image5.getImage();
		    	String quantidadeTotal = qnt5.getText();
		    	
		    	double totAl = (b5.getValorUten()*b5.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    		
	    		String txt1 = lab6.getText();
		    	Image i = image6.getImage();
		    	String quantidadeTotal = qnt6.getText();
		    	
		    	double totAl = (b6.getValorUten()*b6.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    	}
	    	
	    	
	    	
	    	if(quant1>=1 && quant2>=1) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	
		    	
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant1>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant6>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant5>=1 && quant6>=1){
	    		
	    		String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i5, txt5);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	 
	    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i3, txt3);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	 
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
    		
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Televisor") || txtpesquisa.getText().equalsIgnoreCase("Tv")) {
    		
    		Electrodomesticos b1 = new Electrodomesticos(quant1,14883.84);
    		Electrodomesticos b2 = new Electrodomesticos(quant2,10555.42);
    		Electrodomesticos b3 = new Electrodomesticos(quant3,34686.92);
    		Electrodomesticos b4 = new Electrodomesticos(quant4,14877.79);
    		Electrodomesticos b5 = new Electrodomesticos(quant5,20118.41);
    		Electrodomesticos b6 = new Electrodomesticos(quant6,13034.59);
    		
    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	double totAl = (b1.getValorUten()*b1.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab2.getText();
		    	Image i = image2.getImage();
		    	String quantidadeTotal = qnt2.getText();
		    	double totAl = (b2.getValorUten()*b2.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab3.getText();
		    	Image i = image3.getImage();
		    	String quantidadeTotal = qnt3.getText();
		    	
		    	double totAl = (b3.getValorUten()*b3.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab4.getText();
		    	Image i = image4.getImage();
		    	String quantidadeTotal = qnt4.getText();
		    	double totAl = (b4.getValorUten()*b4.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    		
	    		String txt1 = lab5.getText();
		    	Image i = image5.getImage();
		    	String quantidadeTotal = qnt5.getText();
		    	
		    	double totAl = (b5.getValorUten()*b5.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    		
	    		String txt1 = lab6.getText();
		    	Image i = image6.getImage();
		    	String quantidadeTotal = qnt6.getText();
		    	
		    	double totAl = (b6.getValorUten()*b6.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    	}
	    	
	    	
	    	
	    	if(quant1>=1 && quant2>=1) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	
		    	
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant1>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant6>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant5>=1 && quant6>=1){
	    		
	    		String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i5, txt5);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	 
	    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i3, txt3);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	 
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
    		
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("Microonda") || txtpesquisa.getText().equalsIgnoreCase("Microondas")) {
    		
    		Electrodomesticos b1 = new Electrodomesticos(quant1,6811.25);
    		Electrodomesticos b2 = new Electrodomesticos(quant2,7160.90);
    		Electrodomesticos b3 = new Electrodomesticos(quant3,10090.74);
    		Electrodomesticos b4 = new Electrodomesticos(quant4,6598.97);
    		Electrodomesticos b5 = new Electrodomesticos(quant5,6672.50);
    		Electrodomesticos b6 = new Electrodomesticos(quant6,6672.50);
    		
    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	double totAl = (b1.getValorUten()*b1.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab2.getText();
		    	Image i = image2.getImage();
		    	String quantidadeTotal = qnt2.getText();
		    	double totAl = (b2.getValorUten()*b2.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab3.getText();
		    	Image i = image3.getImage();
		    	String quantidadeTotal = qnt3.getText();
		    	
		    	double totAl = (b3.getValorUten()*b3.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab4.getText();
		    	Image i = image4.getImage();
		    	String quantidadeTotal = qnt4.getText();
		    	double totAl = (b4.getValorUten()*b4.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    		
	    		String txt1 = lab5.getText();
		    	Image i = image5.getImage();
		    	String quantidadeTotal = qnt5.getText();
		    	
		    	double totAl = (b5.getValorUten()*b5.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    		
	    		String txt1 = lab6.getText();
		    	Image i = image6.getImage();
		    	String quantidadeTotal = qnt6.getText();
		    	
		    	double totAl = (b6.getValorUten()*b6.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    	}
	    	
	    	
	    	
	    	if(quant1>=1 && quant2>=1) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	
		    	
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant1>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant6>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant5>=1 && quant6>=1){
	    		
	    		String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i5, txt5);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	 
	    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i3, txt3);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	 
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
    		
    		
    	}else if(txtpesquisa.getText().equalsIgnoreCase("PS5") || txtpesquisa.getText().equalsIgnoreCase("Playstation 5")) {
    		
    		Electrodomesticos b1 = new Electrodomesticos(quant1,53910.04);
    		Electrodomesticos b2 = new Electrodomesticos(quant2,54488.86);
    		Electrodomesticos b3 = new Electrodomesticos(quant3,60544.44);
    		Electrodomesticos b4 = new Electrodomesticos(quant4,6685.12);
    		Electrodomesticos b5 = new Electrodomesticos(quant5,4993.78);
    		Electrodomesticos b6 = new Electrodomesticos(quant6,1765.88);
    		
    		if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	double totAl = (b1.getValorUten()*b1.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab2.getText();
		    	Image i = image2.getImage();
		    	String quantidadeTotal = qnt2.getText();
		    	double totAl = (b2.getValorUten()*b2.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab3.getText();
		    	Image i = image3.getImage();
		    	String quantidadeTotal = qnt3.getText();
		    	
		    	double totAl = (b3.getValorUten()*b3.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
	    		
	    		String txt1 = lab4.getText();
		    	Image i = image4.getImage();
		    	String quantidadeTotal = qnt4.getText();
		    	double totAl = (b4.getValorUten()*b4.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
	    		
	    		String txt1 = lab5.getText();
		    	Image i = image5.getImage();
		    	String quantidadeTotal = qnt5.getText();
		    	
		    	double totAl = (b5.getValorUten()*b5.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
	    		
	    		String txt1 = lab6.getText();
		    	Image i = image6.getImage();
		    	String quantidadeTotal = qnt6.getText();
		    	
		    	double totAl = (b6.getValorUten()*b6.getQuantaty());
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.quantaty1(quantidadeTotal);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    	}
	    	
	    	
	    	
	    	if(quant1>=1 && quant2>=1) {
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	
		    	
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
	    		
	    	}else if(quant1>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i = image1.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i, txt1);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant3>=1 && quant6>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant4>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant5>=1 && quant6>=1){
	    		
	    		String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	 
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i5, txt5);
		    	carrinho.imagemteste2(i6, txt6);
		    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	 
	    	if(quant1>=1 && quant2>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i3, txt3);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant2>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i2, txt2);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant1>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
	    		
	    		String txt1 = lab1.getText();
		    	Image i1 = image1.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal = qnt1.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i1, txt1);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant2>=1 && quant3>=1 && quant4>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	 
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i3, txt3);
		    	carrinho.imagemteste3(i4, txt4);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt2 = lab2.getText();
		    	Image i2 = image2.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal2 = qnt2.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i2, txt2);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant3>=1 && quant4>=1 && quant5>=1){
	    		
	    		String txt3 = lab3.getText();
		    	Image i3 = image3.getImage();
		    	 
		    	String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String quantidadeTotal3 = qnt3.getText();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	
		    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i3, txt3);
		    	carrinho.imagemteste2(i4, txt4);
		    	carrinho.imagemteste3(i5, txt5);
		    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
	    	if(quant4>=1 && quant5>=1 && quant6>=1){
	    		
	    		String txt4 = lab4.getText();
		    	Image i4 = image4.getImage();
		    	 
		    	String txt5 = lab5.getText();
		    	Image i5 = image5.getImage();
		    	
		    	String txt6 = lab6.getText();
		    	Image i6 = image6.getImage();
		    	
		    	String quantidadeTotal4 = qnt4.getText();
		    	
		    	String quantidadeTotal5 = qnt5.getText();
		    	
		    	String quantidadeTotal6 = qnt6.getText();
		    	
		    	
		    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
		    	Double.toString(totAl);
				String valor = String.format("%.2f",totAl);
		    	 
		    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
		    	root = loader.load();
		    	
		    	CarrinhoController carrinho = loader.getController();
		    	carrinho.imagemteste(i4, txt4);
		    	carrinho.imagemteste2(i5, txt5);
		    	carrinho.imagemteste3(i6, txt6);
		    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
		    	carrinho.TotalApagar(valor);
		    	
		    	Stage stage2 = new Stage();
		    	Scene scene = new Scene(root);
		    	stage2.setScene(scene);
		    	stage2.show();
		    	
	    	}
	    	
    		
    		
    	}
    }
    
}

