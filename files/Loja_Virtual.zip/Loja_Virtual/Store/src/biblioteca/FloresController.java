package biblioteca;

import java.io.IOException;

import classes.Flores;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class FloresController {
	
	private Parent root;
	private Stage stage;
	private Scene scene;
	
	 double total=0;
	    double total1=0;
	    double total2=0;
	    double total3=0;
	    double total4=0;
	    double total5=0;
	    double total6=0;
	    double total7=0;
	    double total8=0;
	    double total9=0;
	    
	    private static double val3;
	    private static int cont;
		
		static {
			val3=0;
			cont=0;
		}
 
 int quant =0;
 int quant1 =0;
 int quant2 =0;
 int quant3 =0;
 int quant4 =0;
 int quant5 =0;
 int quant6 =0;

    @FXML
    private Label MT;

    @FXML
    private Label Q1;

    @FXML
    private Label Q2;

    @FXML
    private Label Q3;
    
    @FXML
    private Button adcar1;

    @FXML
    private Button adcar2;

    @FXML
    private Button addcar3;

    @FXML
    private Button addcar4;

    @FXML
    private Button addcar5;

    @FXML
    private Button addcar6;

    @FXML
    private Label Q4;

    @FXML
    private Label Q5;

    @FXML
    private Label Q6;

    @FXML
    private AnchorPane anchor;

    @FXML
    private Button c1;

    @FXML
    private Button c2;

    @FXML
    private Button c3;

    @FXML
    private Button c4;

    @FXML
    private Button c5;

    @FXML
    private Button c6;

    @FXML
    private Button cc1;

    @FXML
    private Button cc2;

    @FXML
    private Button cc3;

    @FXML
    private Button cc4;

    @FXML
    private Button cc5;

    @FXML
    private Button cc6;

    @FXML
    private Button check;
    
    @FXML
    private Button cartbtn;

    @FXML
    private ImageView image1;

    @FXML
    private ImageView image2;

    @FXML
    private ImageView image3;

    @FXML
    private ImageView image4;

    @FXML
    private ImageView image5;

    @FXML
    private ImageView image6;

    @FXML
    private Label lab1;

    @FXML
    private Label lab2;

    @FXML
    private Label lab3;

    @FXML
    private Label lab4;

    @FXML
    private Label lab5;

    @FXML
    private Label lab6;

    @FXML
    private TextField qnt1;

    @FXML
    private TextField qnt2;

    @FXML
    private TextField qnt3;

    @FXML
    private TextField qnt4;

    @FXML
    private TextField qnt5;

    @FXML
    private TextField qnt6;

    @FXML
    private Button tot;

    @FXML
    private TextField totfield;

    @FXML
    void Menos1Action(ActionEvent event) {
	  quant1--;
    	qnt1.setText(Integer.toString(quant1));
    }

    @FXML
    void Menos2Action(ActionEvent event) {
    	quant2--;
    	qnt2.setText(Integer.toString(quant2));
    }

    @FXML
    void Menos3Action(ActionEvent event) {
    	quant3--;
    	qnt3.setText(Integer.toString(quant3));
    }

    @FXML
    void Menos4Action(ActionEvent event) {
    	quant4--;
    	qnt4.setText(Integer.toString(quant4));
    }

    @FXML
    void Menos5Action(ActionEvent event) {
    	quant5--;
    	qnt5.setText(Integer.toString(quant5));
    }

    @FXML
    void Menos6Action(ActionEvent event) {
    	quant6--;
    	qnt6.setText(Integer.toString(quant6));
    }

	@FXML
	public void backAction(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("menu.fxml"));
		root = loader.load();
		
		stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

    @FXML
    void checkoutAction(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Checkout.fxml"));
		root = loader.load();
		
		Stage stage2 = new Stage();
		stage2.setScene(new Scene(root));
		stage2.show();
    }

    @FXML
    void compra1Action(ActionEvent event) {
    	quant1++;
    	qnt1.setText(Integer.toString(quant1));
    }

    @FXML
    void compra2Action(ActionEvent event) {
    	quant2++;
    	qnt2.setText(Integer.toString(quant2));
    }

    @FXML
    void compra3Action(ActionEvent event) {
    	quant3++;
    	qnt3.setText(Integer.toString(quant3));
    }

    @FXML
    void compra4Action(ActionEvent event) {
    	quant4++;
    	qnt4.setText(Integer.toString(quant4));
    }

    @FXML
    void compra5Action(ActionEvent event) {
    	quant5++;
    	qnt5.setText(Integer.toString(quant5));
    }

    @FXML
    void compra6Action(ActionEvent event) {
    	quant6++;
    	qnt6.setText(Integer.toString(quant6));
    }
    
    @FXML
    void totAction(ActionEvent event) {
    	 Flores f1 = new Flores(quant1,1984.814);
    	 Flores f2 = new Flores(quant2,1519.8833);
    	 Flores f3 = new Flores(quant3,997.3249);
    	 Flores f4 = new Flores(quant4,1000);
    	 Flores f5 = new Flores(quant5,692.7934);
    	 Flores f6 = new Flores(quant6,6960.072);
    	 total=((f1.getQuantaty()*f1.getValorUten())+(f2.getQuantaty()*f2.getValorUten())+(f3.getQuantaty()*f3.getValorUten())+(f4.getQuantaty()*f4.getValorUten())+(f5.getQuantaty()*f5.getValorUten())+(f6.getQuantaty()*f6.getValorUten()));
    	 totfield.setText(Double.toString(total));
    	 paypalPagamentoController pag = new paypalPagamentoController();
    	 CartaoController card = new CartaoController();
			card.voi(total);
		 pag.voi(total);
    }
    
    @FXML
    void OnAdCarrinho1Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	 
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
    	
    
    }

    @FXML
    void OnAdCarrinho2Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
	    	
    	
    }

    @FXML
    void OnAdCarrinho3Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }

    @FXML
    void OnAdCarrinho4Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }

    @FXML
    void OnAdCarrinho5Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }

    @FXML
    void OnAdCarrinho6Action(ActionEvent event) {
    	try {
    		cont++;
    	if(cont<=3) {
    	 MenuController.setCarrinhoValue(Integer.toString(cont));
    	 cartbtn.setText(Integer.toString(cont));
    	
    	}else {
    		Alert alert = new Alert(AlertType.INFORMATION);
    		alert.setContentText("So e possivel adicionar 3 items ao carrinho");
    		alert.setTitle("Atencao");
    		alert.show();
    		
    	}
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }
    
    @FXML
    void OnCartAction(ActionEvent event) throws IOException {
    	
    	 Flores b1 = new Flores(quant1,1984.814);
    	 Flores b2 = new Flores(quant2,1519.8833);
    	 Flores b3 = new Flores(quant3,997.3249);
    	 Flores b4 = new Flores(quant4,1000);
    	 Flores b5 = new Flores(quant5,692.7934);
    	 Flores b6 = new Flores(quant6,6960.072);
    	
    	if(quant1>=1 && quant2==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0) {
    		String txt1 = lab1.getText();
	    	Image i = image1.getImage();
	    	String quantidadeTotal = qnt1.getText();
	    	double totAl = (b1.getValorUten()*b1.getQuantaty());
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.quantaty1(quantidadeTotal);
	    	carrinho.TotalApagar(valor);
	    	
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant2>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant6==0){
    		
    		String txt1 = lab2.getText();
	    	Image i = image2.getImage();
	    	String quantidadeTotal = qnt2.getText();
	    	double totAl = (b2.getValorUten()*b2.getQuantaty());
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.quantaty1(quantidadeTotal);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
    		
    	}else if(quant3>=1 && quant1==0 && quant2==0 && quant4==0 && quant5==0 && quant6==0){
    		
    		String txt1 = lab3.getText();
	    	Image i = image3.getImage();
	    	String quantidadeTotal = qnt3.getText();
	    	
	    	double totAl = (b3.getValorUten()*b3.getQuantaty());
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.quantaty1(quantidadeTotal);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant4>=1 && quant1==0 && quant2==0 && quant3==0 && quant5==0 && quant6==0){
    		
    		String txt1 = lab4.getText();
	    	Image i = image4.getImage();
	    	String quantidadeTotal = qnt4.getText();
	    	double totAl = (b4.getValorUten()*b4.getQuantaty());
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.quantaty1(quantidadeTotal);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant5>=1 && quant1==0 && quant3==0 && quant4==0 && quant2==0 && quant6==0){
    		
    		String txt1 = lab5.getText();
	    	Image i = image5.getImage();
	    	String quantidadeTotal = qnt5.getText();
	    	
	    	double totAl = (b5.getValorUten()*b5.getQuantaty());
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.quantaty1(quantidadeTotal);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant6>=1 && quant1==0 && quant3==0 && quant4==0 && quant5==0 && quant2==0){
    		
    		String txt1 = lab6.getText();
	    	Image i = image6.getImage();
	    	String quantidadeTotal = qnt6.getText();
	    	
	    	double totAl = (b6.getValorUten()*b6.getQuantaty());
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.quantaty1(quantidadeTotal);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
    	}
    	
    	
    	
    	if(quant1>=1 && quant2>=1) {
    		String txt1 = lab1.getText();
	    	Image i = image1.getImage();
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	
	    	
	    	String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.imagemteste2(i2, txt2);
	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal2);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant3>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i = image1.getImage();
	    	
	    	String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.imagemteste2(i3, txt3);
	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal3);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
    		
    	}else if(quant1>=1 && quant4>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i = image1.getImage();
	    	
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.imagemteste2(i4, txt4);
	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal4);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant5>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i = image1.getImage();
	    	
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.imagemteste2(i5, txt5);
	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal5);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant6>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i = image1.getImage();
	    	
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i, txt1);
	    	carrinho.imagemteste2(i6, txt6);
	    	carrinho.quantaty2(quantidadeTotal,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant2>=1 && quant3>=1){
    		
    		String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	 
	    	String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	
	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i2, txt2);
	    	carrinho.imagemteste2(i3, txt3);
	    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal3);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant2>=1 && quant4>=1){
    		
    		String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	 
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	
	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i2, txt2);
	    	carrinho.imagemteste2(i4, txt4);
	    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal4);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant2>=1 && quant5>=1){
    		
    		String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	 
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	 
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	
	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i2, txt2);
	    	carrinho.imagemteste2(i5, txt5);
	    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal5);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant2>=1 && quant6>=1){
    		
    		String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	 
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i2, txt2);
	    	carrinho.imagemteste2(i6, txt6);
	    	carrinho.quantaty2(quantidadeTotal2,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant3>=1 && quant4>=1){
    		
    		String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	 
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	
	    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i3, txt3);
	    	carrinho.imagemteste2(i4, txt4);
	    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal4);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant3>=1 && quant5>=1){
    		
    		String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	 
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	
	    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i3, txt3);
	    	carrinho.imagemteste2(i5, txt5);
	    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal5);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant3>=1 && quant6>=1){
    		
    		String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	 
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i3, txt3);
	    	carrinho.imagemteste2(i6, txt6);
	    	carrinho.quantaty2(quantidadeTotal3,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant4>=1 && quant5>=1){
    		
    		String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	 
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	
	    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i4, txt4);
	    	carrinho.imagemteste2(i5, txt5);
	    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal5);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant4>=1 && quant6>=1){
    		
    		String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	 
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i4, txt4);
	    	carrinho.imagemteste2(i6, txt6);
	    	carrinho.quantaty2(quantidadeTotal4,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant5>=1 && quant6>=1){
    		
    		String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	 
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b5.getValorUten()*b5.getQuantaty())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i5, txt5);
	    	carrinho.imagemteste2(i6, txt6);
	    	carrinho.quantaty2(quantidadeTotal5,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	 
    	if(quant1>=1 && quant2>=1 && quant3>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	
	    	String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b3.getQuantaty()*b3.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i2, txt2);
	    	carrinho.imagemteste3(i3, txt3);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal3);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant4>=1 && quant5>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i4, txt4);
	    	carrinho.imagemteste3(i5, txt5);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal5);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant6>=1 && quant2>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i2, txt2);
	    	carrinho.imagemteste3(i6, txt6);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant6>=1 && quant3>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i3, txt3);
	    	carrinho.imagemteste3(i6, txt6);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant6>=1 && quant4>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i4, txt4);
	    	carrinho.imagemteste3(i6, txt6);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal4,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant6>=1 && quant5>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i5, txt5);
	    	carrinho.imagemteste3(i6, txt6);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal5,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant1>=1 && quant2>=1 && quant4>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	 
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i2, txt2);
	    	carrinho.imagemteste3(i4, txt4);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal4);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant2>=1 && quant5>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b2.getQuantaty()*b2.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i2, txt2);
	    	carrinho.imagemteste3(i5, txt5);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal2,quantidadeTotal5);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant1>=1 && quant3>=1 && quant4>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i3, txt3);
	    	carrinho.imagemteste3(i4, txt4);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal4);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant1>=1 && quant3>=1 && quant5>=1){
    		
    		String txt1 = lab1.getText();
	    	Image i1 = image1.getImage();
	    	 
	    	String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String quantidadeTotal = qnt1.getText();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	
	    	double totAl = ((b1.getValorUten()*b1.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i1, txt1);
	    	carrinho.imagemteste2(i3, txt3);
	    	carrinho.imagemteste3(i5, txt5);
	    	carrinho.quantaty3(quantidadeTotal,quantidadeTotal3,quantidadeTotal5);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant2>=1 && quant3>=1 && quant4>=1){
    		
    		String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	 
	    	String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	 
	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b3.getQuantaty()*b3.getValorUten())+(b4.getQuantaty()*b4.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i2, txt2);
	    	carrinho.imagemteste2(i3, txt3);
	    	carrinho.imagemteste3(i4, txt4);
	    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal3,quantidadeTotal4);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}else if(quant2>=1 && quant5>=1 && quant6>=1){
    		
    		String txt2 = lab2.getText();
	    	Image i2 = image2.getImage();
	    	 
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal2 = qnt2.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b2.getValorUten()*b2.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i2, txt2);
	    	carrinho.imagemteste2(i5, txt5);
	    	carrinho.imagemteste3(i6, txt6);
	    	carrinho.quantaty3(quantidadeTotal2,quantidadeTotal5,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant3>=1 && quant4>=1 && quant5>=1){
    		
    		String txt3 = lab3.getText();
	    	Image i3 = image3.getImage();
	    	 
	    	String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String quantidadeTotal3 = qnt3.getText();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	
	    	double totAl = ((b3.getValorUten()*b3.getQuantaty())+(b4.getQuantaty()*b4.getValorUten())+(b5.getQuantaty()*b5.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i3, txt3);
	    	carrinho.imagemteste2(i4, txt4);
	    	carrinho.imagemteste3(i5, txt5);
	    	carrinho.quantaty3(quantidadeTotal3,quantidadeTotal4,quantidadeTotal5);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    	if(quant4>=1 && quant5>=1 && quant6>=1){
    		
    		String txt4 = lab4.getText();
	    	Image i4 = image4.getImage();
	    	 
	    	String txt5 = lab5.getText();
	    	Image i5 = image5.getImage();
	    	
	    	String txt6 = lab6.getText();
	    	Image i6 = image6.getImage();
	    	
	    	String quantidadeTotal4 = qnt4.getText();
	    	
	    	String quantidadeTotal5 = qnt5.getText();
	    	
	    	String quantidadeTotal6 = qnt6.getText();
	    	
	    	
	    	double totAl = ((b4.getValorUten()*b4.getQuantaty())+(b5.getQuantaty()*b5.getValorUten())+(b6.getQuantaty()*b6.getValorUten()));
	    	Double.toString(totAl);
			String valor = String.format("%.2f",totAl);
	    	 
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("Carrinho.fxml"));
	    	root = loader.load();
	    	
	    	CarrinhoController carrinho = loader.getController();
	    	carrinho.imagemteste(i4, txt4);
	    	carrinho.imagemteste2(i5, txt5);
	    	carrinho.imagemteste3(i6, txt6);
	    	carrinho.quantaty3(quantidadeTotal4,quantidadeTotal5,quantidadeTotal6);
	    	carrinho.TotalApagar(valor);
	    	
	    	Stage stage2 = new Stage();
	    	Scene scene = new Scene(root);
	    	stage2.setScene(scene);
	    	stage2.show();
	    	
    	}
    	
    }

}
