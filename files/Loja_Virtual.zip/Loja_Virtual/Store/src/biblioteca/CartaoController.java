package biblioteca;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

import classes.Cartao;
import classes.Paypal;
import javafx.event.ActionEvent;

public class CartaoController {
	
	private Parent root;
	
private static double r;
	
	static {
		r=0;
	}

	// Event Listener on Button.onAction
	@FXML
	public void OnContinuarAction(ActionEvent event) throws IOException {
Cartao car = new Cartao(500000);
		
		BrinquedosController bq = new BrinquedosController();
		ElectrodomesticosController elect = new ElectrodomesticosController();
		FloresController fl = new FloresController();
		UtensiliosController ut = new UtensiliosController();
		VestuarioController vest = new VestuarioController();
		
		if((car.getSaldo()-r>0)) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("pagamentoSucesso.fxml"));
			root = loader.load();
			
			Stage stage3 = new Stage();
			stage3.setScene(new Scene(root));
			stage3.show();
		}else {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("saldoInsuficiente.fxml"));
			root = loader.load();
			
			Stage stage = new Stage();
			stage.setScene(new Scene(root));
			stage.show();
		}
}
	
	public  double voi(double tot) {
		r = tot;
		return tot;

	}
}
