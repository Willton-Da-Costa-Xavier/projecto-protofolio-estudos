package classes;

public class Paypal {

private double saldo;
	
	public Paypal(double saldo) {
		this.saldo = saldo;
	}
	
	public Paypal() {
		saldo =0;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	
}
