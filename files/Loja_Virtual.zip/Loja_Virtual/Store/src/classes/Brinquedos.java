package classes;

public class Brinquedos {

	private int quantaty;
	private double valorUten;
	
	public Brinquedos(int quantaty, double valorUten) {
		this.quantaty = quantaty;
		this.valorUten = valorUten;
	}

	public int getQuantaty() {
		return quantaty;
	}

	public void setQuantaty(int quantaty) {
		this.quantaty = quantaty;
	}

	public double getValorUten() {
		return valorUten;
	}

	public void setValorUten(double valorUten) {
		this.valorUten = valorUten;
	}
	
}
