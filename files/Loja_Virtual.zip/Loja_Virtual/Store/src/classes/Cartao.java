package classes;

public class Cartao {

	private float saldo;
	
	public Cartao(float saldo) {
		this.saldo = saldo;
	}
	
	public Cartao() {
		saldo =0;
	}

	public float getSaldo() {
		return saldo;
	}

	public void setSaldo(float saldo) {
		this.saldo = saldo;
	}
	
	
	
}
