package classes;



public class Electrodomesticos {
	public int quantaty;
	public double valorUten;
	
	public Electrodomesticos(int quantaty, double valorUten) {
		this.quantaty=quantaty;
		this.valorUten=valorUten;
	}

	public int getQuantaty() {
		return quantaty;
	}

	public void setQuantaty(int quantaty) {
		this.quantaty = quantaty;
	}

	public double getValorUten() {
		return valorUten;
	}

	public void setValorUten(double valor) {
		this.valorUten = valor;
	}
	
}
