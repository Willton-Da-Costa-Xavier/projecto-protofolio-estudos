package classes;

import javafx.scene.image.Image;

public class Cart {
	 	
	private String desc1;
	private String desc2;
	private String desc3;
	private String desc4;
	private String desc5;
	private String desc6;
	private String image1;
	
	public Cart() {
	
		
	}
	
	public Cart(String t1,String t2,String t3,String t4,String t5,String t6,String im) {
		
		this.desc1=t1;
		this.desc2=t2;
		this.desc3=t3;
		this.desc4=t4;
		this.desc5=t5;
		this.desc6=t6;
		this.image1=im;
		
	}
	
	public Cart(String t1,String image) {
		this.desc1=t1;
		this.image1=image;
	}

	public String getDesc1() {
		return desc1;
	}

	public void setDesc1(String desc1) {
		this.desc1 = desc1;
	}

	public String getDesc2() {
		return desc2;
	}

	public void setDesc2(String desc2) {
		this.desc2 = desc2;
	}

	public String getDesc3() {
		return desc3;
	}

	public void setDesc3(String desc3) {
		this.desc3 = desc3;
	}

	public String getDesc4() {
		return desc4;
	}

	public void setDesc4(String desc4) {
		this.desc4 = desc4;
	}

	public String getDesc5() {
		return desc5;
	}

	public void setDesc5(String desc5) {
		this.desc5 = desc5;
	}

	public String getDesc6() {
		return desc6;
	}

	public void setDesc6(String desc6) {
		this.desc6 = desc6;
	}

	public String getImage1() {
		return image1;
	}

	public void setImage1(String image1) {
		this.image1 = image1;
	}

	
	
	
}
