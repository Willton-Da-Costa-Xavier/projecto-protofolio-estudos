package teste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;





public class sql {

	public static Connection connectToDatabase() {
	    Connection conn = null;
	    String url = "jdbc:mysql://localhost:3306/school";
	    String username = "root";
	    String password = " ";

	    try {
	        conn = DriverManager.getConnection(url, username, password);
	        System.out.println("Connected to the database!");
	    } catch (SQLException e) {
	        System.err.println("Error connecting to the database: " + e.getMessage());
	    }

	    return conn;
	}

	public static void executeQuery(Connection conn) {
	    try {
	        String sql = "SELECT * FROM your_table";
	        PreparedStatement statement = conn.prepareStatement(sql);
	        ResultSet result = statement.executeQuery();

	        while (result.next()) {
	            // Process each row of the result
	            int id = result.getInt("id");
	            String name = result.getString("name");
	            // Print or process the retrieved data
	            System.out.println("ID: " + id + ", Name: " + name);
	        }

	        result.close();
	        statement.close();
	    } catch (SQLException e) {
	        System.err.println("Error executing query: " + e.getMessage());
	    }
	}
	
	public static void closeConnection(Connection conn) {
	    try {
	        if (conn != null) {
	            conn.close();
	            System.out.println("Connection closed.");
	        }
	    } catch (SQLException e) {
	        System.err.println("Error closing connection: " + e.getMessage());
	    }
	}
	
	public static void main(String[] args) {
	    Connection conn = connectToDatabase();
//	    executeQuery(conn);
	    closeConnection(conn);
	}
	
	/* public class MySQLConnection {
    public static void main(String[] args) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/your_database";
        String username = "your_username";
        String password = "your_password";

        try {
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);
            System.out.println("Connected to the database!");

            // Perform database operations here...

            connection.close();  // Close the connection when done
        } catch (SQLException e) {
            System.err.println("Connection failed: " + e.getMessage());
        }
    }
}
 */
	
}
