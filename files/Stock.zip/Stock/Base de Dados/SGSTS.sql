CREATE DATABASE IF NOT EXISTS SGSTS;
USE SGSTS;

-- Tabela para produtos
CREATE TABLE Produtos (
    ProdutoID VARCHAR(7) PRIMARY KEY,
    Marca VARCHAR(100) NOT NULL,
    Tipo VARCHAR(100) NOT NULL,
    Peso VARCHAR (50) NOT NULL,
    Prazo VARCHAR(30) NOT NULL,
    -- Mudar peso para varchar
     -- Peso DECIMAL(10, 2) NOT NULL,
    Quantidade INT NOT NULL
);

-- Tabela para administradores
CREATE TABLE Administradores (
    AdministradorID INT PRIMARY KEY auto_increment,
    NomeUtilizador VARCHAR(50) NOT NULL,
    Password VARCHAR(500) NOT NULL,
    email VARCHAR(50) UNIQUE NOT NULL
);

-- Tabela para funcionários
CREATE TABLE Funcionarios (
    FuncionarioID INT PRIMARY KEY auto_increment,
    Nome VARCHAR(255) NOT NULL,
    Gabinete VARCHAR(50) NOT NULL,
    PasswordFunc VARCHAR(500) NOT NULL,
	emailfunc VARCHAR(50) UNIQUE NOT NULL,
    Funcao VARCHAR(100)
);

-- Tabela para registro de saída de estoque
CREATE TABLE SaidaStock (
    SaidaID INT PRIMARY KEY auto_increment,
    ProdutoID VARCHAR(7),
    QuantidadeSaida INT NOT NULL,
    DataSaida DATETIME NOT NULL,
    FuncionarioID INT,
    FOREIGN KEY (ProdutoID) REFERENCES Produtos(ProdutoID) ON DELETE NO ACTION,
    FOREIGN KEY (FuncionarioID) REFERENCES Funcionarios(FuncionarioID)
);

-- Tabela para criacao de fornecedores
CREATE TABLE Fornecedores (
    FornecedorID INT PRIMARY KEY auto_increment,
    Nome VARCHAR(255) NOT NULL,
    ProdutoID VARCHAR(7),
    FOREIGN KEY (ProdutoID) REFERENCES Produtos(ProdutoID) ON DELETE NO ACTION
);

-- Tabela para registro de entrada de estoque
CREATE TABLE EntradaStock (
    EntradaID INT PRIMARY KEY auto_increment,
    ProdutoID VARCHAR(7),
    QuantidadeEntrada INT NOT NULL,
    DataEntrada DATETIME NOT NULL,
    FornecedorID INT,
	FOREIGN KEY (ProdutoID) REFERENCES Produtos(ProdutoID) ON DELETE NO ACTION,
    FOREIGN KEY (FornecedorID) REFERENCES Fornecedores(FornecedorID)
);

CREATE TABLE Pedidos (
	 PedidoID INT PRIMARY KEY auto_increment,
	 ProdutoID VARCHAR(7),
     FuncionarioID INT,
     QuantidadePedida INT NOT NULL,
     FOREIGN KEY (ProdutoID) REFERENCES Produtos(ProdutoID),
     FOREIGN KEY (FuncionarioID) REFERENCES Funcionarios(FuncionarioID)
);