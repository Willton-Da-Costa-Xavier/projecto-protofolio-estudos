package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import module.SaidaStock;

public class Verificar_Stock_RetirarController {
	
	private Parent root;
	private Stage stage;
	private Scene scene;

    @FXML
    private TextField funcao;

    @FXML
    private TextField funcionario;

    @FXML
    private TextField gabinete;

    @FXML
    private TextField marca;

    @FXML
    private TextField peso;

    @FXML
    private TextField prod;

    @FXML
    private TextField quantidade;
    
    
    @FXML
    void OnButtonPressed(KeyEvent event) {
    	
    	String url = "jdbc:mysql://localhost:3306/sgsts";
        String usuario = "root";
        String senha = "1234567";
        
        try {

	    	if(event.getCode().getName().equals("Enter")) {
	    		
	    		String keyquant = quantidade.getText();
//	    		String gabfield = gabinete.getText();
//	    		String funcfield = funcionario.getText();
//	    		String funcaofield = funcao.getText();
	    		int quantfield = Integer.parseInt(keyquant);
	    		
	    		Connection conn = DriverManager.getConnection(url, usuario, senha);
	
	    		String selectcomplete = "SELECT FuncionarioID FROM pedidos WHERE QuantidadePedida = ?";
	    		
	    		PreparedStatement stmnt = conn.prepareStatement(selectcomplete);
	    		stmnt.setInt(1, quantfield);
	    		
	    		ResultSet resultfunid = stmnt.executeQuery();
	    		
	    		if(resultfunid.next()) {
	    			
	    			int funcid = resultfunid.getInt("FuncionarioID"); 
	    			
	    			String selectdadosfuncionario = "SELECT Nome, Gabinete, Funcao FROM funcionarios WHERE FuncionarioID = ?";
	    			PreparedStatement stmnt2 = conn.prepareStatement(selectdadosfuncionario);
	    			stmnt2.setInt(1, funcid);
	    			
	    			ResultSet resultdados = stmnt2.executeQuery();
	    			
	    			if(resultdados.next()) {
	    				
	    				String n = resultdados.getString("Nome");
	    				String g = resultdados.getString("Gabinete");
	    				String f = resultdados.getString("Funcao"); 
	    				
	    				funcionario.setText(n);
	    				gabinete.setText(g);
	    				funcao.setText(f);
	    			}
	    		}
	    		
	    		stmnt.close();
	    		conn.close();
	    	}
    	
    	
      }catch (Exception e) {
    	  System.out.println(e.getMessage());
      }
    }

    @FXML
    void OnRetirarAction(ActionEvent event) {

    	String url = "jdbc:mysql://localhost:3306/sgsts";
        String usuario = "root";
        String senha = "1234567";
        
        try {
        	
        	String brand = marca.getText();
        	String product = prod.getText();
        	String p = peso.getText();
        	String q = quantidade.getText();
        	int quantity = Integer.parseInt(q); 
        	
        	
        	
        	Connection conn = DriverManager.getConnection(url, usuario, senha);
        	
        	String selectprod = "SELECT ProdutoID FROM produtos WHERE Marca = ? AND Tipo = ? AND Peso = ?";
        	
        	PreparedStatement prepselectprod = conn.prepareStatement(selectprod);
        	
        	prepselectprod.setString(1, brand);
        	prepselectprod.setString(2, product);
        	prepselectprod.setString(3, p);
        
        	
        	ResultSet resultado = prepselectprod.executeQuery();
        	
        	if (resultado.next()) {
        		
        		String prodid = resultado.getString("ProdutoID");
        		
        		String selectfunid = "SELECT FuncionarioID From pedidos WHERE ProdutoID = ?";
        		
        		PreparedStatement st = conn.prepareStatement(selectfunid);
        		
        		st.setString(1, prodid);
        		
        		ResultSet rt = st.executeQuery();
        		
        		if(rt.next()) {
        			
        			int funid = rt.getInt("FuncionarioID");
        			
        			String insertsaida = "INSERT INTO saidastock (ProdutoID, QuantidadeSaida, DataSaida, FuncionarioID) VALUES (?, ?, ?, ?)";
	    			PreparedStatement prepinsertsaida = conn.prepareStatement(insertsaida);
	    			
	    			LocalDateTime agora = LocalDateTime.now();
	                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	                String datasaida = agora.format(formatter);
	    			
	    			prepinsertsaida.setString(1, prodid);
	    			prepinsertsaida.setInt(2, quantity);
	    			prepinsertsaida.setString(3, datasaida);
	    			prepinsertsaida.setInt(4, funid);
	    			prepinsertsaida.executeUpdate();
	    			
	    			
	    			String delete = "DELETE FROM pedidos WHERE ProdutoID = ? AND FuncionarioID = ?";
	    			
	    			PreparedStatement prepdelete = conn.prepareStatement(delete);
	    			
	    			prepdelete.setString(1, prodid);
	    			prepdelete.setInt(2, funid);
	    			prepdelete.executeUpdate();
	    			
	    			
	    			Alert alert = new Alert(AlertType.INFORMATION);
//		        	 alert.setTitle("Erro");
		 			alert.setContentText("Dados Retirados com sucesso");
		 			alert.show();
        		}
	    			
	    			
	    			
//	    			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu_Verificar_Stock.fxml"));
//					root = loader.load();
//					
//					stage = (Stage)((Node)event.getSource()).getScene().getWindow();
//					scene = new Scene(root);
//					stage.setScene(scene);
//					stage.setTitle("Stock");
//					stage.show();
	    		}
	    		
//        		}else if(quantidadeprod == 0) {
//        			
//        			
//        			Statement statement = conn.createStatement();
//        			
//        			 statement.executeUpdate("SET foreign_key_checks = 0");
//        			
//        			String del = "DELETE FROM produtos WHERE ProdutoID = ?";
//        			
//        			 statement.executeUpdate("SET foreign_key_checks = 1");
//        			
//        			PreparedStatement prepdelete = conn.prepareStatement(del);
//        			
//        			prepdelete.setString(1, prodid);
//        			
//        			 int rowsAffected = prepdelete.executeUpdate();
//        			 
//        			 if(rowsAffected > 0) {
//        				  System.out.println("Dados excluídos com sucesso!");
//        	            } else {
//        	                System.out.println("Nenhum dado foi excluído.");
//        			
//        	            }
        		
        		
        		
        	
        
        	
//        	SaidaStock saidastock = new SaidaStock();
        
        }catch (Exception e) {
        	e.printStackTrace();
        }
    }
    
    @FXML
    void OnBackAction(ActionEvent event) {

    	
    	try {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Administrador_Verificar_Pedidos.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Pedidos");
			stage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
    	
    	
    }
    
    


}
