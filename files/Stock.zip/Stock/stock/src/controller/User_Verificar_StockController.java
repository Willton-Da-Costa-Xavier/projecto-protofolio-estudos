package controller;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import module.CombineData;
import module.Produtos;

public class User_Verificar_StockController implements Initializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;

	
	@FXML
    private TableColumn<Produtos, Boolean> marcacao;
	
	@FXML
    private TableView<Produtos> stock;
    
    @FXML
    private TableColumn<Produtos, String> marca;
    
    @FXML
    private TableColumn<Produtos, String> peso;

    @FXML
    private TableColumn<Produtos, String> produto;

    @FXML
    private TableColumn<Produtos, Integer> quantidade;
    
    @FXML
    private TableColumn<Produtos, String> validade;
    
    private ObservableList<Produtos> dadosConsulta;
    
    public static String u;
    public static int q;
    
    static {
    	u = "";
    	q = 0;
    }
    
    
    @FXML
    void OnBackAction(ActionEvent event) {

    	try {
    		
    		
//    		 Alert alert = new Alert(AlertType.CONFIRMATION);
//        	 alert.setTitle("Comfirmacao");
// 			alert.setHeaderText("Tem a Certeza que quer Sair?");
// 			alert.setContentText("Escolhe sua opcao");
// 			alert.show();
// 			
// 			ButtonType btnsim = new ButtonType("Sim");
// 			ButtonType btnnao = new ButtonType("Nao");
// 			
// 			alert.getButtonTypes().setAll(btnsim, btnnao);
// 			
// 			Optional<ButtonType> result = alert.showAndWait();
 			
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Login.fxml"));
				root = loader.load();
				
				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				scene = new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Login");
				stage.show();
 			
// 			result.ifPresent(buttonType -> {
// 				
// 				if(buttonType == btnsim) {
// 					
// 					try {
// 						
// 						
// 						FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Login.fxml"));
// 	 	 				root = loader.load();
// 	 	 				
// 	 	 				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
// 	 	 				scene = new Scene(root);
// 	 	 				stage.setScene(scene);
// 	 	 				stage.setTitle("Login");
// 	 	 				stage.show();
// 						
// 					}catch (Exception e) {
// 						
// 						System.out.println(e.getMessage());
// 					}
// 	 				
// 	 				
// 	 				
// 	 			}else {
// 	 				
// 	 			}
// 			});
 			
 			
 			
// 			if(alert. == 0) {
// 				
// 			}
    		
    		
    		
    	}catch (Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
    }
    
    
    @FXML
    void OnQuantEdit(TableColumn.CellEditEvent<CombineData,Integer> quantidadecellEdit) {

    	Produtos qnty = stock.getSelectionModel().getSelectedItem();
    	qnty.setQuantidade(quantidadecellEdit.getNewValue());
//    	q = quantidadecellEdit.getNewValue();
//    	stock.refresh();
    	
    }
	
	  @FXML
	    void OnFazerPedidoAction(ActionEvent event) {

		  ObservableList<Produtos> dadosConsulta = stock.getItems();
		  List<Produtos> selectedItems = dadosConsulta.stream().filter(Produtos::isMarcado).collect(Collectors.toList());
			 
			 String url = "jdbc:mysql://localhost:3306/sgsts";
	          String usuario = "root";
	          String senha = "1234567";
	          
	          try {
	        	  
	        	  
	        	  Connection conn = DriverManager.getConnection(url, usuario, senha);
	        	  
	        	  for(Produtos produtos: selectedItems) {
	        		  
	        		  String verificarfuncionario = "SELECT FuncionarioID FROM funcionarios WHERE Nome = ?";
	        		  
	        		  PreparedStatement prepverificafunc = conn.prepareStatement(verificarfuncionario);
	        		  prepverificafunc.setString(1, u);
	        		  
	        		  ResultSet resultfunc = prepverificafunc.executeQuery();
	        		  
	        		  if (resultfunc.next()) {
	        			  
	        			  int funid = resultfunc.getInt("FuncionarioID");
	        			  
	        			  String verificarproduto = "SELECT ProdutoID, Quantidade FROM produtos WHERE Marca = ?";
	        			  
	        			  PreparedStatement preproduto = conn.prepareStatement(verificarproduto);
	        			  
	        			  preproduto.setString(1, produtos.getMarca());
//	        			  preproduto.executeUpdate();
	        			  
	        			  ResultSet resultproduto = preproduto.executeQuery();
	        			  
	        			  if(resultproduto.next()) {
	        				  
	        				  String prodid = resultproduto.getString("ProdutoID");
	        				  q = resultproduto.getInt("Quantidade");
	        				  int qt = produtos.getQuantidade();
	        				  
//	        				  if(qt >= q) {
//	        					  System.out.println(q);
//	        					  System.out.println(qt);
//	        					  Alert alert = new Alert(AlertType.WARNING);
////	        			        	 alert.setTitle("Erro");
//	        			 			alert.setContentText("A Quantidade Requisitada nao pode ser igual ou superior a quantidade original");
//	        			 			alert.show();
//		        				  }else {
		        					  
		        					  String inserirpedodo = "INSERT INTO pedidos (ProdutoID, FuncionarioID, QuantidadePedida) VALUES (?, ?, ?)"; 
				        			  
				        			  PreparedStatement prepinsertpedido = conn.prepareStatement(inserirpedodo);
				        			  
				        			  prepinsertpedido.setString(1, prodid);
				        			  prepinsertpedido.setInt(2, funid);
				        			  prepinsertpedido.setInt(3, qt);
				        			  prepinsertpedido.executeUpdate();
				        			  
				        			  String updatequant = "UPDATE produtos set Quantidade = ? WHERE ProdutoID = ?";
				        			  PreparedStatement prepupdatequant = conn.prepareStatement(updatequant);
				        			  
				        			  prepupdatequant.setInt(1, (q-qt));
				        			  prepupdatequant.setString(2, prodid);
				        			  
				        			 prepupdatequant.executeUpdate();
				        			 
				        			 String quantatual = "SELECT Quantidade FROM produtos WHERE Tipo = ?";
				        			 
				        			 PreparedStatement prepqntatual = conn.prepareStatement(quantatual);
				        			 
				        			 prepqntatual.setString(1, produtos.getTipo());
				        			 
				        			 ResultSet resultadoqnt = prepqntatual.executeQuery();
				        			 
				        			 if(resultadoqnt.next()) {
				        				 q = resultadoqnt.getInt("Quantidade");
				        				 produtos.setQuantidade(q);
				        				 produtos.setMarcado(false);
					        			 stock.refresh();
				        			 }
				        			 
				        			 
		        					  
				        			  Alert alert = new Alert(AlertType.INFORMATION);
//				 		        	 alert.setTitle("Erro");
				 		 			alert.setContentText("Pedidos Feitos");
				 		 			alert.show();
				        			  
//		        				  }  
	        				  
	        			  }
	        			  
	        			  
	        		  }
	        		  
	        		 
	        	  }
	        	  
	        	  
	        	  
	          }catch(Exception e) {
	        	  System.out.println(e.getMessage());
	          }
		  
	    }
	  
	  @Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			
		  System.out.println(u);
			
			dadosConsulta = obterDadosDaConsulta(); // Use a função para obter dados observáveis
			
			deleteProductsByQuantity(0);
			
			marcacao.setCellValueFactory(new PropertyValueFactory<Produtos,Boolean>("marcado"));
			marcacao.setCellValueFactory(cellData -> {
	            Produtos item = cellData.getValue();
	            SimpleBooleanProperty property = new SimpleBooleanProperty(item.isMarcado());
	            property.addListener((obs, oldVal, newVal) -> item.setMarcado(newVal));
	            return property;
	        });
			stock.setEditable(true);
			quantidade.setCellFactory(TextFieldTableCell.<Produtos, Integer>forTableColumn(new IntegerStringConverter()));
			marcacao.setCellFactory(CheckBoxTableCell.forTableColumn(marcacao));
			marcacao.setOnEditCommit(event -> {
	            Produtos item = event.getRowValue();
	            item.setMarcado(event.getNewValue());
	        });
			
			marca.setCellValueFactory(new PropertyValueFactory<Produtos,String>("marca"));
			produto.setCellValueFactory(new PropertyValueFactory<Produtos,String>("tipo"));
			peso.setCellValueFactory(new PropertyValueFactory<Produtos,String>("peso"));
			quantidade.setCellValueFactory(new PropertyValueFactory<Produtos,Integer>("quantidade"));
			validade.setCellValueFactory(new PropertyValueFactory<Produtos,String>("prazo"));
			
			
			
			
			stock.setItems(dadosConsulta);
			
			
//			stock.setEditable(true);
//			marca.setCellFactory(TextFieldTableCell.<Produtos>forTableColumn());
//			produto.setCellFactory(TextFieldTableCell.<Produtos>forTableColumn());
//			peso.setCellFactory(TextFieldTableCell.<Produtos, Double>forTableColumn(new DoubleStringConverter()));
//			quantidade.setCellFactory(TextFieldTableCell.<Produtos, Integer>forTableColumn(new IntegerStringConverter()));
			
		
			
			
			
//			// Simulação de atualização automática a cada 5 segundos
//	        new Thread(() -> {
//	            try {
//	                while (true) {
//	                    Thread.sleep(5000); // Espere 5 segundos
//	                    stock.refresh();
//	                }
//	            } catch (InterruptedException e) {
//	                e.printStackTrace();
//	            }
//	        }).start();
			
		}
		
		 private  ObservableList<Produtos> obterDadosDaConsulta() {
			 ObservableList<Produtos> dados = FXCollections.observableArrayList();

		        String url = "jdbc:mysql://localhost:3306/sgsts";
		          String usuario = "root";
		          String senha = "1234567";

		        try {
	Connection conn = DriverManager.getConnection(url, usuario, senha);
		  	        
		  	        System.out.println("Connected to the database!");
		  	        
		  	      String query = "SELECT * FROM produtos";
		    		Statement statement = conn.createStatement();
		    		
		    		ResultSet resultSet = statement.executeQuery(query);

		            while (resultSet.next()) {
		            	
		            	String pid = resultSet.getString("ProdutoID");
		    			String m = resultSet.getString("Marca");
		    			String t = resultSet.getString("Tipo");
		    			String ps = resultSet.getString("Peso");
		    			int qt = resultSet.getInt("Quantidade");
		    			String prazo = resultSet.getString("Prazo");
//		    			System.out.println(pid );
		    			dados.add(new Produtos(false,m,t,ps,qt,prazo));
		            }

		            resultSet.close();
		            statement.close();
		            conn.close();
		            
		        } catch (SQLException e) {
		            e.printStackTrace();
		        }

		        return dados;
		    }
		 
		 private void deleteProductsByQuantity(int quantity) {
				dadosConsulta.removeIf(produtos -> produtos.getQuantidade() == quantity);
		    }
		 
		
		 
		 
		 public String User(String user) {
			 
			 u = user;
			 
			 return u;
		 }
}
