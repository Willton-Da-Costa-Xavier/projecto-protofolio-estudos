package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import module.CombineData;

public class Administrador_Verificar_PedidosController implements Initializable{
	
	
	private Parent root;
	private Stage stage;
	private Scene scene;

    @FXML
    private TableColumn<CombineData, String> gabinete;

    @FXML
    private TableColumn<CombineData, String> marca;

    @FXML
    private TableColumn<CombineData, String> nome;

    @FXML
    private TableView<CombineData> pedidos;

    @FXML
    private TableColumn<CombineData, String> peso;

    @FXML
    private TableColumn<CombineData, Integer> quantidade;

    @FXML
    private TableColumn<CombineData, String> tipo;
    
    private ObservableList<CombineData> dadosconsulta;

    @FXML
    void onRetirarPedidosAction(ActionEvent event) {

    	
    	 try {
			 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Verificar_Stock_Retirar.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Actuando Pedido");
			stage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
    	
    }
    
    
    @FXML
    void OnBackAction(ActionEvent event) {

try {
    		
    		
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Stock");
			stage.show();
    		
    	}catch (Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
		dadosconsulta = obterDados();
		
		nome.setCellValueFactory(new PropertyValueFactory<CombineData,String>("nome"));
		gabinete.setCellValueFactory(new PropertyValueFactory<CombineData,String>("gabinete"));
		marca.setCellValueFactory(new PropertyValueFactory<CombineData,String>("marca"));
		tipo.setCellValueFactory(new PropertyValueFactory<CombineData,String>("tipo"));
		peso.setCellValueFactory(new PropertyValueFactory<CombineData,String>("peso"));
		quantidade.setCellValueFactory(new PropertyValueFactory<CombineData,Integer>("quantidade"));
		
		pedidos.setItems(dadosconsulta);
		
		
	}
	
	
	private  ObservableList<CombineData> obterDados() {
		
		 ObservableList<CombineData> dados = FXCollections.observableArrayList();
		 
		 String url = "jdbc:mysql://localhost:3306/sgsts";
        String usuario = "root";
        String senha = "1234567";
        
        try {
       	 
       	 Connection conn = DriverManager.getConnection(url, usuario, senha);
       	 
       	 System.out.println("Connected to the database!");
	  	        
	  	      String query = "SELECT * FROM pedidos";
	    		Statement statement = conn.createStatement();
	    		
	    		ResultSet resultSet = statement.executeQuery(query);

	            while (resultSet.next()) {
	            	
	            	int pedid = resultSet.getInt("PedidoID");
	            	String pid = resultSet.getString("ProdutoID");
	    			int funid = resultSet.getInt("FuncionarioID");
	    			int quantpedida = resultSet.getInt("QuantidadePedida");
//	    			System.out.println(pid );
	    			
	    				
	    				String selectsaida = "SELECT Nome, Gabinete FROM funcionarios WHERE FuncionarioID = ?";
	    				
	    				PreparedStatement prepsaida = conn.prepareStatement(selectsaida);
	    				
	    				prepsaida.setInt(1, funid);
	    				
	    				ResultSet resulsaida = prepsaida.executeQuery();
	    				
	    				if(resulsaida.next()) {
	    			
	    					String nomefunc = resulsaida.getString("Nome");
	    					String gabfunc = resulsaida.getString("Gabinete");
	    					
	    					
	    					  
	    					String selectfuncionarios = "SELECT Marca, Tipo, Peso FROM produtos WHERE ProdutoID = ?";
	    					
	    					PreparedStatement prepfuncionario = conn.prepareStatement(selectfuncionarios);
	    					
	    					prepfuncionario.setString(1, pid);
	    					
	    					ResultSet resulfuncionarios = prepfuncionario.executeQuery();
	    					
	    					if(resulfuncionarios.next()) {
	    						
	    						String marcaprod = resulfuncionarios.getString("Marca");
	    						
	    						String tipoprod = resulfuncionarios.getString("Tipo");
	    						
	    						String pesoprod = resulfuncionarios.getString("Peso");
	    						
	    						
	    						dados.add(new CombineData(nomefunc,gabfunc, marcaprod, tipoprod, pesoprod, quantpedida));
	    					}
	    				
		    			
	    				
//	    			}else {
//	    				dados.add(new CombineData(pid,m,t,ps,qt,"Nao Alocado","Nao Alocado", "Nao Alocado"));
	    			}
	    			
	    			
	            }

	            resultSet.close();
	            statement.close();
	            conn.close();
       	 
        }catch(SQLException e) {
       	 e.printStackTrace();
        }
        
        return dados;
	}

}
