package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.util.converter.IntegerStringConverter;
import javafx.util.converter.DoubleStringConverter;
import module.CombineData;
import module.EntradaStock;
import module.Funcionarios;
import module.Produtos;
import module.SaidaStock;

public class Verificar_Stock_EditarController implements Initializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;

  


    @FXML
    private TableColumn<Produtos, String> marca;


    @FXML
    private TableColumn<Produtos, String> peso;

    @FXML
    private TableColumn<Produtos, String> produto;

    @FXML
    private TableColumn<Produtos, Integer> quantidade;

    @FXML
    private TableView<Produtos> stock;
    
    @FXML
    private TextField filtroTextField;
    
    private ObservableList<Produtos> dadosconsulta;
    
    @FXML
    void OnBackAction(ActionEvent event) {

    	try {
			 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu_Verificar_Stock.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Verificar Stock");
			stage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
    	
    }

   
    @FXML
    void OnMarcaEdit(TableColumn.CellEditEvent<CombineData,String> marcacellEdit) {

    	Produtos mrc = stock.getSelectionModel().getSelectedItem();
    	mrc.setMarca(marcacellEdit.getNewValue());
    	updatemarca(mrc.getProdutoid(), marcacellEdit.getNewValue());
    	stock.refresh();
    	
    }

    @FXML
    void OnPesoEdit(TableColumn.CellEditEvent<CombineData,String> pesocellEdit) {

    	Produtos pso = stock.getSelectionModel().getSelectedItem();
    	pso.setPeso(pesocellEdit.getNewValue());
    	updatepeso(pso.getProdutoid(), pesocellEdit.getNewValue());
    	stock.refresh();
    	
    }

    @FXML
    void OnPesquisarAction(ActionEvent event) {

    	 String filtro = filtroTextField.getText().toLowerCase(); // Obtém o texto do TextField e converte para minúsculas

         ObservableList<Produtos> filteredList = dadosconsulta.filtered(combine ->
                 String.valueOf(combine.getMarca()).toLowerCase().contains(filtro) ||
                 combine.getTipo().toLowerCase().contains(filtro) || combine.getPeso().contains(filtro) || Integer.toString(combine.getQuantidade()).contains(filtro)
         );

         stock.setItems(filteredList);

    	
    }

    @FXML
    void OnProdutoEdit(TableColumn.CellEditEvent<CombineData,String> prodcellEdit) {

    	Produtos prd = stock.getSelectionModel().getSelectedItem();
    	prd.setTipo(prodcellEdit.getNewValue());
    	updateprod(prd.getProdutoid(), prodcellEdit.getNewValue());
    	stock.refresh();
    	
    }

    @FXML
    void OnQuantidadeEdit(TableColumn.CellEditEvent<CombineData,Integer> quantidadecellEdit) {

    	Produtos qnty = stock.getSelectionModel().getSelectedItem();
    	qnty.setQuantidade(quantidadecellEdit.getNewValue());
    	updatequantidade(qnty.getProdutoid(), quantidadecellEdit.getNewValue());
    	stock.refresh();
    	
    }


    

    @FXML
    void OnSalvarAction(ActionEvent event) {
    	
//    	 String url = "jdbc:mysql://localhost:3306/sgsts";
//         String usuario = "root";
//         String senha = "1234567";
//         
//         try {
//        	 
//        	 int rowcount = stock.getItems().size();
//        	 
//        	 for(int i =0;i < rowcount; i++) {
//        	 CombineData item = stock.getItems().get(i);
//        	 CombineData item2 = stock.getItems().get(i);
//        	 CombineData item3 = stock.getItems().get(i);
//        	 CombineData item4 = stock.getItems().get(i);
//        	 CombineData item5 = stock.getItems().get(i);
//        	 CombineData item6 = stock.getItems().get(i);
//        	 CombineData item7 = stock.getItems().get(i);
//        	 CombineData item8 = stock.getItems().get(i);
//        	 int num = item.getProdutoid();
//        	 String branditem = item2.getMarca();
//        	 String productitem = item3.getTipo();
//        	 double weightitem = item4.getPeso();
//        	 int quantatyitem = item5.getQuantidade();
//        	 String officeitem = item6.getGabinete();
//        	 String workeritem = item7.getNome();
//        	 String functionitem = item8.getFuncao();
//        	 
//        	 Connection conn = DriverManager.getConnection(url, usuario, senha);
//        	 
//        	 String Selectitemprod = "SELECT Marca, Tipo, Peso, Quantidade FROM produtos WHERE ProdutoID = ?";
//        	 
//        	 PreparedStatement prepitemprod = conn.prepareStatement(Selectitemprod);
//        	 
//        	 prepitemprod.setInt(1, num);
//        	
//        	 
//        	 ResultSet resultitemprod = prepitemprod.executeQuery();
//        	 
//        	 if (resultitemprod.next()) {
//        		 
//        		 String marcaupdateselect = resultitemprod.getString("Marca");
//        		 String tipoupdate = resultitemprod.getString("Tipo");
//        		 double pesoupdate = resultitemprod.getDouble("Peso");
//        		 int quantupdate = resultitemprod.getInt("Quantidade");
//        		 
//        		 String selectfuncionarioid = "SELECT FuncionarioID FROM funcionarios";
//        		 
//        		 Statement stmt = conn.createStatement();
//        		
//        		 
//        		 ResultSet resultadoidfumcionario = stmt.executeQuery(selectfuncionarioid);
//        		 
//        		 if(resultadoidfumcionario.next()) {
//        			 
//        			 int workerid = resultadoidfumcionario.getInt("FuncionarioID");
//        			 
//        			 String selectfuncionario = "SELECT Nome, Gabinete, Funcao FROM funcionarios WHERE FuncionarioID = ?";
//            		 
//            		 PreparedStatement prepfuncionarioitem = conn.prepareStatement(selectfuncionario);
//            		 
//            		  prepfuncionarioitem.setInt(1,workerid );
//            		  prepfuncionarioitem.executeUpdate();
//            		  
//            		  ResultSet resultadofuncionarioitem = prepfuncionarioitem.executeQuery();
//            		  
//            		  if(resultadofuncionarioitem.next()) {
//            			  
//            			  
//            			  
//            			  
//            			  String updateitme = "UPDATE produtos SET Marca = ?, Tipo = ?, Peso = ?, Quantidade = ? FROM produtos WHERE ProdutoID = ?";
//            			  PreparedStatement prepupdatePreparedStatement = conn.prepareStatement(updateitme);
//            			  
//            			  prepupdatePreparedStatement.setString(1, branditem);
//            			  prepupdatePreparedStatement.setString(2, productitem);
//            			  prepupdatePreparedStatement.setDouble(3, weightitem);
//            			  prepupdatePreparedStatement.setDouble(4, quantatyitem);
//            			  prepupdatePreparedStatement.setDouble(6, num);
//            			  prepupdatePreparedStatement.executeUpdate();
//            			  
//            			  String updatefuncionario = "UPDATE funcionarios SET Nome = ?, Gabinete = ?, Funcao = ? WHERE FuncionarioID = ?";
//            			  PreparedStatement prepupdatefuncionario = conn.prepareStatement(updatefuncionario);
//            			  
//            			  prepupdatefuncionario.setString(1,workeritem);
//            			  prepupdatefuncionario.setString(2,officeitem);
//            			  prepupdatefuncionario.setString(3,functionitem);
//            			  prepupdatefuncionario.setInt(4,workerid);
//            			  prepupdatefuncionario.executeUpdate();
//            			  
//            			  FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Verificar_Stock.fxml"));
//            				root = loader.load();
//            				
//            				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
//            				scene = new Scene(root);
//            				stage.setScene(scene);
//            				stage.setTitle("Verificar Stock");
//            				stage.show();
//            			  
//            			  Alert alert = new Alert(AlertType.INFORMATION);
////     		        	 alert.setTitle("Erro");
//     		 			alert.setContentText("Dados Alterados com sucesso");
//     		 			alert.show();
//            		  }
//        			 
//        		 }
//        		 
//        		
//        	 }
//        	 
//        	 conn.close();
//        	 prepitemprod.close(); 
//        	 resultitemprod.close();
//        	 
////        	 System.out.println(num);
//        	 
//        	 }
//        	 
//        	 
//        	 
//        	 
//         }catch (SQLException | IOException e) {
//        	 
//        	 System.out.println(e.getMessage());
//         }
try {
    	 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu_Verificar_Stock.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Verificar Stock");
			stage.show();
		  
		  Alert alert = new Alert(AlertType.INFORMATION);
//  	 alert.setTitle("Erro");
		alert.setContentText("Dados Alterados com sucesso");
		alert.show();
}catch (Exception e) {
	System.out.println(e.getMessage());
}
    	 
    	
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
		
		dadosconsulta = obterDados();
		
		deleteProductsByQuantity(0);
		
		
		marca.setCellValueFactory(new PropertyValueFactory<Produtos,String>("marca"));
		produto.setCellValueFactory(new PropertyValueFactory<Produtos,String>("tipo"));
		peso.setCellValueFactory(new PropertyValueFactory<Produtos,String>("peso"));
		quantidade.setCellValueFactory(new PropertyValueFactory<Produtos,Integer>("quantidade"));
		
		
		
		
		
		
		
		stock.setItems(dadosconsulta);
		
		
		
		stock.setEditable(true);
		marca.setCellFactory(TextFieldTableCell.<Produtos>forTableColumn());
		produto.setCellFactory(TextFieldTableCell.<Produtos>forTableColumn());
		peso.setCellFactory(TextFieldTableCell.<Produtos>forTableColumn());
		quantidade.setCellFactory(TextFieldTableCell.<Produtos, Integer>forTableColumn(new IntegerStringConverter()));
		
		
	}
	
	

	
	
	     private  ObservableList<Produtos> obterDados() {
		
		 ObservableList<Produtos> dados = FXCollections.observableArrayList();
		 
		 String url = "jdbc:mysql://localhost:3306/sgsts";
         String usuario = "root";
         String senha = "1234567";
         
         try {
        	 
        	 Connection conn = DriverManager.getConnection(url, usuario, senha);
        	 
        	 System.out.println("Connected to the database!");
	  	        
	  	      String query = "SELECT * FROM produtos";
	    		Statement statement = conn.createStatement();
	    		
	    		ResultSet resultSet = statement.executeQuery(query);

	            while (resultSet.next()) {
	            	
	            	String pid = resultSet.getString("ProdutoID");
	    			String m = resultSet.getString("Marca");
	    			String t = resultSet.getString("Tipo");
	    			String ps = resultSet.getString("Peso");
	    			int qt = resultSet.getInt("Quantidade");
//	    			System.out.println(pid );
	    			
	    				
	    				
	    						
	    						dados.add(new Produtos(pid,m, t, ps, qt));
	    			
	    			
	            }

	            resultSet.close();
	            statement.close();
	            conn.close();
        	 
         }catch(SQLException e) {
        	 e.printStackTrace();
         }
         
         return dados;
	}
	     
	     private void updateprod(String prodid, String novoProd) {
	    	    
	    	    
	    	    String url = "jdbc:mysql://localhost:3306/sgsts";
	            String usuario = "root";
	            String senha = "1234567";

	    	    try {
	    	    Connection conn = DriverManager.getConnection(url, usuario, senha);
	    	    
	    	    String sql = "UPDATE produtos SET Tipo = ? WHERE ProdutoID = ?";
	    	         PreparedStatement stmt = conn.prepareStatement(sql);

	    	        stmt.setString(1, novoProd);
	    	        stmt.setString(2, prodid);
	    	        stmt.executeUpdate();
	    	        
	    	        // Se necessário, você pode adicionar confirmações ou logs aqui após a atualização no banco de dados.
	    	        
	    	    } catch (SQLException e) {
	    	        e.printStackTrace();
	    	        // Lida com exceções ou erros no processo de atualização no banco de dados.
	    	    }
	    	}
	     
	     private void updatemarca(String prodid, String novaMarca) {
	    	    
	    	    
	    	    String url = "jdbc:mysql://localhost:3306/sgsts";
	            String usuario = "root";
	            String senha = "1234567";

	    	    try {
	    	    Connection conn = DriverManager.getConnection(url, usuario, senha);
	    	    
	    	    String sql = "UPDATE produtos SET Marca = ? WHERE ProdutoID = ?";
	    	         PreparedStatement stmt = conn.prepareStatement(sql);

	    	        stmt.setString(1, novaMarca);
	    	        stmt.setString(2, prodid);
	    	        stmt.executeUpdate();
	    	        
	    	        // Se necessário, você pode adicionar confirmações ou logs aqui após a atualização no banco de dados.
	    	        
	    	    } catch (SQLException e) {
	    	        e.printStackTrace();
	    	        // Lida com exceções ou erros no processo de atualização no banco de dados.
	    	    }
	    	}
	     
	     private void updatepeso(String prodid, String novoPeso) {
	    	    
	    	    
	    	    String url = "jdbc:mysql://localhost:3306/sgsts";
	            String usuario = "root";
	            String senha = "1234567";

	    	    try {
	    	    Connection conn = DriverManager.getConnection(url, usuario, senha);
	    	    
	    	    String sql = "UPDATE produtos SET Peso = ? WHERE ProdutoID = ?";
	    	         PreparedStatement stmt = conn.prepareStatement(sql);

	    	        stmt.setString(1, novoPeso);
	    	        stmt.setString(2, prodid);
	    	        stmt.executeUpdate();
	    	        
	    	        // Se necessário, você pode adicionar confirmações ou logs aqui após a atualização no banco de dados.
	    	        
	    	    } catch (SQLException e) {
	    	        e.printStackTrace();
	    	        // Lida com exceções ou erros no processo de atualização no banco de dados.
	    	    }
	    	}
	     
	     private void updatequantidade(String prodid, int novaQuantidade) {
	    	    
	    	    
	    	    String url = "jdbc:mysql://localhost:3306/sgsts";
	            String usuario = "root";
	            String senha = "1234567";

	    	    try {
	    	    Connection conn = DriverManager.getConnection(url, usuario, senha);
	    	    
	    	    String sql = "UPDATE saidastock SET QuantidadeSaida = ? WHERE ProdutoID = ?";
	    	         PreparedStatement stmt = conn.prepareStatement(sql);

	    	        stmt.setInt(1, novaQuantidade);
	    	        stmt.setString(2, prodid);
	    	        stmt.executeUpdate();
	    	        
	    	        // Se necessário, você pode adicionar confirmações ou logs aqui após a atualização no banco de dados.
	    	        
	    	    } catch (SQLException e) {
	    	        e.printStackTrace();
	    	        // Lida com exceções ou erros no processo de atualização no banco de dados.
	    	    }
	    	}
	     
	  
	     
	     private void deleteProductsByQuantity(int quantity) {
	    	 dadosconsulta.removeIf(CombineData -> CombineData.getQuantidade() == quantity);
		    }

}
