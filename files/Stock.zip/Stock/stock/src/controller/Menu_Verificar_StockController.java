package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import application.Main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import module.Produtos;
import javafx.util.converter.DoubleStringConverter;
import javafx.util.converter.IntegerStringConverter;

public class Menu_Verificar_StockController implements Initializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;
	
	

    @FXML
    private TableView<Produtos> stock;
    
    @FXML
    private TableColumn<Produtos, String> marca;

    @FXML
    private TableColumn<Produtos, Integer> nr;

    @FXML
    private TableColumn<Produtos, String> peso;

    @FXML
    private TableColumn<Produtos, String> produto;

    @FXML
    private TableColumn<Produtos, Integer> quantidade;
    
    @FXML
    private TableColumn<Produtos, String> prazo;
    
    private ObservableList<Produtos> dadosConsulta;
    
    
    @FXML
    void OnBackAction(ActionEvent event) {

    	try {
    		
    		
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Stock");
			stage.show();
    		
    	}catch (Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
    }

    @FXML
    void add(ActionEvent event) {

    	 try {
			 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Adicionar_Stock.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				scene = new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Adicionar Stock");
				stage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
    	
    }

    @FXML
    void edit(ActionEvent event) {

    	 try {
			 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Verificar_Stock_Editar.fxml"));
			root = loader.load();
			 
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Editar Stock");
			stage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
    	
    }

    @FXML
    void history(ActionEvent event) {

    	 try {
			 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Verificar_Stock_Relatorio.fxml"));
			root = loader.load();
			
			Stage historystage = new Stage();
			historystage.setScene(new Scene(root));
			historystage.setTitle("Relatorio");
			String imagepath = "/img/caixa.png"; 
			
			String localurl = getClass().getResource(imagepath).toExternalForm();
			
			Image x = new Image(localurl);
			historystage.getIcons().add(x);
			historystage.setResizable(false);
			historystage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
    	
    }

   
    
    

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
		
		dadosConsulta = obterDadosDaConsulta(); // Use a função para obter dados observáveis
		
		deleteProductsByQuantity(0);
		
		nr.setCellValueFactory(new PropertyValueFactory<Produtos,Integer>("produtoid"));
		marca.setCellValueFactory(new PropertyValueFactory<Produtos,String>("marca"));
		produto.setCellValueFactory(new PropertyValueFactory<Produtos,String>("tipo"));
		peso.setCellValueFactory(new PropertyValueFactory<Produtos,String>("peso"));
		quantidade.setCellValueFactory(new PropertyValueFactory<Produtos,Integer>("quantidade"));
		prazo.setCellValueFactory(new PropertyValueFactory<Produtos,String>("prazo"));
		
		
		
		
		stock.setItems(dadosConsulta);
		
		
//		stock.setEditable(true);
//		marca.setCellFactory(TextFieldTableCell.<Produtos>forTableColumn());
//		produto.setCellFactory(TextFieldTableCell.<Produtos>forTableColumn());
//		peso.setCellFactory(TextFieldTableCell.<Produtos, Double>forTableColumn(new DoubleStringConverter()));
//		quantidade.setCellFactory(TextFieldTableCell.<Produtos, Integer>forTableColumn(new IntegerStringConverter()));
		
	
		
		
		
//		// Simulação de atualização automática a cada 5 segundos
//        new Thread(() -> {
//            try {
//                while (true) {
//                    Thread.sleep(5000); // Espere 5 segundos
//                    stock.refresh();
//                }
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }).start();
		
	}
	
	 private  ObservableList<Produtos> obterDadosDaConsulta() {
		 ObservableList<Produtos> dados = FXCollections.observableArrayList();

	        String url = "jdbc:mysql://localhost:3306/sgsts";
	          String usuario = "root";
	          String senha = "1234567";

	        try {
Connection conn = DriverManager.getConnection(url, usuario, senha);
	  	        
	  	        System.out.println("Connected to the database!");
	  	        
	  	      String query = "SELECT * FROM produtos";
	    		Statement statement = conn.createStatement();
	    		
	    		ResultSet resultSet = statement.executeQuery(query);

	            while (resultSet.next()) {
	            	
	            	String pid = resultSet.getString("ProdutoID");
	    			String m = resultSet.getString("Marca");
	    			String t = resultSet.getString("Tipo");
	    			String ps = resultSet.getString("Peso");
	    			int qt = resultSet.getInt("Quantidade");
	    			String pz = resultSet.getString("Prazo");
//	    			System.out.println(pid );
	    			dados.add(new Produtos(pid,m,t,ps,qt,pz));
	            }

	            resultSet.close();
	            statement.close();
	            conn.close();
	            
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }

	        return dados;
	    }
	 
	 private void deleteProductsByQuantity(int quantity) {
			dadosConsulta.removeIf(produtos -> produtos.getQuantidade() == quantity);
	    }

}
