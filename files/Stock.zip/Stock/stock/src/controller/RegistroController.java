package controller;

import java.io.IOException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class RegistroController implements Initializable{
	
	private Parent root;
	private Stage stage;
	private Scene scene;

    @FXML
    private TextField emailfunc;

    @FXML
    private TextField funcao;

    @FXML
    private TextField gabinete;

    @FXML
    private ImageView imagem;

    @FXML
    private PasswordField passwordfunc;

    @FXML
    private TextField username;
    
    
    @FXML
    void OnBackAction(ActionEvent event) {

    	
    	try {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Menu");
			stage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
    	
    	
    }

    @FXML
    void OnRegistrarAction(ActionEvent event){

    	String url = "jdbc:mysql://localhost:3306/sgsts";
        String usuario = "root";
        String senha = "1234567";
        
        try {
        	
        	 String user = username.getText();
	    		String password = passwordfunc.getText();
	    		String hashDaSenhaInserida = hashPassword(password);
	    		String mail = emailfunc.getText();
	    		String func = funcao.getText();
	    		String gab = gabinete.getText();
	    		
	    		Connection conn = DriverManager.getConnection(url, usuario, senha);
	    		
	    		String selectverificar = "SELECT * FROM funcionarios WHERE Nome = ?";
	    		
	    		PreparedStatement stmt = conn.prepareStatement(selectverificar);
	    		
	    		stmt.setString(1, user);
	    		
	    		ResultSet result = stmt.executeQuery();
	    		
	    		if(result.next()) {
	    			
	    			 Alert alert = new Alert(AlertType.INFORMATION);
//	 	        	 alert.setTitle("Erro");
	 	 			alert.setContentText("Usuario Ja foi Cadastrado");
	 	 			alert.show();
	    			
	    		}else {
	    			
	    			 String inuser = "INSERT INTO funcionarios (Nome, Gabinete, PasswordFunc, emailfunc, Funcao) VALUES (?, ?, ?, ?, ?)";
		        	  
		        	  PreparedStatement prep = conn.prepareStatement(inuser);
		        	  
		        	  prep.setString(1, user);
		        	  prep.setString(2, gab);
		        	  prep.setString(3, hashDaSenhaInserida);
		        	  prep.setString(4, mail);
		        	  prep.setString(5, func);
		        	 
		        	  
		        	  int rows = prep.executeUpdate();
		        	  
		        	  if(rows > 0) {
		        		  
		        		  Alert alert = new Alert(AlertType.INFORMATION);
//		 	        	 alert.setTitle("Erro");
		 	 			alert.setContentText("Usuario Cadastrado com Sucesso");
		 	 			alert.show();
		        		  
		        	  }
	    			
	    		}
	    		
	    		stmt.close();
	    		result.close();
	    		conn.close();
	    		
        	
        }catch(Exception e) {
        	System.out.println(e.getMessage());
        }
    	
    	
    }
    
    public static String hashPassword(String password) {
    	
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());

            // Converter os bytes em uma representação hexadecimal
            StringBuilder hexStringBuilder = new StringBuilder();
            for (byte b : hashedBytes) {
                hexStringBuilder.append(String.format("%02x", b));
            }

            return hexStringBuilder.toString();
            
        } catch (NoSuchAlgorithmException e) {
            // Lida com exceção, se o algoritmo SHA-256 não estiver disponível
            e.printStackTrace();
            return null;
        }
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		String imagepath = "/img/ta.png"; 
		
		String localurl = getClass().getResource(imagepath).toExternalForm();
		
		Image x = new Image(localurl);
			imagem.setImage(x);
		
	}

}
