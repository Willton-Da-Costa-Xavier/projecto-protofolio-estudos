package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.scene.Node;

public class MenuController implements Initializable{

	private Parent root;
	private Scene scene;
	private Stage stage;
	
	 @FXML
	    private Button verificarPedidos;
	 
	 @FXML
	    private Circle notificacao;
	 
	 @FXML
	    void onVerificarPedidosAction(ActionEvent event) {

		 try {
	    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Administrador_Verificar_Pedidos.fxml"));
				root = loader.load();
				
				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				scene = new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Pedidos");
				stage.show();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		 
	    }
	 
	 
	 @FXML
	    void OnRegistrarAction(ActionEvent event) {

		 
		 try {
	    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Regitro_Funcionarios.fxml"));
				root = loader.load();
				
				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				scene = new Scene(root);
				stage.setScene(scene);
				stage.setTitle("Registro");
				stage.show();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	    }

	  @FXML
	    void OnAdicionarStock(ActionEvent event) {

		 try {
			 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu_Adicionar_Stock.fxml"));
			root = loader.load();
			
			Stage adstage = new Stage();
			adstage.setScene(new Scene(root));
			adstage.setTitle("Adicionar Stock");
			String imagepath = "/img/caixa.png"; 
			
			String localurl = getClass().getResource(imagepath).toExternalForm();
			
			Image x = new Image(localurl);
			adstage.getIcons().add(x);
			adstage.setResizable(false);
			adstage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		 
		  
	    }

	    @FXML
	    void OnEditarStock(ActionEvent event) {

	    	 try {
				 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Editar_Stock.fxml"));
				root = loader.load();
				
				Stage editstage = new Stage();
				editstage.setScene(new Scene(root));
				editstage.setTitle("Editar Stock");
				String imagepath = "/img/caixa.png"; 
				
				String localurl = getClass().getResource(imagepath).toExternalForm();
				
				Image x = new Image(localurl);
	 			editstage.getIcons().add(x);
	 			editstage.setResizable(false);
				editstage.show();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			 
	    	
	    }

	    @FXML
	    void OnVerificarStock(ActionEvent event) {

	    	 try {
		    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu_Verificar_Stock.fxml"));
					root = loader.load();
					
					stage = (Stage)((Node)event.getSource()).getScene().getWindow();
					scene = new Scene(root);
					stage.setScene(scene);
					stage.setTitle("Verificar Stock");
					stage.show();
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
	    	
	    }


		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			
			String url = "jdbc:mysql://localhost:3306/sgsts";
	          String usuario = "root";
	          String senha = "1234567";
			
			try {
				
				Connection conn = DriverManager.getConnection(url, usuario, senha);
	  	        
	  	        System.out.println("Connected to the database!");
	  	        
	  	        String verificarpedidos = "SELECT * FROM pedidos";
	  	        
	  	        Statement stmnt = conn.createStatement();
	  	        
	  	        ResultSet resultado = stmnt.executeQuery(verificarpedidos);
	  	        
	  	        if(resultado.next()) {
	  	        	
	  	        	notificacao.setVisible(true);
	  	        }
				
	  	        stmnt.close();
	  	        conn.close();
	  	        
			}catch (Exception e) {
				
				System.out.println(e.getMessage());
			}
			
		}
	
}
