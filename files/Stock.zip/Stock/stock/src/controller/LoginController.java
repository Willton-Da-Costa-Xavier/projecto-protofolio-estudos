package controller;

import java.io.IOException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import module.Admin;
import module.Funcionarios;
import module.Produtos;
import javafx.scene.Node;


public class LoginController implements Initializable{
	
	private Parent root;
	private Scene scene;
	private Stage stage;

	 @FXML
	    private PasswordField pass;

	    @FXML
	    private TextField username;
	    
	    @FXML
	    private ImageView imagem;

	   

	    @FXML
	    void OnEnterAction(ActionEvent event) {
	    	
	    	String url = "jdbc:mysql://localhost:3306/sgsts";
	          String usuario = "root";
	          String senha = "1234567";

	    	try {
	    	
		          
		          String user = username.getText();
		    		String password = pass.getText();
		    		String hashDaSenhaInserida5 = hashPassword(password);
		        	  
		  	        Connection conn = DriverManager.getConnection(url, usuario, senha);
		  	        
		  	        System.out.println("Connected to the database!");
		  	        System.out.println(user);
		  	        
		  	      
		  	      String query = "SELECT * FROM administradores WHERE NomeUtilizador = ? AND Password = ?";
		  	      String query2 = "SELECT * FROM funcionarios WHERE Nome = ? AND PasswordFunc = ?";
		  	      
		  	      
		    		PreparedStatement statementadmin = conn.prepareStatement(query);
		            PreparedStatement statementfuncionarios = conn.prepareStatement(query2);
		    		
		            statementadmin.setString(1, user);
		            statementadmin.setString(2, hashDaSenhaInserida5);
		            
		            statementfuncionarios.setString(1, user);
		            statementfuncionarios.setString(2, hashDaSenhaInserida5);
		            
		    		ResultSet resultSetadmin = statementadmin.executeQuery();
		    		ResultSet resultSetfuncionario = statementfuncionarios.executeQuery();
		            
		    		if (resultSetadmin.next()) {
			        	 
			        	 String nome = resultSetadmin.getString("NomeUtilizador");
			        	 String p = resultSetadmin.getString("Password");
			        	 
			        	 System.out.println(p);
			        	 
			        	 String hashDaSenhaInserida = hashPassword(password);
			        	 
			        	 System.out.println(p);
			        	 
				        	 if(p.equals(hashDaSenhaInserida) && nome.equals(user)) {
				        		 
				        		 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu.fxml"));
				 				root = loader.load();
				 				
				 				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
				 				scene = new Scene(root);
				 				stage.setScene(scene);
				 				stage.setTitle("Menu");
				 				stage.show();
				      	    	
				        	 }else if (p.equals(hashDaSenhaInserida)==false && nome.equals(user)){
					        	 
					        	 Alert alert = new Alert(AlertType.ERROR);
					        	 alert.setTitle("Erro");
					 			alert.setContentText("Password Incorrecto");
					 			alert.show();
					        	 
					         }else if(p.equals(hashDaSenhaInserida) && nome.equals(user)==false) {
					        	 
					        	 Alert alert = new Alert(AlertType.ERROR);
					        	 alert.setTitle("Erro");
					 			alert.setContentText("Nome do Usuario Incorrecto");
					 			alert.show();
					         }
				        	 
				       }else if(resultSetfuncionario.next()){
				        	 
				    	   String nomefunc = resultSetfuncionario.getString("Nome");
				        	 String p = resultSetfuncionario.getString("PasswordFunc");
				        	 
				        	 System.out.println(p);
				        	 
				        	 String hashDaSenhaInseridafunc = hashPassword(password);
				        	 
				        	 System.out.println(p);
				        	 
				        	 
					        	 if(p.equals(hashDaSenhaInseridafunc) && nomefunc.equals(user)) {
					        		 
					        		 FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/User_Verificar_Stock.fxml"));
					 				root = loader.load();
					 				
					 				User_Verificar_StockController usercontroller = loader.getController();
					 				usercontroller.User(user);
					 				
					 				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
					 				scene = new Scene(root);
					 				stage.setScene(scene);
					 				stage.setTitle("Stock");
					 				stage.show();
					      	    	
					        	 }else if (p.equals(hashDaSenhaInseridafunc)==false && nomefunc.equals(user)){
						        	 
						        	 Alert alert = new Alert(AlertType.ERROR);
						        	 alert.setTitle("Erro");
						 			alert.setContentText("Password Incorrecto");
						 			alert.show();
						        	 
						         }else if(p.equals(hashDaSenhaInseridafunc) && nomefunc.equals(user)==false) {
						        	 
						        	 Alert alert = new Alert(AlertType.ERROR);
						        	 alert.setTitle("Erro");
						 			alert.setContentText("Nome do Usuario Incorrecto");
						 			alert.show();
						         }
				        	 
				       }else{
				         
				    	   
				        	 Alert alert = new Alert(AlertType.ERROR);
				        	 alert.setTitle("Erro");
				 			alert.setContentText("Dados nao consta na base de dados");
				 			alert.show();
				    	   
				       }
				       
		    		


			        	 statementadmin.close();
			        	 statementfuncionarios.close();
		            conn.close();
		  	       
	    		
	    		
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	
	    	
	    }
	    
	    @FXML
	    void OnResetAction(ActionEvent event) {

	    }
	    
	    public static String hashPassword(String password) {
	    	
	        try {
	            MessageDigest md = MessageDigest.getInstance("SHA-256");
	            byte[] hashedBytes = md.digest(password.getBytes());

	            // Converter os bytes em uma representação hexadecimal
	            StringBuilder hexStringBuilder = new StringBuilder();
	            for (byte b : hashedBytes) {
	                hexStringBuilder.append(String.format("%02x", b));
	            }

	            return hexStringBuilder.toString();
	            
	        } catch (NoSuchAlgorithmException e) {
	            // Lida com exceção, se o algoritmo SHA-256 não estiver disponível
	            e.printStackTrace();
	            return null;
	        }
	    }

		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			
			String url = "jdbc:mysql://localhost:3306/sgsts";
	          String usuario = "root";
	          String senha = "1234567";
	          
	          try {
	        	  
	        	  Connection conn = DriverManager.getConnection(url, usuario, senha);
		  	        
		  	        System.out.println("Connected to the database!");
	        	  
	        	  String user = "Willton";
	        	  String p = "12345678";
	        	  String meumail = "willton00@gmail.com";
	        	  
	        	  String user2 = "Milton";
	        	  String p2 = "12345678";
	        	  String meumail2 = "miltonbobole@gmail.com";
	        	  String funcao = "Estagiario";
	        	  String gabinete = "Departamento de Informatica";
	        	  
	        	  String user3 = "Amanda";
	        	  String p3 = "12345678";
	        	  String meumail3 = "kataneira@gmail.com";
	        	  String funcao2 = "Estagiaria";
	        	  String gabinete2 = "Departamento de Informatica";
	        	  
	        	  String user4 = "Maura";
	        	  String p4 = "12345678";
	        	  String meumail4 = "baixinha@gmail.com";
	        	  String funcao3 = "Estagiaria";
	        	  String gabinete3 = "Departamento de Informatica";
	        	  
	        	  String hashedpassuser = hashPassword(p);
	        	  String hashedpassuser2 = hashPassword(p2);
	        	  String hashedpassuser3 = hashPassword(p3);
	        	  String hashedpassuser4 = hashPassword(p4);
	        	 
	        	  
	        	  Admin admin = new Admin(user, p, meumail);
	        	  Funcionarios usr = new Funcionarios(user2,gabinete, funcao, meumail2, hashedpassuser2);
	        	  Funcionarios usr2 = new Funcionarios(user3,gabinete, funcao2, meumail3, hashedpassuser3);
	        	  Funcionarios usr3 = new Funcionarios(user4,gabinete, funcao3, meumail4, hashedpassuser4);
	        	  
	        	  String selectadmin = "SELECT * FROM administradores";
	        	  
	        	  String selectuser = "SELECT * FROM funcionarios";
	        	  
	        	 Statement stateuser = conn.createStatement();
	        	  
	        	  Statement state = conn.createStatement();
	        	  
	        	  ResultSet rstuser = stateuser.executeQuery(selectuser);
	        	  
	        	  ResultSet rstadmin = state.executeQuery(selectadmin);
	        	  
	        	  if(rstadmin.next()) {
	        		  
	        		System.out.println("Admin ja cadastrado");
	        		  
	        	  }else {
	        		  
	        		  String inuser = "INSERT INTO administradores (NomeUtilizador, Password, email) VALUES (?, ?, ?)";
		        	  
		        	  PreparedStatement prep = conn.prepareStatement(inuser);
		        	  
		        	  prep.setString(1, user);
		        	  prep.setString(2, hashedpassuser);
		        	  prep.setString(3, meumail);
		        	  
		        	  int rows = prep.executeUpdate();
		        	  
		        	  if(rows > 0) {
		        		  
		        		  Alert alert = new Alert(AlertType.INFORMATION);
//		 	        	 alert.setTitle("Erro");
		 	 			alert.setContentText("Usuario Cadastrado com Sucesso");
		 	 			alert.show();
		        		  
		        	  }
	        		  
	        	  }
	        	  
	        	  if(rstuser.next()) {
	        		  System.out.println("usuarios ja Cadastrados");
	        	  }else {
	        		 
	        		  String inusuario = "INSERT INTO funcionarios (Nome, PasswordFunc, emailfunc, Gabinete, Funcao) VALUES(?, ?, ?, ?, ?), (?, ?, ?, ?, ?), (?, ?, ?, ?, ?)";
	        		  
	        		  PreparedStatement prepuser = conn.prepareStatement(inusuario);
	        		  
	        		  prepuser.setString(1, usr.getNome());
	        		  prepuser.setString(2, usr.getPassword());
	        		  prepuser.setString(3, usr.getMail());
	        		  prepuser.setString(4, usr.getGabinete());
	        		  prepuser.setString(5, usr.getFuncao());
	        		  
	        		  prepuser.setString(6, usr2.getNome());
	        		  prepuser.setString(7, usr2.getPassword());
	        		  prepuser.setString(8, usr2.getMail());
	        		  prepuser.setString(9, usr2.getGabinete());
	        		  prepuser.setString(10, usr2.getFuncao());
	        		  
	        		  prepuser.setString(11, usr3.getNome());
	        		  prepuser.setString(12, usr3.getPassword());
	        		  prepuser.setString(13, usr3.getMail());
	        		  prepuser.setString(14, usr3.getGabinete());
	        		  prepuser.setString(15, usr3.getFuncao());
	        		  
	        		  int rowsuser = prepuser.executeUpdate();
	        		  
	        		  if(rowsuser > 0) {
	        			  
	        			  Alert alert = new Alert(AlertType.INFORMATION);
//			 	        	 alert.setTitle("Erro");
			 	 			alert.setContentText("Funcionario Cadastrado com Sucesso");
			 	 			alert.show();
	        			  
	        		  }
	        	  }
	        	  
	        	  String imagepath = "/img/ta.png"; 
					
					String localurl = getClass().getResource(imagepath).toExternalForm();
					
					Image x = new Image(localurl);
						imagem.setImage(x);
	        	  
	        	 
	        	  
	          }catch(Exception e) {
	        	  e.printStackTrace();
	          }
			
			 
			
			
			
		}


		


		
		
		
		

	
}
