package controller;

import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;
import module.Produtos;

public class Adicionar_StockController {
	
	private Parent root;
	private Stage stage;
	private Scene scene;

    @FXML
    private TextField marca;

    @FXML
    private TextField peso;

    @FXML
    private TextField prod;

    @FXML
    private TextField quantidade;
    
    @FXML
    private TextField fornecedores;
    
    @FXML
    private DatePicker prazo;

    
    
    @FXML
    void OnBackAction(ActionEvent event) {

    	try {
    		
    		
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu_Verificar_Stock.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Stock");
			stage.show();
    		
    	}catch (Exception e) {
    		System.out.println(e.getMessage());
    	}
    	
    }
    
    
 // Método para gerar um código alfanumérico randomizado
    public static String gerarCodigo(int tamanho) {
        // Definir os caracteres permitidos para o código
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        // Inicializar o gerador de números aleatórios
        SecureRandom random = new SecureRandom();

        // StringBuilder para construir o código
        StringBuilder codigo = new StringBuilder(tamanho);

        // Gerar o código com o tamanho desejado
        for (int i = 0; i < tamanho; i++) {
            int indice = random.nextInt(caracteres.length());
            codigo.append(caracteres.charAt(indice));
        }

        return codigo.toString();
    }

    @FXML
    void onAddAction(ActionEvent event) {

    	String url = "jdbc:mysql://localhost:3306/sgsts";
        String usuario = "root";
        String senha = "1234567";
  	
  	try {
  		
  		
  		 String brand = marca.getText();
         String weight = peso.getText();
         String product = prod.getText();
         String q = quantidade.getText();
         String fornecedor = fornecedores.getText();
         String validade = prazo.getEditor().getText();
         int quantaty = Integer.parseInt(q);
         int tamanhoCodigo = 7;
         String codigo = gerarCodigo(tamanhoCodigo);
         
         
         
         Connection conn = DriverManager.getConnection(url, usuario, senha);
         
    
         
         Produtos produto = new Produtos(codigo,brand, product,weight, quantaty, validade);
 	        
 	        System.out.println("Connected to the database!");
 	        
 	       if (brand.isEmpty() || product.isEmpty() || weight.isEmpty() || quantaty == 0 || validade.isEmpty() || fornecedor.isEmpty()) {
	  	        Alert at = new Alert(AlertType.WARNING);
	  	        at.setContentText("Por favor, preencha todos os campos");
	  	        at.show();
	  	        
	  	    }else {
 	   // Insira um novo registro na tabela "Produtos"
           String inserirProdutosSQL = "INSERT INTO Produtos (ProdutoID, Marca, Tipo, Peso, Quantidade, Prazo) VALUES (?, ?, ?, ?, ?, ?)";
           PreparedStatement preparedStatementProdutos = conn.prepareStatement(inserirProdutosSQL);
           preparedStatementProdutos.setString(1, produto.getProdutoid());
           preparedStatementProdutos.setString(2, produto.getMarca());
           preparedStatementProdutos.setString(3, produto.getTipo());
           preparedStatementProdutos.setString(4, produto.getPeso()); // Exemplo de valor para Peso
           preparedStatementProdutos.setInt(5, produto.getQuantidade()); // Exemplo de valor para Quantidade
           preparedStatementProdutos.setString(6, produto.getPrazo());

           preparedStatementProdutos.executeUpdate();
           
           String selectproject = "SELECT ProdutoID From produtos WHERE Tipo = ?";
           PreparedStatement prepprodid = conn.prepareStatement(selectproject);
           
           prepprodid.setString(1, produto.getTipo());
           
           ResultSet chavesGeradas = prepprodid.executeQuery();
           	
           if (chavesGeradas.next()) {
              String produtoID = chavesGeradas.getString("ProdutoID");
           // Insira dados correspondentes na tabela "EntradaStock" usando o "ProdutoID"
           
               LocalDateTime agora = LocalDateTime.now();
               DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
               String dataEntrada = agora.format(formatter);
               
               String inserirfornecedores = "INSERT INTO fornecedores (Nome, ProdutoID) VALUES (?, ?)";
               PreparedStatement prepfornecedores = conn.prepareStatement(inserirfornecedores);
               prepfornecedores.setString(1, fornecedor);
               prepfornecedores.setString(2, produtoID);
               System.out.println(produtoID);
               prepfornecedores.executeUpdate();
               
               String selectforn = "SELECT FornecedorID FROM fornecedores WHERE ProdutoID = ?";
               
               PreparedStatement prepfornecedoresselect = conn.prepareStatement(selectforn);
               
               prepfornecedoresselect.setString(1, produtoID);
               
               ResultSet resultselectfprnecedores = prepfornecedoresselect.executeQuery();
               
               if(resultselectfprnecedores.next()) {
            	   
            	   int fornid  = resultselectfprnecedores.getInt("FornecedorID");
            	   
            	   System.out.println(fornid);
            	   
            	   String inserirEntradaStockSQL = "INSERT INTO EntradaStock (ProdutoID, QuantidadeEntrada, DataEntrada, FornecedorID) VALUES (?, ?, ?, ?)";
                   PreparedStatement preparedStatementEntradaStock = conn.prepareStatement(inserirEntradaStockSQL);
                   preparedStatementEntradaStock.setString(1, produtoID);
                   preparedStatementEntradaStock.setInt(2, quantaty); // Exemplo de quantidade de entrada
                   preparedStatementEntradaStock.setString(3, dataEntrada);
                   preparedStatementEntradaStock.setInt(4,fornid );

                   // Execute o INSERT na tabela "EntradaStock"
                   preparedStatementEntradaStock.executeUpdate();
                   
                  
                   
                   Alert alert = new Alert(AlertType.INFORMATION);
//    	        	 alert.setTitle("Erro");
    	 			alert.setContentText("Dados Inseridos com Sucesso");
    	 			alert.show();
    	 			
    	 			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu_Verificar_Stock.fxml"));
    				root = loader.load();
    				
    				stage = (Stage)((Node)event.getSource()).getScene().getWindow();
    				scene = new Scene(root);
    				stage.setScene(scene);
    				stage.setTitle("Stock");
    				stage.show();
               }

              
           }
           preparedStatementProdutos.close();
           chavesGeradas.close();
	  	    }

           // Feche os recursos
          
           conn.close();
           
  	}catch(Exception e) {
  			e.printStackTrace();
  	}
  	}
}
