package controller;

import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import module.CombineData;
import module.FileCounterManager;
import module.Produtos;

public class Menu_Verificar_Stock_RelatorioController implements Initializable{
	
	private Stage stage;
	private Scene scene;
	private Parent root;

	  @FXML
	    private TableColumn<CombineData, String> datasaida;

	    @FXML
	    private TableView<CombineData> entradas;

	    @FXML
	    private TableColumn<CombineData, String> funcaosaida;

	    @FXML
	    private TableColumn<CombineData, String> funcionariosaida;

	    @FXML
	    private TableColumn<CombineData, String> gabinetesaida;

	    @FXML
	    private TableColumn<CombineData, String> marcaentrada;

	    @FXML
	    private TableColumn<CombineData, String> marcasaida;


	    @FXML
	    private TableColumn<CombineData, String> pesoentrada;

	    @FXML
	    private TableColumn<CombineData, String> pesosaida;

	    @FXML
	    private TableColumn<CombineData, String> produtoentrada;

	    @FXML
	    private TableColumn<CombineData, String> produtosaida;

	    @FXML
	    private TableColumn<CombineData, Integer> quantidadeentrada;

	    @FXML
	    private TableColumn<CombineData, Integer> quantidadesaida;

	    @FXML
	    private TableView<CombineData> saidas;
	    
	    @FXML
	    private TableColumn<CombineData, String> dataentrada;
	    
	    @FXML
	    private TableColumn<CombineData, String> fornecedorentrada;
	    
	    private ObservableList<CombineData> dados;
	    
	    private ObservableList<CombineData> dados2;
	    
	    private int fileCounter;

    @FXML
    void OnImprimir(ActionEvent event) throws FileNotFoundException, DocumentException{
    	
    	
    	
    	Document doc = new Document(PageSize.A4.rotate());
    	
    	
    	  // Caminho para a pasta no desktop
        String caminhoPasta = System.getProperty("user.home") + "/Desktop/Estoque_PDF";

        // Criar um objeto File representando a pasta
        File pasta = new File(caminhoPasta);

        // Criar a pasta se ela não existir
        if (!pasta.exists()) {
            boolean criada = pasta.mkdir();
            if (criada) {
                System.out.println("Pasta criada com sucesso!");
            } else {
                System.out.println("Falha ao criar a pasta.");
                return;
            }
            
        } else {
            System.out.println("A pasta já existe.");
        }

        String dataAtual = LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        String caminhoArquivo = caminhoPasta + "/Estoque_" + dataAtual + ".pdf";
        File arq = new File(caminhoArquivo);
        

        try {
            boolean arquivoCriado = arq.createNewFile();
            if (arquivoCriado) {
            	
            	PdfWriter.getInstance(doc, new FileOutputStream(caminhoArquivo));
        		doc.open();
            	
            	ObservableList<TableColumn<CombineData, ?>> colunas = entradas.getColumns();
            	
            	 Font fonteNegrito = FontFactory.getFont(FontFactory.TIMES_BOLD, 12); // Defina a fonte como negrito
            	
            	Paragraph entr = new Paragraph("Entradas",fonteNegrito);
            	entr.setAlignment(1);
            	doc.add(entr);
            	entr = new Paragraph(" ");
            	doc.add(entr);

            	PdfPTable tabela = new PdfPTable(colunas.size()); // O número de colunas na TableView

            	// Adicione os cabeçalhos das colunas à tabela no PDF
            	for (TableColumn<CombineData, ?> coluna : colunas) {
            		
            		  if (!"nrentrada".equals(coluna.getId())) {
                          tabela.addCell(new Paragraph(coluna.getText()));
                      }
            	    
            	}

            	// Adicione os dados das linhas à tabela no PDF
            	ObservableList<CombineData> dados3 = entradas.getItems();
            	for (CombineData linha : dados3) {
            	    for (TableColumn<CombineData, ?> coluna : colunas) {
            	        Object cellValue = coluna.getCellData(linha);
            	        tabela.addCell(new Paragraph(String.valueOf(cellValue)));
            	    }
            	}

            	// Adicione a tabela ao documento PDF
            	doc.add(tabela);
        		
            	
            	ObservableList<TableColumn<CombineData, ?>> colunas2 = saidas.getColumns();
            	Paragraph entr2 = new Paragraph("");
                entr2 = new Paragraph("Saidas",fonteNegrito);
            	entr2.setAlignment(1);
            	doc.add(entr2);
            	entr2 = new Paragraph(" ");
            	doc.add(entr2);
            	
            	PdfPTable tabela2 = new PdfPTable(colunas2.size()); // O número de colunas na TableView

            	// Adicione os cabeçalhos das colunas à tabela no PDF
            	for (TableColumn<CombineData, ?> coluna2 : colunas2) {
            		if (!"nrsaida".equals(coluna2.getId())) {
                        tabela2.addCell(new Paragraph(coluna2.getText()));
                    }
            	}

            	// Adicione os dados das linhas à tabela no PDF
            	ObservableList<CombineData> dados4 = saidas.getItems();
            	for (CombineData linha2 : dados4) {
            	    for (TableColumn<CombineData, ?> coluna2 : colunas2) {
            	        Object cellValue2 = coluna2.getCellData(linha2);
            	        tabela2.addCell(new Paragraph(String.valueOf(cellValue2)));
            	    }
            	}

            	// Adicione a tabela ao documento PDF
            	doc.add(tabela2);
        		
        		doc.close();
        		
        		Alert alert = new Alert(AlertType.INFORMATION);
//          	 alert.setTitle("Erro");
        		alert.setContentText("PDF Criado");
        		alert.show();
        		
        		Desktop.getDesktop().open(new File(caminhoArquivo));
                System.out.println("Arquivo criado com sucesso!");
                
                fileCounter++;
                FileCounterManager.saveFileCounter(fileCounter);
                
            } else {
            	  Alert alert = new Alert(AlertType.INFORMATION);
//           	 alert.setTitle("Erro");
         		alert.setContentText("PDF ja Criado Verifique a pasta stock no Desktop");
         		alert.show();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    	

    
    	
    	
    	
    }
    
    @FXML
    void OnBackAction(ActionEvent event) {

    	try {
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Menu_Verificar_Stock.fxml"));
			root = loader.load();
			
			stage = (Stage)((Node)event.getSource()).getScene().getWindow();
			scene = new Scene(root);
			stage.setScene(scene);
			stage.setTitle("Verificar Stock");
			stage.show();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
    	
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		marcasaida.setCellValueFactory(new PropertyValueFactory<CombineData,String>("marca"));
		produtosaida.setCellValueFactory(new PropertyValueFactory<CombineData,String>("tipo"));
		pesosaida.setCellValueFactory(new PropertyValueFactory<CombineData,String>("peso"));
		quantidadesaida.setCellValueFactory(new PropertyValueFactory<CombineData,Integer>("quantidade"));
		gabinetesaida.setCellValueFactory(new PropertyValueFactory<CombineData,String>("gabinete"));
		funcionariosaida.setCellValueFactory(new PropertyValueFactory<CombineData,String>("nome"));
		funcaosaida.setCellValueFactory(new PropertyValueFactory<CombineData,String>("funcao"));
		datasaida.setCellValueFactory(new PropertyValueFactory<CombineData,String>("datasaida"));
		
//		 fileCounter = FileCounterManager.loadFileCounter();
		
		
		dados = FXCollections.observableArrayList();
		
		
		saidas.setItems(dados);
		
		
		
		obterDados();
		
	
		marcaentrada.setCellValueFactory(new PropertyValueFactory<CombineData,String>("marca"));
		produtoentrada.setCellValueFactory(new PropertyValueFactory<CombineData,String>("tipo"));
		pesoentrada.setCellValueFactory(new PropertyValueFactory<CombineData,String>("peso"));
		quantidadeentrada.setCellValueFactory(new PropertyValueFactory<CombineData,Integer>("quantidade"));
		fornecedorentrada.setCellValueFactory(new PropertyValueFactory<CombineData,String>("fornecedor"));
		dataentrada.setCellValueFactory(new PropertyValueFactory<CombineData,String>("dataentrada"));
		
		dados2 = FXCollections.observableArrayList();
		
		entradas.setItems(dados2);
		
		obterDadoentrada();
	}
	
	
	 private  ObservableList<CombineData> obterDados() {
			
//		 ObservableList<CombineData> dados = FXCollections.observableArrayList();
		 
		 String url = "jdbc:mysql://localhost:3306/sgsts";
         String usuario = "root";
         String senha = "1234567";
         
         try {
        	 
        	 Connection conn = DriverManager.getConnection(url, usuario, senha);
        	 
        	 System.out.println("Connected to the database!");
	  	        
	  	      String query = "SELECT * FROM produtos";
	    		Statement statement = conn.createStatement();
	    		
	    		ResultSet resultSet = statement.executeQuery(query);

	            while (resultSet.next()) {
	            	
	            	String pid = resultSet.getString("ProdutoID");
	    			String m = resultSet.getString("Marca");
	    			String t = resultSet.getString("Tipo");
	    			String ps = resultSet.getString("Peso");
	    			int qt = resultSet.getInt("Quantidade");
//	    			System.out.println(pid );
	    			
	    				
	    				String selectsaida = "SELECT FuncionarioID, QuantidadeSaida, DataSaida FROM saidastock WHERE ProdutoID = ?";
	    				
	    				PreparedStatement prepsaida = conn.prepareStatement(selectsaida);
	    				
	    				prepsaida.setString(1, pid);
	    			
	    				
	    				ResultSet resulsaida = prepsaida.executeQuery();
	    				
	    				if(resulsaida.next()) {
	    			
	    					int funid = resulsaida.getInt("FuncionarioID");
	    					int quantsaida = resulsaida.getInt("QuantidadeSaida");
	    					String dtasaida = resulsaida.getString("DataSaida");
	    					  
	    					String selectfuncionarios = "SELECT Gabinete, Nome, Funcao FROM funcionarios WHERE FuncionarioID = ?";
	    					
	    					PreparedStatement prepfuncionario = conn.prepareStatement(selectfuncionarios);
	    					
	    					prepfuncionario.setInt(1, funid);
	    					
	    					ResultSet resulfuncionarios = prepfuncionario.executeQuery();
	    					
	    					if(resulfuncionarios.next()) {
	    						
	    						String gab = resulfuncionarios.getString("Gabinete");
	    						
	    						String n = resulfuncionarios.getString("Nome");
	    						
	    						String func = resulfuncionarios.getString("Funcao");
	    						
	    						dados.add(new CombineData(pid,m, t, ps, quantsaida,n, gab, func, dtasaida));
	    					}
	    				
		    			
	    				
	    			}
	    			
	    			
	            }

	            resultSet.close();
	            statement.close();
	            conn.close();
        	 
         }catch(SQLException e) {
        	 e.printStackTrace();
         }
         
         return dados;
	}
	 
	 private  ObservableList<CombineData> obterDadoentrada() {
			
//		 ObservableList<CombineData> dados = FXCollections.observableArrayList();
		 
		 String url = "jdbc:mysql://localhost:3306/sgsts";
         String usuario = "root";
         String senha = "1234567";
         
         try {
        	 
        	 Connection conn = DriverManager.getConnection(url, usuario, senha);
        	 
        	 System.out.println("Connected to the database!");
	  	        
	  	      String query = "SELECT ProdutoID, Tipo, Marca, Peso FROM produtos";
	    		Statement statement = conn.createStatement();
	    		
	    		ResultSet resultSet = statement.executeQuery(query);

	            while (resultSet.next()) {
	            	
	            	String pid = resultSet.getString("ProdutoID");
	    			String m = resultSet.getString("Marca");
	    			String t = resultSet.getString("Tipo");
	    			String ps = resultSet.getString("Peso");
	    			
//	    			System.out.println(pid );
	    			
	    				
	    				String selectentrada = "SELECT FornecedorID, QuantidadeEntrada, DataEntrada FROM entradastock WHERE ProdutoID = ?";
	    				
	    				PreparedStatement prepentrada = conn.prepareStatement(selectentrada);
	    				
	    				prepentrada.setString(1, pid);
	    			
	    				
	    				ResultSet resulentrada = prepentrada.executeQuery();
	    				
	    				if(resulentrada.next()) {
	    			
	    					int fornid = resulentrada.getInt("FornecedorID");
	    					int quantentrada = resulentrada.getInt("QuantidadeEntrada");
	    					String dtaentrada = resulentrada.getString("DataEntrada");
	    					
	    					
	    					  
	    					String selectfornecedor = "SELECT Nome FROM fornecedores WHERE ProdutoID = ?";
	    					
	    					PreparedStatement prepfornecedor = conn.prepareStatement(selectfornecedor);
	    					
	    					prepfornecedor.setString(1, pid);
	    					
	    					ResultSet resulfornecedor = prepfornecedor.executeQuery();
	    					
	    					if(resulfornecedor.next()) {
	    						
	    						String nomefornecedor = resulfornecedor.getString("Nome");
	    						
	    						System.out.println(quantentrada+" "+dtaentrada + " "+nomefornecedor);
	    						 
	    						dados2.add(new CombineData(pid,m, t, ps, quantentrada,nomefornecedor, dtaentrada));
	    						
	    						
	    					}
	    				
		    			
	    				
	    			}
	    			
	    			
	            }

	            resultSet.close();
	            statement.close();
	            conn.close();
        	 
         }catch(SQLException e) {
        	 e.printStackTrace();
         }
         
         return dados2;
	}

}
