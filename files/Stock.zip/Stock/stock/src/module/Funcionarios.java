package module;

public class Funcionarios {

	private int funcionarioid;
	private String nome;
	private String password;
	private String mail;
	private String gabinete;
	private String funcao;
	
	
	
	public Funcionarios(int funcionarioid, String nome, String gabinete, String funcao, String pass, String mail) {
		this.mail = mail;
		this.password = pass;
		this.funcionarioid = funcionarioid;
		this.nome = nome;
		this.gabinete = gabinete;
		this.funcao = funcao;
	}
	
	public Funcionarios(String nome, String gabinete, String funcao, String mail, String pass) {
		this.mail = mail;
		this.password = pass;
		this.nome = nome;
		this.gabinete = gabinete;
		this.funcao = funcao;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public int getFuncionarioid() {
		return funcionarioid;
	}
	public void setFuncionarioid(int funcionarioid) {
		this.funcionarioid = funcionarioid;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getGabinete() {
		return gabinete;
	}
	public void setGabinete(String gabinete) {
		this.gabinete = gabinete;
	}
	public String getFuncao() {
		return funcao;
	}
	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}
	
}
