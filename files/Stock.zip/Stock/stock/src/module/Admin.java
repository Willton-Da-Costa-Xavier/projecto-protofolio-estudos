package module;

public class Admin {

	protected String user;
	protected String password;
	protected String mail;
	
	
	public Admin(String user, String password, String mail) {
		super();
		this.user = user;
		this.password = password;
		this.mail = mail;
	}
	
	public Admin() {
		super();
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
