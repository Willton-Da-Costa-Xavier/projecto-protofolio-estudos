package module;

import java.time.LocalDateTime;

public class SaidaStock extends Produtos{


	private int saidaid;
	private int funcionarioid;
	private int quantidadesaida;
	private LocalDateTime datasaida;
	
	public SaidaStock(String produtoid, String marca, String tipo, String peso, int quantidade, int saidaid, int funcionarioid, int quantidadesaida, LocalDateTime datasaida, String prazo) {
		super(produtoid, marca, tipo, peso, quantidade, prazo);
	}

	public int getSaidaid() {
		return saidaid;
	}

	public void setSaidaid(int saidaid) {
		this.saidaid = saidaid;
	}


	public int getFuncionarioid() {
		return funcionarioid;
	}

	public void setFuncionarioid(int funcionarioid) {
		this.funcionarioid = funcionarioid;
	}

	public int getQuantidadesaida() {
		return quantidadesaida;
	}

	public void setQuantidadesaida(int quantidadesaida) {
		this.quantidadesaida = quantidadesaida;
	}

	public LocalDateTime getDatasaida() {
		return datasaida;
	}

	public void setDatasaida(LocalDateTime datasaida) {
		this.datasaida = datasaida;
	}
	
 

}
