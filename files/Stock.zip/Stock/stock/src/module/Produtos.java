package module;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

public class Produtos {

	private String produtoid;
	private String marca;
	private String tipo;
	private String peso;
	private int quantidade;
	private boolean  marcado;
	private String prazo;
	
	
	public boolean isMarcado() {
		return marcado;
	}


	public void setMarcado(boolean marcado) {
		this.marcado = marcado;
	}
	
	
	public Produtos(String produtoid, String marca, String tipo, String peso, int quantidade) {
		super();
		this.produtoid = produtoid;
		this.marca = marca;
		this.tipo = tipo;
		this.peso = peso;
		this.quantidade = quantidade;
		
	}


	public Produtos(String produtoid, String marca, String tipo, String peso, int quantidade, String prazo) {
		super();
		this.produtoid = produtoid;
		this.marca = marca;
		this.tipo = tipo;
		this.peso = peso;
		this.quantidade = quantidade;
		this.prazo = prazo;
	}
	
	
	public String getPrazo() {
		return prazo;
	}


	public void setPrazo(String prazo) {
		this.prazo = prazo;
	}


	public Produtos(String marca, String tipo, String peso, int quantidade) {
		super();
		this.marca = marca;
		this.tipo = tipo;
		this.peso = peso;
		this.quantidade = quantidade;
	}
	
public Produtos(boolean marcado, String marca, String tipo, String peso, int quantidade, String prazo) {
		super();
		this.marcado = marcado;
		this.marca = marca;
		this.tipo = tipo;
		this.peso = peso;
		this.quantidade = quantidade;
		this.prazo = prazo;
	}


	public String getProdutoid() {
		return produtoid;
	}


	public void setProdutoid(String produtoid) {
		this.produtoid = produtoid;
	}


	public String getMarca() {
		return marca;
	}


	public void setMarca(String marca) {
		this.marca = marca;
	}


	public String getTipo() {
		return tipo;
	}


	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


	public String getPeso() {
		return peso;
	}


	public void setPeso(String peso) {
		this.peso = peso;
	}


	public int getQuantidade() {
		return quantidade;
	}


	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	
	
	
	
}
