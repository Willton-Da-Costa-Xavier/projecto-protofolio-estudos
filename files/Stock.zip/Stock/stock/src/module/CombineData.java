package module;

import java.time.LocalDateTime;

public class CombineData {

	private String produtoid;
	private String marca;
	private String tipo;
	private String peso;
	private int quantidade;
	private String nome;
	private String gabinete;
	private String funcao;
	private String datasaida;
	private String dataentrada;
	private String fornecedor;
	
	public CombineData(String produtoid, String marca, String tipo, String peso, int quantidade, String nome, String gabinete, String funcao) {
		super();
		this.produtoid = produtoid;
		this.marca = marca;
		this.tipo = tipo;
		this.peso = peso;
		this.quantidade = quantidade;
		this.nome = nome;
		this.gabinete = gabinete;
		this.funcao = funcao;
	}
	
	public CombineData(String produtoid, String marca, String tipo, String peso, int quantidade, String nome, String gabinete, String funcao, String datasaida) {
		super();
		this.produtoid = produtoid;
		this.marca = marca;
		this.tipo = tipo;
		this.peso = peso;
		this.quantidade = quantidade;
		this.nome = nome;
		this.gabinete = gabinete;
		this.funcao = funcao;
		this.datasaida = datasaida;
	}
	
	public CombineData(String produtoid, String marca, String tipo, String peso, int quantidade, String fornecedor,String dataentrada) {
		super();
		this.produtoid = produtoid;
		this.marca = marca;
		this.tipo = tipo;
		this.peso = peso;
		this.quantidade = quantidade;
		this.fornecedor = fornecedor;
		this.dataentrada = dataentrada;
	}
	
	public CombineData(String nome, String gabinete, String marca, String tipo, String peso, int quantidade ) {
		super();
		this.nome = nome;
		this.gabinete = gabinete;
		this.marca = marca;
		this.tipo = tipo;
		this.peso = peso;
		this.quantidade = quantidade;
	}

	public String getDataentrada() {
		return dataentrada;
	}

	public void setDataentrada(String dataentrada) {
		this.dataentrada = dataentrada;
	}

	public String getFornecedor() {
		return fornecedor;
	}

	public void setFornecedor(String fornecedor) {
		this.fornecedor = fornecedor;
	}

	public String getDatasaida() {
		return datasaida;
	}

	public void setDatasaida(String datasaida) {
		this.datasaida = datasaida;
	}

	public String getProdutoid() {
		return produtoid;
	}

	public void setProdutoid(String produtoid) {
		this.produtoid = produtoid;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getPeso() {
		return peso;
	}

	public void setPeso(String peso) {
		this.peso = peso;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getGabinete() {
		return gabinete;
	}

	public void setGabinete(String gabinete) {
		this.gabinete = gabinete;
	}

	public String getFuncao() {
		return funcao;
	}

	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}

   

	
}
