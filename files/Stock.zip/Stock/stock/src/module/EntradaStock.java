package module;

import java.time.LocalDateTime;

public class EntradaStock{
	private int prodid;
	private int quantidadeentrada;
	private LocalDateTime dataentrada;

	public EntradaStock(int prodid, int quantidadeentrada, LocalDateTime dataentrada) {
		super();
		this.prodid = prodid;
		this.quantidadeentrada = quantidadeentrada;
		this.dataentrada = dataentrada;
	}


	public int getProdid() {
		return prodid;
	}


	public void setProdid(int prodid) {
		this.prodid = prodid;
	}


	public int getQuantidadeentrada() {
		return quantidadeentrada;
	}

	public void setQuantidadeentrada(int quantidadeentrada) {
		this.quantidadeentrada = quantidadeentrada;
	}

	public LocalDateTime getDataentrada() {
		return dataentrada;
	}

	public void setDataentrada(LocalDateTime dataentrada) {
		this.dataentrada = dataentrada;
	}

	
	
}
