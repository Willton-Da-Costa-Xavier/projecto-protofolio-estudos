package module;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileCounterManager {

	
	private static final String DIRECTORY_PATH = "files";
    private static final String FILE_PATH = DIRECTORY_PATH + "/fileCounter.txt"; // Caminho completo incluindo o diretório

    public static int loadFileCounter() {
        int counter = 1; // Valor padrão se o arquivo não existir

        try {
            // Obter o diretório atual do projeto
            String projetoDiretorio = System.getProperty("user.dir");
            File directory = new File(projetoDiretorio, DIRECTORY_PATH);

            // Verificar se o diretório existe, se não, criar
            if (!directory.exists()) {
                directory.mkdirs(); // Cria os diretórios pais também, se necessário
            }

            // Ler o contador do arquivo
            try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
                String line = reader.readLine();
                if (line != null && !line.isEmpty()) {
                    counter = Integer.parseInt(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return counter;
    }

    public static void saveFileCounter(int counter) {
        try {
            // Obter o diretório atual do projeto
            String projetoDiretorio = System.getProperty("user.dir");
            File directory = new File(projetoDiretorio, DIRECTORY_PATH);

            // Verificar se o diretório existe, se não, criar
            if (!directory.exists()) {
                directory.mkdirs(); // Cria os diretórios pais também, se necessário
            }

            // Salvar o contador no arquivo
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
                writer.write(String.valueOf(counter));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Exemplo de uso
        int counter = loadFileCounter();
        System.out.println("Counter: " + counter);

        // Modificar o contador (por exemplo, incrementar)
        counter++;

        // Salvar o novo contador
        saveFileCounter(counter);
    }
	
}
